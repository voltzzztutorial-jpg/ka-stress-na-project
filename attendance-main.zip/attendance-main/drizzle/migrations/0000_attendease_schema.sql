create type public.app_role as enum ('admin','faculty','student');
create type public.attendance_status as enum ('present','absent','late','excused');

create or replace function public.set_updated_at() returns trigger language plpgsql set search_path = public as $$
begin new.updated_at := now(); return new; end $$;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null default '',
  avatar_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index profiles_email_idx on public.profiles (lower(btrim(email)));
grant select, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
create index user_roles_user_idx on public.user_roles(user_id);
grant select, insert, update, delete on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.is_active_user(_user_id uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_active from public.profiles where id = _user_id), false)
$$;
create or replace function public.has_role(_user_id uuid, _role public.app_role) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_active_user(_user_id) and exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;
create or replace function public.is_staff(_user_id uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_active_user(_user_id) and exists (select 1 from public.user_roles where user_id = _user_id and role in ('admin','faculty'))
$$;

create table public.students (
  id uuid primary key default gen_random_uuid(),
  student_number text not null,
  first_name text not null,
  last_name text not null,
  email text not null,
  program text not null,
  year_level int not null check (year_level between 1 and 5),
  section text not null default 'A',
  user_id uuid references public.profiles(id) on delete set null,
  status text not null default 'active' check (status in ('active','inactive')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index students_number_uq on public.students (upper(btrim(student_number)));
create unique index students_email_uq on public.students (lower(btrim(email)));
create index students_user_idx on public.students(user_id);
create index students_name_idx on public.students(last_name, first_name);
grant select, insert, update, delete on public.students to authenticated;
grant all on public.students to service_role;
alter table public.students enable row level security;

create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  subject_code text not null,
  subject_name text not null,
  faculty_id uuid references public.profiles(id) on delete set null,
  schedule_day text not null default 'Monday',
  schedule_time text not null default '08:00',
  room text not null default '',
  semester text not null default '1st Semester',
  school_year text not null default '2026-2027',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index subjects_code_uq on public.subjects (upper(btrim(subject_code)));
create index subjects_faculty_idx on public.subjects(faculty_id);
grant select, insert, update, delete on public.subjects to authenticated;
grant all on public.subjects to service_role;
alter table public.subjects enable row level security;

create table public.enrollments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (student_id, subject_id)
);
create index enrollments_subject_idx on public.enrollments(subject_id);
grant select, insert, update, delete on public.enrollments to authenticated;
grant all on public.enrollments to service_role;
alter table public.enrollments enable row level security;

create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  attendance_date date not null,
  time_recorded time not null default localtime,
  status public.attendance_status not null,
  remarks text,
  recorded_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (student_id, subject_id, attendance_date)
);
create index attendance_subject_date_idx on public.attendance(subject_id, attendance_date);
create index attendance_date_idx on public.attendance(attendance_date);
grant select, insert, update, delete on public.attendance to authenticated;
grant all on public.attendance to service_role;
alter table public.attendance enable row level security;

create table public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity text not null,
  details text,
  created_at timestamptz not null default now()
);
create index activity_logs_created_idx on public.activity_logs(created_at desc);
create index activity_logs_action_idx on public.activity_logs(action);
grant select, insert on public.activity_logs to authenticated;
grant all on public.activity_logs to service_role;
alter table public.activity_logs enable row level security;

create trigger profiles_updated before update on public.profiles for each row execute function public.set_updated_at();
create trigger students_updated before update on public.students for each row execute function public.set_updated_at();
create trigger subjects_updated before update on public.subjects for each row execute function public.set_updated_at();
create trigger attendance_updated before update on public.attendance for each row execute function public.set_updated_at();

create or replace function public.teaches(_user_id uuid, _subject_id uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.has_role(_user_id,'faculty') and exists (select 1 from public.subjects where id = _subject_id and faculty_id = _user_id)
$$;
create or replace function public.my_student_id(_user_id uuid) returns uuid
language sql stable security definer set search_path = public as $$
  select s.id from public.students s where s.user_id = _user_id and public.is_active_user(_user_id) limit 1
$$;

create policy "read own or staff profiles" on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_staff(auth.uid()));
create policy "active user updates own profile" on public.profiles for update to authenticated
  using (id = auth.uid() and public.is_active_user(auth.uid())) with check (id = auth.uid());
create policy "admin updates profiles" on public.profiles for update to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create or replace function public.guard_profile() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.has_role(auth.uid(),'admin') then
    new.is_active := old.is_active;
    new.email := old.email;
  end if;
  new.email := lower(btrim(new.email));
  return new;
end $$;
create trigger guard_profile before update on public.profiles for each row execute function public.guard_profile();

create policy "read own roles or staff" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.is_staff(auth.uid()));
create policy "admin manages roles" on public.user_roles for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create policy "staff or self read students" on public.students for select to authenticated
  using (public.is_staff(auth.uid()) or (user_id = auth.uid() and public.is_active_user(auth.uid())));
create policy "staff insert students" on public.students for insert to authenticated with check (public.is_staff(auth.uid()));
create policy "staff update students" on public.students for update to authenticated
  using (public.is_staff(auth.uid())) with check (public.is_staff(auth.uid()));
create policy "admin delete students" on public.students for delete to authenticated using (public.has_role(auth.uid(),'admin'));

create policy "active users read subjects" on public.subjects for select to authenticated using (public.is_active_user(auth.uid()));
create policy "admin insert subjects" on public.subjects for insert to authenticated with check (public.has_role(auth.uid(),'admin'));
create policy "admin or teacher update subjects" on public.subjects for update to authenticated
  using (public.has_role(auth.uid(),'admin') or (public.has_role(auth.uid(),'faculty') and faculty_id = auth.uid()))
  with check (public.has_role(auth.uid(),'admin') or (public.has_role(auth.uid(),'faculty') and faculty_id = auth.uid()));
create policy "admin delete subjects" on public.subjects for delete to authenticated using (public.has_role(auth.uid(),'admin'));

create or replace function public.guard_subject() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.has_role(auth.uid(),'admin') then
    if new.faculty_id is distinct from old.faculty_id or new.subject_code is distinct from old.subject_code then
      raise exception 'Faculty cannot change the subject code or assigned faculty';
    end if;
  end if;
  return new;
end $$;
create trigger guard_subject before update on public.subjects for each row execute function public.guard_subject();

create policy "read enrollments" on public.enrollments for select to authenticated
  using (public.has_role(auth.uid(),'admin') or public.teaches(auth.uid(), subject_id) or student_id = public.my_student_id(auth.uid()));
create policy "manage enrollments" on public.enrollments for all to authenticated
  using (public.has_role(auth.uid(),'admin') or public.teaches(auth.uid(), subject_id))
  with check (public.has_role(auth.uid(),'admin') or public.teaches(auth.uid(), subject_id));

create policy "read attendance" on public.attendance for select to authenticated
  using (public.has_role(auth.uid(),'admin') or public.teaches(auth.uid(), subject_id) or student_id = public.my_student_id(auth.uid()));
create policy "write attendance" on public.attendance for all to authenticated
  using (public.has_role(auth.uid(),'admin') or public.teaches(auth.uid(), subject_id))
  with check (public.has_role(auth.uid(),'admin') or public.teaches(auth.uid(), subject_id));

create policy "admin reads all logs, others own" on public.activity_logs for select to authenticated
  using (public.has_role(auth.uid(),'admin') or (user_id = auth.uid() and public.is_active_user(auth.uid())));
create policy "insert own logs" on public.activity_logs for insert to authenticated
  with check (user_id = auth.uid() and public.is_active_user(auth.uid()));

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare v_email text := lower(btrim(coalesce(new.email,'')));
begin
  perform pg_advisory_xact_lock(hashtext('attendease_first_admin'));
  insert into public.profiles (id, full_name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', ''), v_email);
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  else
    insert into public.user_roles (user_id, role) values (new.id, 'student');
  end if;
  update public.students set user_id = new.id where lower(btrim(email)) = v_email and user_id is null;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.link_student_account() returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.email := lower(btrim(new.email));
  new.student_number := upper(btrim(new.student_number));
  if tg_op = 'INSERT' or new.email is distinct from old.email then
    select p.id into new.user_id from public.profiles p where lower(btrim(p.email)) = new.email limit 1;
  end if;
  return new;
end $$;
create trigger link_student_account before insert or update on public.students for each row execute function public.link_student_account();

create or replace function public.set_user_role(_user_id uuid, _role public.app_role)
returns void language plpgsql security definer set search_path = public as $$
declare v_name text;
begin
  if not public.has_role(auth.uid(), 'admin') then
    raise exception 'Only administrators can change roles';
  end if;
  if _user_id = auth.uid() then
    raise exception 'You cannot change your own role';
  end if;
  delete from public.user_roles where user_id = _user_id and role <> _role;
  insert into public.user_roles (user_id, role) values (_user_id, _role) on conflict (user_id, role) do nothing;
  select coalesce(nullif(full_name,''), email) into v_name from public.profiles where id = _user_id;
  insert into public.activity_logs (user_id, action, entity, details)
  values (auth.uid(), 'changed role', 'user', coalesce(v_name,'user') || ' → ' || _role::text);
end $$;
revoke all on function public.set_user_role(uuid, public.app_role) from public, anon;
grant execute on function public.set_user_role(uuid, public.app_role) to authenticated;

create or replace function public.set_user_active(_user_id uuid, _active boolean)
returns void language plpgsql security definer set search_path = public as $$
declare v_name text;
begin
  if not public.has_role(auth.uid(), 'admin') then
    raise exception 'Only administrators can change account status';
  end if;
  if _user_id = auth.uid() then
    raise exception 'You cannot deactivate your own account';
  end if;
  update public.profiles set is_active = _active where id = _user_id returning coalesce(nullif(full_name,''), email) into v_name;
  insert into public.activity_logs (user_id, action, entity, details)
  values (auth.uid(), case when _active then 'activated' else 'deactivated' end, 'user', coalesce(v_name,'user'));
end $$;
revoke all on function public.set_user_active(uuid, boolean) from public, anon;
grant execute on function public.set_user_active(uuid, boolean) to authenticated;

create or replace function public.my_enrolled_faculty()
returns table (id uuid, full_name text, avatar_url text)
language sql stable security definer set search_path to public as $$
  select distinct p.id, p.full_name, p.avatar_url
  from public.profiles p
  join public.subjects s on s.faculty_id = p.id
  join public.enrollments e on e.subject_id = s.id
  join public.students st on st.id = e.student_id
  where st.user_id = auth.uid() and public.is_active_user(auth.uid())
$$;
revoke all on function public.my_enrolled_faculty() from public, anon;
grant execute on function public.my_enrolled_faculty() to authenticated;

insert into public.subjects (subject_code, subject_name, schedule_day, schedule_time, room) values
 ('IT101','Introduction to Computing','Monday','08:00','CL-1'),
 ('IT202','Data Structures and Algorithms','Tuesday','10:00','CL-2'),
 ('ED110','Foundations of Education','Wednesday','13:00','RM-204'),
 ('BA120','Principles of Management','Thursday','09:00','RM-301');

insert into public.students (student_number, first_name, last_name, email, program, year_level, section) values
 ('2026-0001','Juan','Dela Cruz','juan.delacruz@student.sorsu.edu.ph','BSIT',1,'A'),
 ('2026-0002','Maria','Santos','maria.santos@student.sorsu.edu.ph','BSIT',1,'A'),
 ('2026-0003','Jose','Reyes','jose.reyes@student.sorsu.edu.ph','BSIT',2,'B'),
 ('2026-0004','Ana','Garcia','ana.garcia@student.sorsu.edu.ph','BSED',1,'A'),
 ('2026-0005','Pedro','Lim','pedro.lim@student.sorsu.edu.ph','BSED',2,'A'),
 ('2026-0006','Carmela','Bautista','carmela.bautista@student.sorsu.edu.ph','BSBA',1,'A'),
 ('2026-0007','Ramon','Villanueva','ramon.villanueva@student.sorsu.edu.ph','BSBA',3,'B'),
 ('2026-0008','Liza','Mendoza','liza.mendoza@student.sorsu.edu.ph','BSIT',2,'B');

insert into public.enrollments (student_id, subject_id)
select s.id, sub.id from public.students s join public.subjects sub on
  (s.program='BSIT' and sub.subject_code in ('IT101','IT202')) or
  (s.program='BSED' and sub.subject_code='ED110') or
  (s.program='BSBA' and sub.subject_code in ('BA120','IT101'));

insert into public.attendance (student_id, subject_id, attendance_date, status)
select e.student_id, e.subject_id, ((now() at time zone 'Asia/Manila')::date - (w * 7 + 1))::date,
  (array['present','present','present','late','present','absent','present','excused','present','late']::public.attendance_status[])
  [1 + (abs(hashtext(e.id::text || w::text)) % 10)]
from public.enrollments e cross join generate_series(0, 3) w;

create policy "Signed-in users read avatars" on storage.objects for select to authenticated using (bucket_id = 'avatars');
create policy "Users upload own avatar" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users update own avatar" on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users delete own avatar" on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create table public.excuse_requests (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  request_date date not null,
  reason text not null check (length(btrim(reason)) between 3 and 1000),
  file_path text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  review_note text,
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now()
);
create unique index excuse_requests_one_pending on public.excuse_requests (student_id, subject_id, request_date) where status = 'pending';
create index excuse_requests_subject_idx on public.excuse_requests (subject_id, status);
create index excuse_requests_file_idx on public.excuse_requests (file_path);
grant select, insert, delete on public.excuse_requests to authenticated;
grant all on public.excuse_requests to service_role;
alter table public.excuse_requests enable row level security;

create policy "read own, taught or admin excuse requests" on public.excuse_requests for select to authenticated
  using (student_id = public.my_student_id(auth.uid()) or public.teaches(auth.uid(), subject_id) or public.has_role(auth.uid(),'admin'));
create policy "students submit own pending requests" on public.excuse_requests for insert to authenticated
  with check (
    student_id = public.my_student_id(auth.uid())
    and status = 'pending' and reviewed_by is null and reviewed_at is null and review_note is null
    and created_by = auth.uid()
    and (file_path is null or split_part(file_path, '/', 1) = auth.uid()::text)
    and exists (select 1 from public.enrollments e where e.student_id = excuse_requests.student_id and e.subject_id = excuse_requests.subject_id)
  );
create policy "students cancel own pending requests" on public.excuse_requests for delete to authenticated
  using (status = 'pending' and student_id = public.my_student_id(auth.uid()));

create or replace function public.validate_excuse_request() returns trigger language plpgsql set search_path = public as $$
declare today date := (now() at time zone 'Asia/Manila')::date;
begin
  if new.request_date > today then raise exception 'The excuse date cannot be in the future.'; end if;
  if new.request_date < today - 30 then raise exception 'The excuse date must be within the last 30 days.'; end if;
  if not exists (select 1 from public.enrollments e where e.student_id = new.student_id and e.subject_id = new.subject_id) then
    raise exception 'You are not enrolled in this subject.';
  end if;
  return new;
end $$;
create trigger validate_excuse_request before insert on public.excuse_requests for each row execute function public.validate_excuse_request();

create or replace function public.review_excuse_request(_id uuid, _approve boolean, _note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r public.excuse_requests; prev public.attendance_status; v_details text;
begin
  select * into r from public.excuse_requests where id = _id for update;
  if r.id is null then raise exception 'Request not found'; end if;
  if not (public.teaches(auth.uid(), r.subject_id) or public.has_role(auth.uid(),'admin')) then
    raise exception 'Only the subject''s faculty or an admin can review this request';
  end if;
  if r.status <> 'pending' then raise exception 'This request was already reviewed'; end if;
  if not _approve and coalesce(btrim(_note),'') = '' then raise exception 'A note is required when rejecting'; end if;
  select status into prev from public.attendance where student_id = r.student_id and subject_id = r.subject_id and attendance_date = r.request_date;
  update public.excuse_requests set status = case when _approve then 'approved' else 'rejected' end,
    review_note = nullif(btrim(coalesce(_note,'')),''), reviewed_by = auth.uid(), reviewed_at = now() where id = _id;
  if _approve then
    insert into public.attendance (student_id, subject_id, attendance_date, status, remarks, recorded_by)
    values (r.student_id, r.subject_id, r.request_date, 'excused', left('Excuse: ' || r.reason, 500), auth.uid())
    on conflict (student_id, subject_id, attendance_date)
    do update set status = 'excused', remarks = excluded.remarks, recorded_by = excluded.recorded_by;
  end if;
  v_details := r.request_date::text;
  if _approve and prev is not null and prev <> 'excused' then
    v_details := v_details || ' (previous status: ' || prev::text || ' → excused)';
  end if;
  insert into public.activity_logs (user_id, action, entity, details)
  values (auth.uid(), case when _approve then 'approved' else 'rejected' end, 'excuse request', v_details);
end $$;
revoke all on function public.review_excuse_request(uuid, boolean, text) from public, anon;
grant execute on function public.review_excuse_request(uuid, boolean, text) to authenticated;

create or replace function public.activity_actions() returns setof text
language sql stable security definer set search_path = public as $$
  select distinct action from public.activity_logs where public.has_role(auth.uid(),'admin') order by 1
$$;
revoke all on function public.activity_actions() from public, anon;
grant execute on function public.activity_actions() to authenticated;

create policy "Owner reads own excuse files" on storage.objects for select to authenticated
  using (bucket_id = 'excuse-files' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Reviewers read excuse files" on storage.objects for select to authenticated
  using (bucket_id = 'excuse-files' and exists (
    select 1 from public.excuse_requests er
    where er.file_path = storage.objects.name
      and (er.student_id = public.my_student_id(auth.uid()) or public.teaches(auth.uid(), er.subject_id) or public.has_role(auth.uid(),'admin'))
  ));
create policy "Owner uploads own excuse files" on storage.objects for insert to authenticated
  with check (bucket_id = 'excuse-files' and (storage.foldername(name))[1] = auth.uid()::text
    and lower(storage.extension(name)) in ('pdf','jpg','jpeg','png','webp'));
create policy "Owner deletes own excuse files" on storage.objects for delete to authenticated
  using (bucket_id = 'excuse-files' and (storage.foldername(name))[1] = auth.uid()::text);