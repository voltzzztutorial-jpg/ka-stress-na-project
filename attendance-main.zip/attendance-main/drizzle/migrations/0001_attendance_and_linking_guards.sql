-- 1. Block student re-linking: on UPDATE without an email change, keep the existing user_id
CREATE OR REPLACE FUNCTION public.link_student_account()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  new.email := lower(btrim(new.email));
  new.student_number := upper(btrim(new.student_number));
  if tg_op = 'INSERT' or new.email is distinct from old.email then
    select p.id into new.user_id from public.profiles p where lower(btrim(p.email)) = new.email limit 1;
  else
    -- Email unchanged: never let a direct UPDATE move the linked account.
    new.user_id := old.user_id;
  end if;
  return new;
end $function$;

-- 2a. Only link students after email confirmation
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_email text := lower(btrim(coalesce(new.email,'')));
begin
  perform pg_advisory_xact_lock(hashtext('attendease_first_admin'));
  insert into public.profiles (id, full_name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', ''), v_email);
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  else
    insert into public.user_roles (user_id, role) values (new.id, 'student');
  end if;
  if new.email_confirmed_at is not null then
    update public.students set user_id = new.id where lower(btrim(email)) = v_email and user_id is null;
  end if;
  return new;
end $function$;

-- 2b. Link the student record once the email becomes confirmed
CREATE OR REPLACE FUNCTION public.link_student_on_confirm()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if new.email_confirmed_at is not null and old.email_confirmed_at is null then
    update public.students set user_id = new.id
    where lower(btrim(email)) = lower(btrim(coalesce(new.email,''))) and user_id is null;
  end if;
  return new;
end $function$;

CREATE TRIGGER on_auth_user_email_confirmed
  AFTER UPDATE OF email_confirmed_at ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.link_student_on_confirm();

-- 3. Enforce attendance rules in the database: enrolled students only, no future dates
CREATE OR REPLACE FUNCTION public.validate_attendance()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
begin
  if not exists (select 1 from public.enrollments e where e.student_id = new.student_id and e.subject_id = new.subject_id) then
    raise exception 'Student is not enrolled in this subject.';
  end if;
  if new.attendance_date > (now() at time zone 'Asia/Manila')::date then
    raise exception 'Attendance date cannot be in the future.';
  end if;
  return new;
end $function$;

CREATE TRIGGER validate_attendance
  BEFORE INSERT OR UPDATE ON public.attendance
  FOR EACH ROW EXECUTE FUNCTION public.validate_attendance();

-- 15. Excuse files can only be deleted while the referencing request is still pending
DROP POLICY IF EXISTS "Owner deletes own excuse files" ON storage.objects;
CREATE POLICY "Owner deletes own excuse files" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'excuse-files'
    AND (storage.foldername(name))[1] = (auth.uid())::text
    AND NOT EXISTS (
      SELECT 1 FROM public.excuse_requests er
      WHERE er.file_path = objects.name AND er.status <> 'pending'
    )
  );