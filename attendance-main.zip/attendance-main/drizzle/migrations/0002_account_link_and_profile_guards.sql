CREATE OR REPLACE FUNCTION public.link_student_account()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  NEW.email := lower(btrim(NEW.email));
  NEW.student_number := upper(btrim(NEW.student_number));
  -- Only the admin-authorized RPC deliberately opts out of automatic linking.
  -- The setting alone never grants access: an active admin is also required.
  IF TG_OP = 'UPDATE' AND public.has_role(auth.uid(), 'admin')
     AND current_setting('attendease.relink_student', true) = NEW.id::text THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'UPDATE' AND OLD.user_id IS NOT NULL THEN
    NEW.user_id := OLD.user_id;
    RETURN NEW;
  END IF;
  NEW.user_id := NULL;
  SELECT p.id INTO NEW.user_id FROM public.profiles p
    JOIN auth.users u ON u.id = p.id
    WHERE lower(btrim(p.email)) = NEW.email AND u.email_confirmed_at IS NOT NULL
    ORDER BY p.id LIMIT 1;
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.relink_student(_student_id uuid, _user_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE previous_setting text;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only administrators can relink students';
  END IF;
  IF _user_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.profiles p JOIN auth.users u ON u.id = p.id
    WHERE p.id = _user_id AND u.email_confirmed_at IS NOT NULL
  ) THEN RAISE EXCEPTION 'Account must exist and have a confirmed email'; END IF;
  previous_setting := current_setting('attendease.relink_student', true);
  PERFORM set_config('attendease.relink_student', _student_id::text, true);
  UPDATE public.students SET user_id = _user_id WHERE id = _student_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Student not found'; END IF;
  PERFORM set_config('attendease.relink_student', coalesce(previous_setting, ''), true);
  INSERT INTO public.activity_logs(user_id, action, entity, details)
    VALUES(auth.uid(), 'relinked', 'student', _student_id::text || ' → ' || coalesce(_user_id::text, 'unlinked'));
END $$;
REVOKE ALL ON FUNCTION public.relink_student(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.relink_student(uuid, uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.guard_profile()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF auth.uid() IS NOT NULL THEN
    IF NEW.avatar_url IS NOT NULL AND NEW.avatar_url NOT LIKE NEW.id::text || '/%' THEN
      RAISE EXCEPTION 'Invalid avatar path';
    END IF;
    IF NOT public.has_role(auth.uid(), 'admin') THEN
      NEW.is_active := OLD.is_active;
      -- Nested Auth lifecycle synchronization may copy only the actual Auth email.
      IF NOT (pg_trigger_depth() > 1 AND EXISTS (
        SELECT 1 FROM auth.users u WHERE u.id = NEW.id
        AND lower(btrim(coalesce(u.email, ''))) = lower(btrim(NEW.email))
      )) THEN NEW.email := OLD.email; END IF;
    END IF;
  END IF;
  NEW.email := lower(btrim(NEW.email));
  IF OLD.is_active AND NOT NEW.is_active THEN
    PERFORM pg_advisory_xact_lock(hashtext('attendease_last_active_admin'));
    IF EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = OLD.id AND role = 'admin')
      AND NOT EXISTS (SELECT 1 FROM public.user_roles r JOIN public.profiles p ON p.id = r.user_id
        WHERE r.role = 'admin' AND p.is_active AND p.id <> OLD.id) THEN
      RAISE EXCEPTION 'Cannot deactivate the last active administrator';
    END IF;
  END IF;
  RETURN NEW;
END $$;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'public.profiles'::regclass AND conname = 'profiles_avatar_url_not_http') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_avatar_url_not_http
      CHECK (avatar_url IS NULL OR avatar_url NOT LIKE 'http%');
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.guard_last_active_admin_role()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE removing boolean;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('attendease_last_active_admin'));
  IF TG_OP = 'DELETE' THEN removing := true;
  ELSE removing := NEW.role IS DISTINCT FROM 'admin' OR NEW.user_id IS DISTINCT FROM OLD.user_id; END IF;
  IF OLD.role = 'admin' AND removing
    AND EXISTS (SELECT 1 FROM public.profiles WHERE id = OLD.user_id AND is_active)
    AND NOT EXISTS (SELECT 1 FROM public.user_roles r JOIN public.profiles p ON p.id = r.user_id
      WHERE r.role = 'admin' AND p.is_active AND r.user_id <> OLD.user_id) THEN
    RAISE EXCEPTION 'Cannot remove or demote the last active administrator';
  END IF;
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS guard_last_active_admin_role ON public.user_roles;
CREATE TRIGGER guard_last_active_admin_role BEFORE UPDATE OR DELETE ON public.user_roles
FOR EACH ROW EXECUTE FUNCTION public.guard_last_active_admin_role();

CREATE OR REPLACE FUNCTION public.set_user_role(_user_id uuid, _role public.app_role)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE v_name text;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('attendease_last_active_admin'));
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Only administrators can change roles'; END IF;
  IF _user_id = auth.uid() THEN RAISE EXCEPTION 'You cannot change your own role'; END IF;
  DELETE FROM public.user_roles WHERE user_id = _user_id AND role <> _role;
  INSERT INTO public.user_roles(user_id, role) VALUES(_user_id, _role) ON CONFLICT(user_id, role) DO NOTHING;
  SELECT coalesce(nullif(full_name,''), email) INTO v_name FROM public.profiles WHERE id = _user_id;
  INSERT INTO public.activity_logs(user_id, action, entity, details)
    VALUES(auth.uid(), 'changed role', 'user', coalesce(v_name,'user') || ' → ' || _role::text);
END $$;
REVOKE ALL ON FUNCTION public.set_user_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_user_role(uuid, public.app_role) TO authenticated;

CREATE OR REPLACE FUNCTION public.set_user_active(_user_id uuid, _active boolean)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE v_name text;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('attendease_last_active_admin'));
  IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Only administrators can change account status'; END IF;
  IF _user_id = auth.uid() THEN RAISE EXCEPTION 'You cannot deactivate your own account'; END IF;
  UPDATE public.profiles SET is_active = _active WHERE id = _user_id
    RETURNING coalesce(nullif(full_name,''), email) INTO v_name;
  INSERT INTO public.activity_logs(user_id, action, entity, details)
    VALUES(auth.uid(), CASE WHEN _active THEN 'activated' ELSE 'deactivated' END, 'user', coalesce(v_name,'user'));
END $$;
REVOKE ALL ON FUNCTION public.set_user_active(uuid, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_user_active(uuid, boolean) TO authenticated;

CREATE OR REPLACE FUNCTION public.sync_auth_email_to_profile()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF NEW.email IS DISTINCT FROM OLD.email THEN
    UPDATE public.profiles SET email = lower(btrim(coalesce(NEW.email, ''))) WHERE id = NEW.id;
    IF NEW.email_confirmed_at IS NOT NULL THEN
      UPDATE public.students SET user_id = NEW.id
      WHERE user_id IS NULL AND lower(btrim(email)) = lower(btrim(coalesce(NEW.email, '')));
    END IF;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS sync_auth_email_to_profile ON auth.users;
CREATE TRIGGER sync_auth_email_to_profile AFTER UPDATE OF email ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.sync_auth_email_to_profile();

CREATE OR REPLACE FUNCTION public.validate_attendance()
RETURNS trigger LANGUAGE plpgsql SET search_path TO 'public' AS $$
DECLARE needs_enrollment boolean;
BEGIN
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  IF TG_OP = 'INSERT' THEN needs_enrollment := true;
  ELSE needs_enrollment := NEW.student_id IS DISTINCT FROM OLD.student_id OR NEW.subject_id IS DISTINCT FROM OLD.subject_id; END IF;
  IF needs_enrollment AND NOT EXISTS (SELECT 1 FROM public.enrollments e
    WHERE e.student_id = NEW.student_id AND e.subject_id = NEW.subject_id) THEN
    RAISE EXCEPTION 'Student is not enrolled in this subject.';
  END IF;
  IF NEW.attendance_date > (now() AT TIME ZONE 'Asia/Manila')::date THEN
    RAISE EXCEPTION 'Attendance date cannot be in the future.';
  END IF;
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.review_excuse_request(_id uuid, _approve boolean, _note text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE r public.excuse_requests; prev public.attendance_status; v_details text;
BEGIN
  SELECT * INTO r FROM public.excuse_requests WHERE id = _id FOR UPDATE;
  IF r.id IS NULL THEN RAISE EXCEPTION 'Request not found'; END IF;
  IF NOT (public.teaches(auth.uid(), r.subject_id) OR public.has_role(auth.uid(),'admin')) THEN
    RAISE EXCEPTION 'Only the subject''s faculty or an admin can review this request';
  END IF;
  IF r.status <> 'pending' THEN RAISE EXCEPTION 'This request was already reviewed'; END IF;
  IF NOT _approve AND coalesce(btrim(_note),'') = '' THEN RAISE EXCEPTION 'A note is required when rejecting'; END IF;
  IF _approve AND NOT EXISTS (SELECT 1 FROM public.enrollments e WHERE e.student_id = r.student_id AND e.subject_id = r.subject_id) THEN
    RAISE EXCEPTION 'Student is no longer enrolled in this subject.';
  END IF;
  SELECT status INTO prev FROM public.attendance WHERE student_id = r.student_id AND subject_id = r.subject_id AND attendance_date = r.request_date;
  UPDATE public.excuse_requests SET status = CASE WHEN _approve THEN 'approved' ELSE 'rejected' END,
    review_note = nullif(btrim(coalesce(_note,'')),''), reviewed_by = auth.uid(), reviewed_at = now() WHERE id = _id;
  IF _approve THEN
    INSERT INTO public.attendance(student_id, subject_id, attendance_date, status, remarks, recorded_by)
    VALUES(r.student_id, r.subject_id, r.request_date, 'excused', left('Excuse: ' || r.reason, 500), auth.uid())
    ON CONFLICT(student_id, subject_id, attendance_date) DO UPDATE SET status = 'excused', remarks = excluded.remarks, recorded_by = excluded.recorded_by;
  END IF;
  v_details := r.request_date::text;
  IF _approve AND prev IS NOT NULL AND prev <> 'excused' THEN
    v_details := v_details || ' (previous status: ' || prev::text || ' → excused)';
  END IF;
  INSERT INTO public.activity_logs(user_id, action, entity, details)
    VALUES(auth.uid(), CASE WHEN _approve THEN 'approved' ELSE 'rejected' END, 'excuse request', v_details);
END $$;

DROP POLICY IF EXISTS "insert own logs" ON public.activity_logs;
CREATE POLICY "insert own logs" ON public.activity_logs FOR INSERT TO authenticated
WITH CHECK(user_id = auth.uid() AND public.is_active_user(auth.uid()) AND action IN (
  'deleted', 'updated', 'created', 'enrolled', 'bulk enrolled', 'archived', 'restored', 'added', 'recorded',
  'changed role', 'activated', 'deactivated', 'approved', 'rejected', 'relinked'
));
DROP POLICY IF EXISTS "Users upload own avatar" ON storage.objects;
CREATE POLICY "Users upload own avatar" ON storage.objects FOR INSERT TO authenticated
WITH CHECK(bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text
  AND lower(storage.extension(name)) IN ('png','jpg','jpeg','webp'));
DROP POLICY IF EXISTS "Users update own avatar" ON storage.objects;
CREATE POLICY "Users update own avatar" ON storage.objects FOR UPDATE TO authenticated
USING(bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text)
WITH CHECK(bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text
  AND lower(storage.extension(name)) IN ('png','jpg','jpeg','webp'));