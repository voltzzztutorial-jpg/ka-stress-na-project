import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { daysAgo, localDate } from "@/lib/attendance";
import { lowestRisk } from "@/lib/student-workflows";
import { fetchAllPages, MAX_ROWS } from "@/lib/paging";
import { Card, EmptyState, Loading } from "@/components/shared";
import { StudentAvatar } from "@/components/UserAvatar";
import { Button } from "@/components/ui/button";
export function StaffClassActions() {
  const { data: auth } = useAuth();
  const date = localDate();
  const weekday = new Date(`${date}T12:00:00`).toLocaleDateString("en-US", { weekday: "long" });
  const q = useQuery({
    queryKey: ["staff-class-actions", auth?.user.id, auth?.role, date],
    enabled: !!auth,
    queryFn: async () => {
      let query = supabase
        .from("subjects")
        .select("id,subject_code,subject_name,schedule_day,schedule_time,room");
      if (auth?.role === "faculty") query = query.eq("faculty_id", auth.user.id);
      const { data: subjects, error } = await query;
      if (error) throw error;
      const ids = (subjects ?? []).map((s) => s.id);
      if (!ids.length) return { subjects: subjects ?? [], rows: [], truncated: false };
      const since = daysAgo(120);
      const result = await fetchAllPages((from, to) => {
        return supabase
          .from("attendance")
          .select(
            "id,student_id,subject_id,attendance_date,status,students(first_name,last_name,status,user_id,profile:profiles!students_user_id_fkey(avatar_url,updated_at))",
          )
          .in("subject_id", ids)
          .gte("attendance_date", since)
          .order("id")
          .range(from, to);
      });
      return { subjects: subjects ?? [], rows: result.rows, truncated: result.truncated };
    },
  });
  const classes = q.data?.subjects.filter((s) => s.schedule_day === weekday) ?? [];
  const risk = lowestRisk((q.data?.rows ?? []).filter((r) => r.students?.status === "active"));
  const errorState = (
    <div role="alert" className="space-y-3 py-4">
      <p className="text-sm text-destructive">Couldn't load this section. Try again.</p>
      <Button size="sm" variant="outline" onClick={() => q.refetch()}>
        Try again
      </Button>
    </div>
  );
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card title="Today's classes">
        {q.isError ? (
          errorState
        ) : q.isLoading ? (
          <Loading />
        ) : !classes.length ? (
          <EmptyState text="No classes scheduled today" />
        ) : (
          <ul className="divide-y">
            {classes.map((s) => {
              const taken = q.data?.rows.some(
                (r) => r.subject_id === s.id && r.attendance_date === date,
              );
              return (
                <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                  <div>
                    <p className="font-medium">
                      {s.subject_code} · {s.subject_name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {s.schedule_time} · {s.room} · {taken ? "Attendance taken" : "Not taken yet"}
                    </p>
                  </div>
                  <Button asChild size="sm" variant="outline">
                    <Link to="/attendance" search={{ subject: s.id, date }}>
                      Mark attendance
                    </Link>
                  </Button>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
      <Card
        title="Students at risk (below 75%)"
        action={
          <Link to="/reports" className="text-xs font-medium text-primary">
            Reports
          </Link>
        }
      >
        {q.data?.truncated && (
          <p role="status" className="text-sm text-late">
            Showing the first {MAX_ROWS.toLocaleString()} records only.
          </p>
        )}
        {q.isError ? (
          errorState
        ) : q.isLoading ? (
          <Loading />
        ) : !risk.length ? (
          <EmptyState text="No students at risk" />
        ) : (
          <ul className="divide-y">
            {risk.map((r) => {
              const student = r.row.students;
              const name = student ? `${student.first_name} ${student.last_name}` : "Student";
              const subject = q.data?.subjects.find((s) => s.id === r.row.subject_id);
              return (
                <li
                  key={`${r.row.student_id}:${r.row.subject_id}`}
                  className="flex items-center gap-3 py-3"
                >
                  <StudentAvatar
                    name={name}
                    profile={student?.profile}
                    linked={!!student?.user_id}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{name}</p>
                    <p className="text-xs text-muted-foreground">
                      {subject?.subject_code} · {r.total} records
                    </p>
                  </div>
                  <strong className="text-sm text-absent">{r.rate}%</strong>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
