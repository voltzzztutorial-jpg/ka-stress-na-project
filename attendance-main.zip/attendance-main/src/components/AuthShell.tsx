import { useEffect, type ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";
import { Logo } from "@/components/shared";

export function AuthShell({
  title,
  subtitle,
  children,
  allowSignedIn,
}: {
  title: string;
  subtitle: string;
  children: ReactNode;
  allowSignedIn?: boolean;
}) {
  const { data: auth } = useAuth();
  const navigate = useNavigate();
  useEffect(() => {
    if (auth && !allowSignedIn) navigate({ to: "/dashboard", replace: true });
  }, [auth, allowSignedIn, navigate]);
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="bg-hero hidden flex-col justify-between p-10 text-primary-foreground lg:flex">
        <Link to="/">
          <Logo light />
        </Link>
        <div>
          <h2 className="text-3xl font-bold">Sorsogon State University</h2>
          <p className="mt-1 opacity-80">Bulan Campus · Student Attendance Management</p>
        </div>
      </div>
      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <Link to="/" className="mb-8 inline-block text-primary lg:hidden">
            <Logo />
          </Link>
          <h1 className="text-2xl font-bold">{title}</h1>
          <p className="mt-1 mb-6 text-sm text-muted-foreground">{subtitle}</p>
          {children}
        </div>
      </div>
    </div>
  );
}
