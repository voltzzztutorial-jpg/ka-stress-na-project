import { useEnrolledClasses } from "@/lib/my-classes";
import { UserAvatar } from "@/components/UserAvatar";
export function StudentFacultyList() {
  const q = useEnrolledClasses();
  if (!q.data?.subjects.length) return null;
  return (
    <div className="flex flex-wrap gap-4">
      {q.data.subjects.map((s) => {
        const faculty = q.data.faculty.find((f) => f.id === s.faculty_id);
        return (
          <div key={s.id} className="flex items-center gap-2 text-sm">
            <UserAvatar
              name={faculty?.full_name || "Unassigned"}
              avatarUrl={faculty?.avatar_url}
              size="xs"
            />
            <span>
              {s.subject_code} · {faculty?.full_name || "Unassigned"}
            </span>
          </div>
        );
      })}
    </div>
  );
}
