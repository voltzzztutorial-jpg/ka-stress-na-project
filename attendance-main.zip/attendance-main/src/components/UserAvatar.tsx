import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useAvatarUrl, avatarTone, type AvatarProfile } from "@/lib/avatar";
import { cn } from "@/lib/utils";

const sizes = {
  xs: "size-6 text-[10px]",
  sm: "size-8 text-xs",
  md: "size-10 text-sm",
  lg: "size-20 text-xl",
};
const tones = [
  "bg-primary/15 text-primary",
  "bg-present/15 text-present",
  "bg-excused/15 text-excused",
  "bg-late/20 text-foreground",
];
export function UserAvatar({
  avatarUrl,
  name,
  size = "md",
  version,
  className,
}: {
  avatarUrl?: string | null;
  name: string;
  size?: keyof typeof sizes;
  version?: string | number;
  className?: string;
}) {
  const initials =
    name
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0])
      .join("")
      .toUpperCase() || "?";
  const src = useAvatarUrl(avatarUrl, version);
  return (
    <Avatar className={cn(sizes[size], className)}>
      <AvatarImage src={src} alt={name} loading="lazy" className="object-cover" />
      <AvatarFallback className={cn("font-semibold", tones[avatarTone(name)])}>
        {initials}
      </AvatarFallback>
    </Avatar>
  );
}

export function StudentAvatar({
  name,
  profile,
  linked,
  preview,
  number,
  size = "sm",
}: {
  name: string;
  profile?: AvatarProfile | null;
  linked?: boolean;
  preview?: boolean;
  number?: string;
  size?: keyof typeof sizes;
}) {
  const [open, setOpen] = useState(false);
  const image = (
    <UserAvatar
      name={name}
      avatarUrl={profile?.avatar_url}
      version={profile?.updated_at}
      size={size}
    />
  );
  const trigger = preview ? (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      className="h-auto w-auto shrink-0 rounded-full p-0"
      aria-label={`Preview photo of ${name}`}
      onClick={() => setOpen(true)}
    >
      {image}
    </Button>
  ) : (
    <span className="inline-flex shrink-0" tabIndex={linked === false ? 0 : undefined}>
      {image}
    </span>
  );
  return (
    <>
      {linked === false ? (
        <Tooltip>
          <TooltipTrigger asChild>{trigger}</TooltipTrigger>
          <TooltipContent>No account linked yet</TooltipContent>
        </Tooltip>
      ) : (
        trigger
      )}
      {preview && (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle>{name}</DialogTitle>
            </DialogHeader>
            <UserAvatar
              name={name}
              avatarUrl={profile?.avatar_url}
              version={profile?.updated_at}
              size="lg"
              className="mx-auto size-56 text-5xl"
            />
            {number && (
              <p className="text-center font-mono text-sm text-muted-foreground">{number}</p>
            )}
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
