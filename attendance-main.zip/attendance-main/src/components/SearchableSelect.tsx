import { type ReactNode, useId, useRef, useState } from "react";
import { Check, ChevronsUpDown, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { matchesSearch } from "@/lib/select-options";
import { cn } from "@/lib/utils";

export type SearchableOption = {
  value: string;
  label: string;
  description?: string;
  searchText?: string;
  leading?: ReactNode;
};
type Props = {
  value: string;
  onValueChange: (value: string) => void;
  options: SearchableOption[];
  noneOption?: SearchableOption;
  placeholder?: string;
  searchPlaceholder?: string;
  loading?: boolean;
  disabled?: boolean;
  className?: string;
  id?: string;
  "aria-label"?: string;
};

export function SearchableSelect({
  value,
  onValueChange,
  options,
  noneOption,
  placeholder = "Select an option",
  searchPlaceholder = "Search…",
  loading,
  disabled,
  className,
  id,
  "aria-label": ariaLabel,
}: Props) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const input = useRef<HTMLInputElement>(null);
  const listId = useId();
  const selected =
    noneOption?.value === value ? noneOption : options.find((option) => option.value === value);
  const visible = options.filter((option) =>
    matchesSearch(`${option.label} ${option.description ?? ""} ${option.searchText ?? ""}`, search),
  );
  const choose = (next: string) => {
    onValueChange(next);
    setOpen(false);
  };
  const item = (option: SearchableOption) => (
    <CommandItem
      key={option.value}
      value={option.value}
      onSelect={() => choose(option.value)}
      className="min-h-11"
    >
      <Check className={cn("shrink-0", value === option.value ? "opacity-100" : "opacity-0")} />
      {option.leading}
      <span className="min-w-0 flex-1 break-words">
        <span className="block">{option.label}</span>
        {option.description && (
          <span className="block text-xs text-muted-foreground">{option.description}</span>
        )}
      </span>
    </CommandItem>
  );
  return (
    <Popover
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (next) setSearch("");
      }}
    >
      <PopoverTrigger asChild>
        <Button
          id={id}
          type="button"
          variant="outline"
          role="combobox"
          aria-label={ariaLabel}
          aria-expanded={open}
          aria-controls={open ? listId : undefined}
          disabled={disabled}
          className={cn("w-full min-w-0 justify-between font-normal", className)}
        >
          <span className={cn("min-w-0 truncate", !selected && "text-muted-foreground")}>
            {selected?.label ?? placeholder}
          </span>
          {loading ? (
            <Loader2 className="shrink-0 animate-spin" />
          ) : (
            <ChevronsUpDown className="shrink-0 opacity-50" />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        align="start"
        className="w-[var(--radix-popover-trigger-width)] max-w-[calc(100vw-2rem)] p-0"
        onOpenAutoFocus={(event) => {
          event.preventDefault();
          input.current?.focus();
        }}
      >
        <Command shouldFilter={false} loop>
          <CommandInput
            ref={input}
            aria-label={searchPlaceholder}
            placeholder={searchPlaceholder}
            value={search}
            onValueChange={setSearch}
          />
          <CommandList
            id={listId}
            className="max-h-[min(300px,var(--radix-popover-content-available-height))] overscroll-contain"
          >
            {loading ? (
              <div
                role="status"
                className="flex items-center justify-center gap-2 py-6 text-sm text-muted-foreground"
              >
                <Loader2 className="size-4 animate-spin" /> Loading…
              </div>
            ) : (
              <>
                {!visible.length && !noneOption && <CommandEmpty>No results found</CommandEmpty>}
                <CommandGroup>
                  {noneOption && item(noneOption)}
                  {visible.map(item)}
                </CommandGroup>
                {!visible.length && noneOption && (
                  <p role="status" className="py-4 text-center text-sm text-muted-foreground">
                    No results found
                  </p>
                )}
              </>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
