import { useEffect, useState, type ReactNode } from "react";
import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  BarChart3,
  BookOpen,
  ClipboardCheck,
  HelpCircle,
  History,
  LayoutDashboard,
  LogOut,
  Menu,
  Moon,
  Sun,
  UserCircle,
  Users,
  UserCog,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, type AppRole } from "@/lib/auth";
import { Logo, Loading } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { UserAvatar } from "@/components/UserAvatar";

type NavItem = { to: string; label: string; icon: typeof Users; roles: AppRole[] };
export const NAV: NavItem[] = [
  {
    to: "/dashboard",
    label: "Dashboard",
    icon: LayoutDashboard,
    roles: ["admin", "faculty", "student"],
  },
  { to: "/my-classes", label: "My classes", icon: BookOpen, roles: ["student"] },
  { to: "/students", label: "Students", icon: Users, roles: ["admin", "faculty"] },
  { to: "/subjects", label: "Subjects", icon: BookOpen, roles: ["admin", "faculty"] },
  { to: "/attendance", label: "Attendance", icon: ClipboardCheck, roles: ["admin", "faculty"] },
  { to: "/reports", label: "Reports", icon: BarChart3, roles: ["admin", "faculty"] },
  { to: "/users", label: "User Management", icon: UserCog, roles: ["admin"] },
  { to: "/activity", label: "Activity log", icon: History, roles: ["admin"] },
  { to: "/profile", label: "My Profile", icon: UserCircle, roles: ["admin", "faculty", "student"] },
  { to: "/help", label: "Help", icon: HelpCircle, roles: ["admin", "faculty", "student"] },
];

export function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => {
    const d = localStorage.getItem("theme") === "dark";
    setDark(d);
    document.documentElement.classList.toggle("dark", d);
  }, []);
  return (
    <Button
      variant="ghost"
      size="icon"
      aria-label="Toggle dark mode"
      onClick={() => {
        const d = !dark;
        setDark(d);
        localStorage.setItem("theme", d ? "dark" : "light");
        document.documentElement.classList.toggle("dark", d);
      }}
    >
      {dark ? <Sun /> : <Moon />}
    </Button>
  );
}

function NavLinks({ role, onNavigate }: { role: AppRole; onNavigate?: () => void }) {
  const { pathname } = useLocation();
  return (
    <nav className="flex flex-col gap-1">
      {NAV.filter((n) => n.roles.includes(role)).map((n) => {
        const active = pathname.startsWith(n.to);
        return (
          <Link
            key={n.to}
            to={n.to}
            onClick={onNavigate}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
              active
                ? "bg-sidebar-primary text-sidebar-primary-foreground"
                : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
            )}
          >
            <n.icon className="size-4" />
            {n.label}
          </Link>
        );
      })}
    </nav>
  );
}

export function AppLayout({ children }: { children: ReactNode }) {
  const { data: auth, isLoading, isError, refetch } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { pathname } = useLocation();
  const current = NAV.find((n) => pathname.startsWith(n.to));

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/login", replace: true });
  }

  if (isError) {
    return (
      <div className="mx-auto max-w-md py-24 text-center">
        <h1 className="text-xl font-semibold">Couldn't load your account</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          This may be a temporary connection problem.
        </p>
        <Button className="mt-6" onClick={() => refetch()}>
          Try again
        </Button>
      </div>
    );
  }
  if (isLoading || !auth) return <Loading />;
  if (auth.profile && !auth.profile.is_active) {
    return (
      <div className="mx-auto max-w-md py-24 text-center">
        <h1 className="text-xl font-semibold">Account deactivated</h1>
        <p className="mt-2 text-sm text-muted-foreground">Please contact your administrator.</p>
        <Button className="mt-6" onClick={signOut}>
          Sign out
        </Button>
      </div>
    );
  }

  const sidebar = (
    <div className="flex h-full flex-col gap-6 bg-sidebar p-4 text-sidebar-foreground">
      <Link to="/dashboard" className="px-2 pt-2 text-sidebar-accent-foreground">
        <Logo light />
      </Link>
      <NavLinks role={auth.role} onNavigate={() => setOpen(false)} />
      <div className="mt-auto rounded-lg bg-sidebar-accent p-3 text-sm">
        <div className="flex items-center gap-3">
          <UserAvatar
            name={auth.profile?.full_name || "Unnamed user"}
            avatarUrl={auth.profile?.avatar_url}
            version={auth.profile?.updated_at}
            size="sm"
          />
          <div className="min-w-0">
            <p className="truncate font-medium text-sidebar-accent-foreground">
              {auth.profile?.full_name || auth.user.email}
            </p>
            <p className="text-xs capitalize opacity-75">{auth.role}</p>
          </div>
        </div>
        <button
          onClick={signOut}
          className="mt-3 flex items-center gap-2 text-xs font-medium opacity-90 hover:opacity-100"
        >
          <LogOut className="size-3.5" /> Log out
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[260px_1fr]">
      <aside className="no-print sticky top-0 hidden h-screen lg:block">{sidebar}</aside>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent
          side="left"
          className="w-64 border-0 p-0"
          closeLabel="Close menu"
          closeButtonClassName="text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:bg-sidebar-accent focus-visible:text-sidebar-accent-foreground focus-visible:ring-sidebar-ring focus-visible:ring-offset-sidebar"
        >
          <SheetTitle className="sr-only">Navigation</SheetTitle>
          {sidebar}
        </SheetContent>
      </Sheet>
      <div className="min-w-0">
        <header className="no-print sticky top-0 z-20 flex h-14 items-center gap-3 border-b bg-background/85 px-4 backdrop-blur sm:px-6">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            aria-label="Open menu"
            onClick={() => setOpen(true)}
          >
            <Menu />
          </Button>
          <nav aria-label="Breadcrumb" className="text-sm text-muted-foreground">
            <Link to="/dashboard" className="hover:text-foreground">
              Home
            </Link>
            {current && current.to !== "/dashboard" && (
              <>
                <span className="mx-2">/</span>
                <span className="font-medium text-foreground">{current.label}</span>
              </>
            )}
          </nav>
          <div className="ml-auto flex items-center gap-1">
            <Link to="/profile" aria-label="My profile">
              <UserAvatar
                name={auth.profile?.full_name || "Unnamed user"}
                avatarUrl={auth.profile?.avatar_url}
                version={auth.profile?.updated_at}
                size="sm"
              />
            </Link>
            <ThemeToggle />
          </div>
        </header>
        <main className="mx-auto max-w-7xl p-4 sm:p-6 lg:p-8">{children}</main>
      </div>
    </div>
  );
}

export function RequireRole({ roles, children }: { roles: AppRole[]; children: ReactNode }) {
  const { data, isError, refetch } = useAuth();
  if (isError) {
    return (
      <div className="mx-auto max-w-md py-20 text-center">
        <h1 className="text-xl font-semibold">Couldn't verify your role</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          This may be a temporary connection problem.
        </p>
        <Button className="mt-6" onClick={() => refetch()}>
          Try again
        </Button>
      </div>
    );
  }
  if (!data) return <Loading />;
  if (!roles.includes(data.role)) {
    return (
      <div className="mx-auto max-w-md py-20 text-center">
        <p className="font-display text-6xl font-bold text-primary">403</p>
        <h1 className="mt-3 text-xl font-semibold">Access denied</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Your role doesn't have permission to view this page.
        </p>
        <Button asChild className="mt-6">
          <Link to="/dashboard">Back to dashboard</Link>
        </Button>
      </div>
    );
  }
  return <>{children}</>;
}
