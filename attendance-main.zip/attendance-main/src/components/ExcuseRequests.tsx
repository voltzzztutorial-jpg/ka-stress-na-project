import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, Loader2, Paperclip, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { errMsg, useAuth } from "@/lib/auth";
import { daysAgo, localDate } from "@/lib/attendance";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  EXCUSE_BUCKET,
  MAX_EXCUSE_AGE_DAYS,
  excuseDateError,
  excuseFileError,
  excuseReasonError,
} from "@/lib/excuse";
import { Card, EmptyState, Loading } from "@/components/shared";
import { SearchableSelect } from "@/components/SearchableSelect";
import { StudentAvatar } from "@/components/UserAvatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

type Subject = { id: string; subject_code: string; subject_name: string };

async function openAttachment(p: string) {
  const { data, error } = await supabase.storage.from(EXCUSE_BUCKET).createSignedUrl(p, 60);
  if (error) return toast.error("Couldn't open the attachment.");
  window.open(data.signedUrl, "_blank", "noopener");
}

function friendlyExcuseError(e: { message: string }): string {
  const m = e.message;
  if (m.includes("excuse_requests_one_pending"))
    return "You already have a pending request for that class and date.";
  if (m.includes("future") || m.includes("30 days") || m.includes("not enrolled"))
    return m.replace(/^.*?: /, "");
  return errMsg(e);
}

function StatusPill({ status }: { status: string }) {
  const variant =
    status === "approved" ? "default" : status === "rejected" ? "destructive" : "secondary";
  return (
    <Badge variant={variant} className="capitalize">
      {status}
    </Badge>
  );
}

/** Student side: submit an excuse request and see the status of past ones. */
export function StudentExcuseRequests({ subjects }: { subjects: Subject[] }) {
  const { data: auth } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [subject, setSubject] = useState("");
  const [date, setDate] = useState(() => localDate());
  const [reason, setReason] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const list = useQuery({
    queryKey: ["excuse-requests", "mine", auth?.user.id],
    enabled: !!auth,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("excuse_requests")
        .select(
          "id,request_date,reason,status,review_note,file_path,created_at,subjects(subject_code)",
        )
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  function reset() {
    setSubject("");
    setDate(localDate());
    setReason("");
    setFile(null);
    setErrors({});
  }

  async function submit() {
    if (!auth) return;
    const errs: Record<string, string> = {};
    if (!subject) errs.subject = "Choose a subject.";
    const d = excuseDateError(date, localDate(), daysAgo(MAX_EXCUSE_AGE_DAYS));
    if (d) errs.date = d;
    const r = excuseReasonError(reason);
    if (r) errs.reason = r;
    const f = excuseFileError(file);
    if (f) errs.file = f;
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setSaving(true);
    const { data: student, error: sErr } = await supabase
      .from("students")
      .select("id")
      .eq("user_id", auth.user.id)
      .maybeSingle();
    if (sErr || !student) {
      setSaving(false);
      return toast.error("Your account isn't linked to a student record.");
    }
    let path: string | null = null;
    if (file) {
      path = `${auth.user.id}/${crypto.randomUUID()}-${file.name.replace(/[^\w.-]/g, "_")}`;
      const { error } = await supabase.storage
        .from(EXCUSE_BUCKET)
        .upload(path, file, { contentType: file.type });
      if (error) {
        setSaving(false);
        return toast.error(errMsg(error));
      }
    }
    const { error } = await supabase.from("excuse_requests").insert({
      student_id: student.id,
      subject_id: subject,
      request_date: date,
      reason: reason.trim(),
      file_path: path,
      created_by: auth.user.id,
    });
    setSaving(false);
    if (error) {
      if (path) await supabase.storage.from(EXCUSE_BUCKET).remove([path]);
      return toast.error(friendlyExcuseError(error));
    }
    toast.success("Excuse request sent to your instructor");
    qc.invalidateQueries({ queryKey: ["excuse-requests"] });
    reset();
    setOpen(false);
  }

  const [cancelling, setCancelling] = useState<{ id: string; file_path: string | null } | null>(
    null,
  );
  async function cancelRequest() {
    if (!cancelling) return;
    const { error, count } = await supabase
      .from("excuse_requests")
      .delete({ count: "exact" })
      .eq("id", cancelling.id)
      .eq("status", "pending");
    if (error || !count) {
      setCancelling(null);
      return toast.error(error ? errMsg(error) : "This request was already reviewed.");
    }
    if (cancelling.file_path)
      await supabase.storage.from(EXCUSE_BUCKET).remove([cancelling.file_path]);
    setCancelling(null);
    toast.success("Request cancelled");
    qc.invalidateQueries({ queryKey: ["excuse-requests"] });
  }

  return (
    <Card
      title="Excuse requests"
      action={
        <Button size="sm" onClick={() => setOpen(true)} disabled={!subjects.length}>
          Request an excuse
        </Button>
      }
      className="mt-6"
    >
      {list.isLoading ? (
        <Loading />
      ) : !list.data?.length ? (
        <EmptyState text="No excuse requests yet" />
      ) : (
        <ul className="divide-y">
          {list.data.map((r) => (
            <li
              key={r.id}
              className="flex flex-wrap items-start justify-between gap-3 py-3 text-sm"
            >
              <div className="min-w-0 flex-1">
                <p className="font-medium">
                  {r.subjects?.subject_code} · {r.request_date}
                </p>
                <p className="text-muted-foreground">{r.reason}</p>
                {r.review_note && <p className="mt-1 text-xs">Instructor note: {r.review_note}</p>}
                {r.file_path && (
                  <Button
                    variant="link"
                    size="sm"
                    className="h-auto p-0"
                    onClick={() => r.file_path && openAttachment(r.file_path)}
                  >
                    <Paperclip /> Attachment
                  </Button>
                )}
              </div>
              <div className="flex items-center gap-2">
                <StatusPill status={r.status} />
                {r.status === "pending" && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setCancelling({ id: r.id, file_path: r.file_path })}
                  >
                    <Trash2 /> Cancel
                  </Button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
      <AlertDialog open={!!cancelling} onOpenChange={(o) => !o && setCancelling(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel this request?</AlertDialogTitle>
            <AlertDialogDescription>
              The request and its attached file will be removed. You can submit a new one later.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep it</AlertDialogCancel>
            <AlertDialogAction onClick={cancelRequest}>Cancel request</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <Dialog
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (!o) reset();
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Request an excuse</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Subject</Label>
              <SearchableSelect
                aria-label="Subject"
                className="mt-1"
                value={subject}
                onValueChange={setSubject}
                placeholder="Choose a subject"
                searchPlaceholder="Search subject"
                options={subjects.map((s) => ({
                  value: s.id,
                  label: `${s.subject_code} – ${s.subject_name}`,
                }))}
              />
              {errors.subject && <p className="mt-1 text-xs text-destructive">{errors.subject}</p>}
            </div>
            <div>
              <Label htmlFor="ex-date">Date</Label>
              <Input
                id="ex-date"
                type="date"
                className="mt-1"
                value={date}
                min={daysAgo(MAX_EXCUSE_AGE_DAYS)}
                max={localDate()}
                onChange={(e) => setDate(e.target.value)}
              />
              {errors.date && <p className="mt-1 text-xs text-destructive">{errors.date}</p>}
            </div>
            <div>
              <Label htmlFor="ex-reason">Reason</Label>
              <Textarea
                id="ex-reason"
                className="mt-1"
                rows={4}
                maxLength={1000}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
              />
              {errors.reason && <p className="mt-1 text-xs text-destructive">{errors.reason}</p>}
            </div>
            <div>
              <Label htmlFor="ex-file">Supporting file (optional, under 2 MB)</Label>
              <Input
                id="ex-file"
                type="file"
                className="mt-1"
                accept=".pdf,image/jpeg,image/png,image/webp"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              />
              {errors.file && <p className="mt-1 text-xs text-destructive">{errors.file}</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={submit} disabled={saving}>
              {saving && <Loader2 className="animate-spin" />} Submit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/** Faculty side: pending requests for subjects they teach; admins see all subjects. */
export function PendingExcuseRequests({
  userId,
  isAdmin = false,
}: {
  userId: string;
  isAdmin?: boolean;
}) {
  const [confirming, setConfirming] = useState<{ id: string; from: string } | null>(null);
  const qc = useQueryClient();
  const [rejecting, setRejecting] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const q = useQuery({
    queryKey: ["excuse-requests", "pending", userId, isAdmin],
    queryFn: async () => {
      let query = supabase
        .from("excuse_requests")
        .select(
          "id,request_date,reason,file_path,created_at,student_id,subject_id,subjects!inner(subject_code,faculty_id),students(first_name,last_name,student_number,user_id,profile:profiles!students_user_id_fkey(avatar_url,updated_at))",
        )
        .eq("status", "pending");
      if (!isAdmin) query = query.eq("subjects.faculty_id", userId);
      const { data, error } = await query.order("created_at");
      if (error) throw error;
      return data;
    },
  });

  async function review(id: string, approve: boolean, reviewNote?: string) {
    setBusy(id);
    const { error } = await supabase.rpc("review_excuse_request", {
      _id: id,
      _approve: approve,
      _note: reviewNote ?? "",
    });
    setBusy(null);
    if (error) return toast.error(errMsg(error));
    toast.success(approve ? "Approved — marked as Excused" : "Request rejected");
    setRejecting(null);
    setNote("");
    qc.invalidateQueries();
  }

  async function approve(r: {
    id: string;
    student_id: string;
    subject_id: string;
    request_date: string;
  }) {
    const { data } = await supabase
      .from("attendance")
      .select("status")
      .eq("student_id", r.student_id)
      .eq("subject_id", r.subject_id)
      .eq("attendance_date", r.request_date)
      .maybeSingle();
    if (data && data.status !== "excused") return setConfirming({ id: r.id, from: data.status });
    review(r.id, true);
  }
  const cap = (x: string) => x.charAt(0).toUpperCase() + x.slice(1);

  return (
    <Card
      title={isAdmin ? "Pending excuse requests (all subjects)" : "Pending excuse requests"}
      className={isAdmin ? "mt-6" : undefined}
    >
      {q.isLoading ? (
        <Loading />
      ) : q.error ? (
        <p className="text-sm text-destructive">{q.error.message}</p>
      ) : !q.data?.length ? (
        <EmptyState text="No pending requests" />
      ) : (
        <ul className="divide-y">
          {q.data.map((r) => {
            const s = r.students;
            const name = s ? `${s.first_name} ${s.last_name}` : "Student";
            return (
              <li key={r.id} className="flex flex-wrap items-start gap-3 py-3">
                <StudentAvatar name={name} profile={s?.profile} linked={!!s?.user_id} />
                <div className="min-w-0 flex-1 text-sm">
                  <p className="font-medium">
                    {name} · {r.subjects?.subject_code} · {r.request_date}
                  </p>
                  <p className="text-muted-foreground">{r.reason}</p>
                  {r.file_path && (
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0"
                      onClick={() => r.file_path && openAttachment(r.file_path)}
                    >
                      <Paperclip /> View attachment
                    </Button>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" disabled={busy === r.id} onClick={() => approve(r)}>
                    <Check /> Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy === r.id}
                    onClick={() => {
                      setRejecting(r.id);
                      setNote("");
                    }}
                  >
                    <X /> Reject
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <AlertDialog open={!!confirming} onOpenChange={(o) => !o && setConfirming(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Change the attendance record?</AlertDialogTitle>
            <AlertDialogDescription>
              This will change {confirming ? cap(confirming.from) : ""} to Excused.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Go back</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (confirming) review(confirming.id, true);
                setConfirming(null);
              }}
            >
              Approve
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <Dialog open={!!rejecting} onOpenChange={(o) => !o && setRejecting(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject excuse request</DialogTitle>
          </DialogHeader>
          <Label htmlFor="rej-note">Note to the student</Label>
          <Textarea id="rej-note" rows={3} value={note} onChange={(e) => setNote(e.target.value)} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejecting(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              disabled={!note.trim() || busy === rejecting}
              onClick={() => rejecting && review(rejecting, false, note)}
            >
              Reject
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
