import { createElement, type ComponentType } from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({ query: vi.fn() }));
vi.mock("@/components/AppLayout", () => ({
  RequireRole: ({ children }: { children: React.ReactNode }) => children,
}));
vi.mock("@/lib/my-subjects", () => ({
  useMySubjects: () => ({ data: [{ id: "subject" }], isSuccess: true, isLoading: false }),
}));
vi.mock("@tanstack/react-query", () => ({
  useQuery: (options: unknown) => {
    mocks.query(options);
    return { data: { rows: [] }, isLoading: false, isError: false };
  },
}));
vi.mock("@/integrations/supabase/client", () => ({ supabase: {} }));
import { Route } from "@/routes/_authenticated/reports";
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});
it("clearing either Reports date keeps the value and does not change the query", () => {
  render(createElement(Route.options.component as ComponentType));
  const from = screen.getByLabelText("From") as HTMLInputElement;
  const to = screen.getByLabelText("To") as HTMLInputElement;
  const previous = [from.value, to.value];
  const queryCalls = mocks.query.mock.calls.length;
  fireEvent.change(from, { target: { value: "" } });
  fireEvent.change(to, { target: { value: "" } });
  expect([from.value, to.value]).toEqual(previous);
  expect(mocks.query.mock.calls.length).toBe(queryCalls);
});
