import { createElement, type ComponentType } from "react";
import { cleanup, render, screen, act } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

type AuthCallback = (event: string, session: unknown) => void;

const mocks = vi.hoisted(() => ({
  getSession: vi.fn(),
  updateUser: vi.fn(),
  unsubscribe: vi.fn(),
  listener: { current: null as AuthCallback | null },
}));
vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    auth: {
      getSession: mocks.getSession,
      updateUser: mocks.updateUser,
      onAuthStateChange: (cb: AuthCallback) => {
        mocks.listener.current = cb;
        return { data: { subscription: { unsubscribe: mocks.unsubscribe } } };
      },
    },
  },
}));
vi.mock("@/lib/auth", () => ({
  useAuth: () => ({ data: null, isLoading: false }),
}));
vi.mock("@tanstack/react-router", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@tanstack/react-router")>();
  return {
    ...actual,
    useNavigate: () => vi.fn(),
    Link: ({ children, to }: { children: React.ReactNode; to: string }) =>
      createElement("a", { href: to }, children),
  };
});

import { Route } from "@/routes/reset-password";

function renderPage() {
  return render(createElement(Route.options.component as ComponentType));
}

const session = { access_token: "tok" };

beforeEach(() => {
  window.history.replaceState(null, "", "/reset-password");
  mocks.getSession.mockResolvedValue({ data: { session: null } });
});

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
  vi.useRealTimers();
});

describe("reset-password page", () => {
  it("shows the expired message and no form when the URL has error_code=otp_expired", () => {
    window.history.replaceState(null, "", "/reset-password#error_code=otp_expired");
    renderPage();
    expect(screen.getByText("This reset link is invalid or has expired")).toBeTruthy();
    expect(screen.queryByLabelText("New password")).toBeNull();
    expect(screen.getByRole("link", { name: "Request a new reset link" })).toBeTruthy();
  });

  it("shows the form when a PASSWORD_RECOVERY event fires", async () => {
    renderPage();
    await act(async () => {
      mocks.listener.current?.("PASSWORD_RECOVERY", session);
    });
    expect(screen.getByLabelText("New password")).toBeTruthy();
    expect(screen.queryByText("This reset link is invalid or has expired")).toBeNull();
  });

  it("shows the expired message when no session and no event arrive before the timer", async () => {
    vi.useFakeTimers();
    renderPage();
    await act(async () => {
      await vi.advanceTimersByTimeAsync(2100);
    });
    expect(screen.getByText("This reset link is invalid or has expired")).toBeTruthy();
    expect(screen.queryByLabelText("New password")).toBeNull();
  });

  it("shows the form when a session exists, independent of profile or role loading", async () => {
    mocks.getSession.mockResolvedValue({ data: { session } });
    renderPage();
    await act(async () => {});
    expect(await screen.findByLabelText("New password")).toBeTruthy();
    expect(screen.queryByText("This reset link is invalid or has expired")).toBeNull();
  });
});
