import { describe, expect, it } from "vitest";
import { excuseFileError, excuseReasonError } from "@/lib/excuse";

describe("excuse request rules", () => {
  it("allows no attachment", () => expect(excuseFileError(null)).toBeNull());
  it("accepts a file just under 2 MB", () =>
    expect(excuseFileError({ size: 2 * 1024 * 1024 - 1, type: "application/pdf" })).toBeNull());
  it("rejects a file of exactly 2 MB", () =>
    expect(excuseFileError({ size: 2 * 1024 * 1024, type: "application/pdf" })).toBe(
      "File must be under 2 MB.",
    ));
  it("requires a reason", () => expect(excuseReasonError("  ")).toBe("Please give a reason."));
});

import { excuseDateError } from "@/lib/excuse";
describe("excuse date rule", () => {
  const today = "2026-10-18",
    oldest = "2026-09-18";
  it("rejects a future date", () =>
    expect(excuseDateError("2026-10-19", today, oldest)).toBe(
      "The excuse date can't be in the future.",
    ));
  it("accepts today", () => expect(excuseDateError(today, today, oldest)).toBeNull());
  it("accepts exactly 30 days ago", () =>
    expect(excuseDateError(oldest, today, oldest)).toBeNull());
  it("rejects 31 days ago", () =>
    expect(excuseDateError("2026-09-17", today, oldest)).toBe(
      "The excuse date must be within the last 30 days.",
    ));
});
