import { describe, expect, it } from "vitest";
import { needsPasswordSetup, profilePasswordSchema } from "@/lib/profile-password";

const google = {
  identities: [{ provider: "google" }],
  app_metadata: { providers: ["google"] },
  user_metadata: {},
};
describe("Profile password rules", () => {
  it("offers initial setup to Google-only users without a current password", () => {
    expect(needsPasswordSetup(google)).toBe(true);
    expect(
      profilePasswordSchema(true).safeParse({
        current: "",
        password: "Password1",
        confirm: "Password1",
      }).success,
    ).toBe(true);
  });
  it("keeps the current password requirement for email/password accounts", () => {
    expect(
      needsPasswordSetup({ ...google, identities: [...google.identities, { provider: "email" }] }),
    ).toBe(false);
    expect(
      profilePasswordSchema(false).safeParse({
        current: "",
        password: "Password1",
        confirm: "Password1",
      }).success,
    ).toBe(false);
  });
  it("recognizes email-only accounts", () => {
    expect(
      needsPasswordSetup({
        ...google,
        identities: [{ provider: "email" }],
        app_metadata: { providers: ["email"] },
      }),
    ).toBe(false);
  });
  it("remembers successful setup even when Auth retains only a Google identity", () => {
    expect(
      needsPasswordSetup({ ...google, user_metadata: { attendease_password_set: true } }),
    ).toBe(false);
  });
  it("requires at least eight characters", () => {
    expect(
      profilePasswordSchema(true).safeParse({
        current: "",
        password: "Abc1234",
        confirm: "Abc1234",
      }).success,
    ).toBe(false);
    expect(
      profilePasswordSchema(true).safeParse({
        current: "",
        password: "Abc12345",
        confirm: "Abc12345",
      }).success,
    ).toBe(true);
  });
  it("requires a letter", () => {
    expect(
      profilePasswordSchema(true).safeParse({
        current: "",
        password: "12345678",
        confirm: "12345678",
      }).success,
    ).toBe(false);
  });
  it("requires a number", () => {
    expect(
      profilePasswordSchema(true).safeParse({
        current: "",
        password: "abcdefgh",
        confirm: "abcdefgh",
      }).success,
    ).toBe(false);
  });
  it("requires matching confirmation", () => {
    expect(
      profilePasswordSchema(true).safeParse({
        current: "",
        password: "Password1",
        confirm: "Password2",
      }).success,
    ).toBe(false);
  });
});
