import { createElement, type ComponentType } from "react";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  updateUser: vi.fn(),
  invalidateQueries: vi.fn(),
  success: vi.fn(),
  auth: {
    user: {
      id: "google-user",
      email: "google@example.edu",
      identities: [{ provider: "google" }],
      app_metadata: { providers: ["google"] },
      user_metadata: {},
    },
    profile: { full_name: "Google User", avatar_url: null },
    role: "admin",
  },
}));
vi.mock("@/lib/auth", () => ({
  useAuth: () => ({ data: mocks.auth }),
  errMsg: (error: { message: string }) => error.message,
  logActivity: vi.fn(),
}));
vi.mock("@/lib/avatar", () => ({
  AVATAR_BUCKET: "avatars",
  useAvatarUrl: () => undefined,
  avatarTone: () => 0,
}));
vi.mock("@tanstack/react-query", () => ({
  useQueryClient: () => ({ invalidateQueries: mocks.invalidateQueries }),
}));
vi.mock("@/integrations/supabase/client", () => ({
  supabase: { auth: { updateUser: mocks.updateUser } },
}));
vi.mock("sonner", () => ({ toast: { success: mocks.success, error: vi.fn() } }));

import { Route } from "@/routes/_authenticated/profile";

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

describe("Google initial password flow", () => {
  it("preserves an edited name when the profile cache refreshes", () => {
    const component = createElement(Route.options.component as ComponentType);
    const view = render(component);
    fireEvent.change(screen.getByLabelText("Full name"), { target: { value: "Unsaved name" } });
    const previousProfile = mocks.auth.profile;
    mocks.auth.profile = { ...previousProfile, full_name: "Refetched name" };
    view.rerender(createElement(Route.options.component as ComponentType));
    expect(screen.getByLabelText("Full name")).toHaveValue("Unsaved name");
    mocks.auth.profile = previousProfile;
  });
  it("sends no current password during setup and requires one after successful setup", async () => {
    mocks.updateUser.mockResolvedValue({ error: null });
    render(createElement(Route.options.component as ComponentType));
    expect(screen.queryByLabelText("Current password")).toBeNull();
    fireEvent.change(screen.getByLabelText("New password"), { target: { value: "Example123" } });
    fireEvent.change(screen.getByLabelText("Confirm new password"), {
      target: { value: "Example123" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Set password" }));
    await waitFor(() =>
      expect(mocks.updateUser).toHaveBeenCalledWith({
        password: "Example123",
        data: { attendease_password_set: true },
      }),
    );
    await screen.findByLabelText("Current password");
    fireEvent.change(screen.getByLabelText("New password"), { target: { value: "Another123" } });
    fireEvent.change(screen.getByLabelText("Confirm new password"), {
      target: { value: "Another123" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Update password" }));
    expect(mocks.updateUser).toHaveBeenCalledTimes(1);
    fireEvent.change(screen.getByLabelText("Current password"), {
      target: { value: "Example123" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Update password" }));
    await waitFor(() =>
      expect(mocks.updateUser).toHaveBeenLastCalledWith({
        password: "Another123",
        current_password: "Example123",
      }),
    );
  });

  it("stays in initial setup when saving fails", async () => {
    mocks.updateUser.mockResolvedValue({ error: { message: "Unable to set password" } });
    render(createElement(Route.options.component as ComponentType));
    fireEvent.change(screen.getByLabelText("New password"), { target: { value: "Example123" } });
    fireEvent.change(screen.getByLabelText("Confirm new password"), {
      target: { value: "Example123" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Set password" }));
    await waitFor(() => expect(mocks.updateUser).toHaveBeenCalledTimes(1));
    expect(screen.queryByLabelText("Current password")).toBeNull();
    expect(mocks.success).not.toHaveBeenCalled();
  });
});
