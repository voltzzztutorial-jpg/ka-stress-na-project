import { describe, expect, it } from "vitest";
import { csvCell, toCsv } from "@/components/shared";

describe("CSV export", () => {
  it("starts with a UTF-8 BOM", () => {
    expect(toCsv([["a"]]).charCodeAt(0)).toBe(0xfeff);
  });
  it("prefixes cells starting with = + - @ with an apostrophe", () => {
    expect(csvCell("=SUM(A1)")).toBe(`"'=SUM(A1)"`);
    expect(csvCell("+1")).toBe(`"'+1"`);
    expect(csvCell("-5")).toBe(`"'-5"`);
    expect(csvCell("@x")).toBe(`"'@x"`);
    expect(csvCell("Dela Cruz")).toBe(`"Dela Cruz"`);
  });
  it("prefixes cells starting with tab or carriage return", () => {
    expect(csvCell("\t=cmd")).toBe(`"'\t=cmd"`);
    expect(csvCell("\rSUM")).toBe(`"'\rSUM"`);
  });
});
