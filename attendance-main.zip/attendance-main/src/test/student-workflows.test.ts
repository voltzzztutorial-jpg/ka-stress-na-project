import { describe, expect, it } from "vitest";
import { bulkCandidates, changedMarkIds, lowestRisk, marksChanged } from "@/lib/student-workflows";
import { avatarTone } from "@/lib/avatar";
const student = (id: string, extra = {}) => ({
  id,
  status: "active",
  program: "BSIT",
  year_level: 1,
  section: "A",
  ...extra,
});
const row = (
  student_id: string,
  status: "present" | "absent" | "late" | "excused",
  subject_id = "subject",
) => ({ student_id, subject_id, status });
describe("Student workflow rules", () => {
  it("bulk enrollment excludes archived students", () => {
    expect(
      bulkCandidates(
        [student("active"), student("archived", { status: "inactive" })],
        new Set(),
        "BSIT",
        "1",
        "",
      ).candidates.map((s) => s.id),
    ).toEqual(["active"]);
  });
  it("skips duplicates in the preview", () => {
    const result = bulkCandidates(
      [student("enrolled"), student("new")],
      new Set(["enrolled"]),
      "BSIT",
      "1",
      "",
    );
    expect(result.skipped).toBe(1);
    expect(result.candidates.map((s) => s.id)).toEqual(["new"]);
  });
  it("filters by chosen program and year", () => {
    expect(
      bulkCandidates(
        [
          student("match"),
          student("wrong-program", { program: "BSED" }),
          student("wrong-year", { year_level: 2 }),
        ],
        new Set(),
        "BSIT",
        "1",
        "",
      ).candidates.map((s) => s.id),
    ).toEqual(["match"]);
  });
  it("optionally filters section", () => {
    expect(
      bulkCandidates(
        [student("a"), student("b", { section: "B" })],
        new Set(),
        "BSIT",
        "1",
        " a ",
      ).candidates.map((s) => s.id),
    ).toEqual(["a"]);
  });
  it("requires at least three records to be at risk", () => {
    expect(
      lowestRisk([
        row("two", "absent"),
        row("two", "absent"),
        row("three", "absent"),
        row("three", "absent"),
        row("three", "present"),
      ]).map((r) => r.row.student_id),
    ).toEqual(["three"]);
  });
  it("excludes excused from the rate and requires below 75 percent", () => {
    const result = lowestRisk([
      row("safe", "present"),
      row("safe", "late"),
      row("safe", "present"),
      row("safe", "absent"),
      row("risk", "late"),
      row("risk", "absent"),
      row("risk", "excused"),
    ]);
    expect(result.map((r) => [r.row.student_id, r.rate])).toEqual([["risk", 50]]);
  });
  it("returns only five lowest student-subject rates", () => {
    const rows = Array.from({ length: 7 }, (_, i) => [
      row(String(i), "absent"),
      row(String(i), "absent"),
      row(String(i), "absent"),
    ]).flat();
    expect(lowestRisk(rows)).toHaveLength(5);
  });
  it("detects unsaved marks and remarks and clears with the saved baseline", () => {
    const saved = { s: { status: "present", remarks: "" } };
    expect(marksChanged({ s: { status: "late", remarks: "" } }, saved)).toBe(true);
    expect(marksChanged({ s: { status: "present", remarks: "note" } }, saved)).toBe(true);
    expect(marksChanged(saved, { ...saved })).toBe(false);
  });
  it("flags only excused students as not at risk", () => {
    expect(
      lowestRisk([
        row("excused-only", "excused"),
        row("excused-only", "excused"),
        row("excused-only", "excused"),
      ]),
    ).toEqual([]);
  });
  it("save diff sends only changed or new marks", () => {
    const saved = { a: { status: "present", remarks: "" }, b: { status: "absent", remarks: "" } };
    const marks = {
      a: { status: "present", remarks: "" },
      b: { status: "late", remarks: "" },
      c: { status: "absent", remarks: "" },
    };
    expect(changedMarkIds(marks, saved)).toEqual(["b", "c"]);
    expect(changedMarkIds(saved, saved)).toEqual([]);
  });
  it("save diff includes remark-only changes", () => {
    const saved = { a: { status: "present", remarks: "" } };
    expect(changedMarkIds({ a: { status: "present", remarks: "note" } }, saved)).toEqual(["a"]);
  });
  it("uses stable name-derived avatar tones", () => {
    expect(avatarTone(" Maria Cruz ")).toBe(avatarTone("maria cruz"));
    expect(new Set(["Ana", "Juan", "Pedro", "Maria"].map(avatarTone)).size).toBeGreaterThan(1);
  });
});
