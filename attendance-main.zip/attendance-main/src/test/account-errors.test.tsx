import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({ refetch: vi.fn() }));
vi.mock("@/lib/auth", () => ({
  useAuth: () => ({ data: undefined, isLoading: false, isError: true, refetch: mocks.refetch }),
}));
vi.mock("@tanstack/react-router", () => ({
  useLocation: () => ({ pathname: "/dashboard" }),
  useNavigate: () => vi.fn(),
  Link: () => null,
}));
vi.mock("@tanstack/react-query", () => ({ useQueryClient: () => ({}) }));
vi.mock("@/integrations/supabase/client", () => ({ supabase: { auth: {} } }));
vi.mock("@/components/UserAvatar", () => ({ UserAvatar: () => null }));
import { AppLayout, RequireRole } from "@/components/AppLayout";
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});
describe("First-load account failure", () => {
  it("allows retry in AppLayout without account data", () => {
    render(<AppLayout>Private content</AppLayout>);
    fireEvent.click(screen.getByRole("button", { name: "Try again" }));
    expect(mocks.refetch).toHaveBeenCalledOnce();
    expect(screen.queryByText("Private content")).toBeNull();
  });
  it("allows role verification retry without account data", () => {
    render(<RequireRole roles={["admin"]}>Private content</RequireRole>);
    fireEvent.click(screen.getByRole("button", { name: "Try again" }));
    expect(mocks.refetch).toHaveBeenCalledOnce();
  });
});
