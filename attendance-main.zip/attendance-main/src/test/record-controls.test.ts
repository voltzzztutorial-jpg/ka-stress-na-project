import { describe, expect, it } from "vitest";
import {
  clampPage,
  compareValues,
  markUnmarkedPresent,
  retainedDate,
  validDateRange,
} from "@/lib/record-controls";
import { allowedAvatarPath } from "@/lib/avatar";

describe("Verified record controls", () => {
  it("retains cleared dates without changing the query range", () => {
    expect(retainedDate("2026-10-01", "")).toBe("2026-10-01");
    expect(retainedDate("2026-10-18", "2026-10-17")).toBe("2026-10-17");
    expect(validDateRange("2026-10-18", "2026-10-01")).toBe(false);
  });
  it("clamps a deleted final page and an empty list", () => {
    expect(clampPage(2, 2)).toBe(1);
    expect(clampPage(1, 1)).toBe(0);
    expect(clampPage(0, 0)).toBe(0);
  });
  it("returns zero on sort ties in either direction", () => {
    expect(compareValues("Cruz", "Cruz")).toBe(0);
    expect(compareValues("Cruz", "Cruz", false)).toBe(0);
    expect(compareValues("Ana", "Ben")).toBe(-1);
  });
  it("marks only unmarked students as present", () => {
    const marks = {
      e: { status: "excused" as const, remarks: "approved" },
      a: { status: "absent" as const, remarks: "" },
    };
    expect(markUnmarkedPresent(marks, [{ id: "e" }, { id: "a" }, { id: "u" }])).toEqual({
      ...marks,
      u: { status: "present", remarks: "" },
    });
    expect(marks).not.toHaveProperty("u");
  });
  it("rejects external and data avatar URLs", () => {
    for (const path of [
      "https://example.com/a.jpg",
      "http://example.com/a.jpg",
      "data:image/png;base64,abc",
      "//example.com/a.jpg",
      "user/../a.jpg",
    ])
      expect(allowedAvatarPath(path)).toBe(false);
    expect(allowedAvatarPath("user/avatar.jpg")).toBe(true);
    expect(allowedAvatarPath("blob:local-preview")).toBe(true);
  });
});
