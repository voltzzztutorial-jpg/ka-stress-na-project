import { describe, expect, it } from "vitest";
import { attendanceRate, daysAgo, isLowAttendance, localDate } from "@/lib/attendance";

describe("attendance rules", () => {
  it("counts present + late over present + late + absent", () => {
    expect(attendanceRate({ present: 6, late: 2, absent: 2 })).toBe(80);
  });
  it("excludes excused from numerator and denominator", () => {
    expect(attendanceRate({ present: 3, late: 0, absent: 1, excused: 10 })).toBe(75);
  });
  it("warns below 75% only", () => {
    expect(isLowAttendance(74.9)).toBe(true);
    expect(isLowAttendance(75)).toBe(false);
  });
  it("does not flag a student with only excused records", () => {
    // Excused-only means no countable records, so never a warning.
    expect(isLowAttendance(0, false)).toBe(false);
    expect(
      isLowAttendance(attendanceRate({ present: 0, late: 0, absent: 0, excused: 5 }), false),
    ).toBe(false);
  });
  it("uses the local calendar date, not UTC", () => {
    // 00:30 local on Jan 2 must stay Jan 2 regardless of UTC offset
    expect(localDate(new Date(2026, 0, 2, 0, 30))).toBe("2026-01-02");
    expect(daysAgo(1, new Date(2026, 2, 1, 0, 30))).toBe("2026-02-28");
  });
});
