import { describe, expect, it } from "vitest";
import { activeFaculty, eligibleStudents, matchesSearch } from "@/lib/select-options";

describe("Searchable choice rules", () => {
  it("matches case-insensitively across names, numbers and emails", () => {
    const text = "Dela Cruz, Maria 2026-001 BSIT maria@example.edu";
    for (const search of ["DELA CRUZ", "2026-001", "MARIA@EXAMPLE.EDU"])
      expect(matchesSearch(text, search)).toBe(true);
    expect(matchesSearch(text, "absent name")).toBe(false);
  });
  it("excludes inactive enrollment candidates", () => {
    expect(
      eligibleStudents(
        [
          { id: "active", status: "active" },
          { id: "inactive", status: "inactive" },
        ],
        new Set(),
      ).map((s) => s.id),
    ).toEqual(["active"]);
  });
  it("excludes already-enrolled students", () => {
    expect(
      eligibleStudents(
        [
          { id: "enrolled", status: "active" },
          { id: "available", status: "active" },
        ],
        new Set(["enrolled"]),
      ).map((s) => s.id),
    ).toEqual(["available"]);
  });
  it("excludes inactive role-eligible faculty and admins", () => {
    expect(
      activeFaculty([
        { id: "faculty", is_active: true },
        { id: "admin", is_active: true },
        { id: "inactive", is_active: false },
      ]).map((p) => p.id),
    ).toEqual(["faculty", "admin"]);
  });
});
