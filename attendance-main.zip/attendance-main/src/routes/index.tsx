import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BarChart3,
  CheckCircle2,
  ClipboardCheck,
  LayoutDashboard,
  Lock,
  ShieldCheck,
} from "lucide-react";
import hero from "@/assets/hero.jpg";
import { Logo } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/AppLayout";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AttendEase – Attendance System | SorSU Bulan Campus" },
      {
        name: "description",
        content:
          "Fast, accurate student attendance for Sorsogon State University – Bulan Campus. Mark, track and report in minutes.",
      },
      { property: "og:title", content: "AttendEase – Student Attendance Management" },
      {
        property: "og:description",
        content:
          "Mark attendance, see real-time dashboards and export reports for SorSU Bulan Campus.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const features = [
  {
    icon: ClipboardCheck,
    title: "Easy attendance marking",
    text: "Pick a class and date, tap a status, save. Mark everyone present in one click.",
  },
  {
    icon: LayoutDashboard,
    title: "Real-time dashboard",
    text: "See today's present, absent and late counts with charts that update instantly.",
  },
  {
    icon: BarChart3,
    title: "Automated reports",
    text: "Attendance percentages per student and subject, ready to export or print.",
  },
  {
    icon: ShieldCheck,
    title: "Role-based access",
    text: "Admins, faculty and students each see exactly what they need — nothing more.",
  },
  {
    icon: Lock,
    title: "Secure login",
    text: "Every account is protected with secure email and password sign-in.",
  },
];

export function PublicNav() {
  const { data: auth, isLoading } = useAuth();
  return (
    <header className="sticky top-0 z-30 border-b bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-4 px-4">
        <Link to="/" className="text-primary">
          <Logo />
        </Link>
        <nav className="ml-6 hidden gap-6 text-sm text-muted-foreground md:flex">
          <Link
            to="/"
            hash="features"
            hashScrollIntoView={{ behavior: "smooth", block: "start" }}
            className="hover:text-foreground"
          >
            Features
          </Link>
          <Link to="/help" className="hover:text-foreground">
            Help
          </Link>
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <ThemeToggle />
          {isLoading ? (
            <span className="h-9 w-40 animate-pulse rounded-md bg-muted" aria-label="Loading" />
          ) : auth ? (
            <Button asChild>
              <Link to="/dashboard">Go to Dashboard</Link>
            </Button>
          ) : (
            <>
              <Button variant="ghost" asChild>
                <Link to="/login">Login</Link>
              </Button>
              <Button asChild>
                <Link to="/register">Register</Link>
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

export function PublicFooter() {
  return (
    <footer className="border-t py-8 text-center text-sm text-muted-foreground">
      <p className="font-medium text-foreground">Sorsogon State University – Bulan Campus</p>
      <p className="mt-1">© {new Date().getFullYear()} AttendEase. All rights reserved.</p>
    </footer>
  );
}

function Landing() {
  return (
    <div className="min-h-screen">
      <PublicNav />
      <section className="bg-hero text-primary-foreground">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2 md:py-24">
          <div>
            <p className="inline-flex rounded-full bg-primary-foreground/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider">
              SorSU · Bulan Campus
            </p>
            <h1 className="mt-5 text-4xl font-extrabold leading-tight sm:text-5xl">
              Attendance, done in <span className="text-gold">seconds</span> — not on paper.
            </h1>
            <p className="mt-5 max-w-lg text-lg opacity-85">
              AttendEase helps faculty record class attendance, lets students track their own
              records, and gives administrators instant reports.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" variant="gold" asChild>
                <Link to="/register">Get Started</Link>
              </Button>
              <Button size="lg" variant="heroOutline" asChild>
                <Link to="/login">Login</Link>
              </Button>
            </div>
            <ul className="mt-8 space-y-2 text-sm opacity-85">
              {[
                "No more lost attendance sheets",
                "Automatic attendance percentages",
                "Low-attendance warnings below 75%",
              ].map((t) => (
                <li key={t} className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-gold" />
                  {t}
                </li>
              ))}
            </ul>
          </div>
          <img
            src={hero}
            alt="Instructor taking attendance with a tablet in a classroom"
            width={1280}
            height={960}
            className="rounded-2xl shadow-2xl ring-1 ring-primary-foreground/20"
          />
        </div>
      </section>
      <section id="features" className="mx-auto max-w-6xl px-4 py-20">
        <h2 className="text-center text-3xl font-bold">Main Features</h2>
        <p className="mx-auto mt-2 max-w-xl text-center text-muted-foreground">
          Everything a campus needs to run attendance without the paperwork.
        </p>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <div key={f.title} className="rounded-xl border bg-card p-6 shadow-card">
              <span className="grid size-11 place-items-center rounded-lg bg-primary/10 text-primary">
                <f.icon className="size-5" />
              </span>
              <h3 className="mt-4 font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>
      <PublicFooter />
    </div>
  );
}
