import { createFileRoute } from "@tanstack/react-router";
import { MapPin } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { AppLayout } from "@/components/AppLayout";
import { Loading } from "@/components/shared";
import { useAuth } from "@/lib/auth";
import { PublicFooter, PublicNav } from "./index";

export const Route = createFileRoute("/help")({
  head: () => ({
    meta: [
      { title: "About & Help – AttendEase" },
      {
        name: "description",
        content: "How to use AttendEase, frequently asked questions and contact information.",
      },
      { property: "og:title", content: "About & Help – AttendEase" },
      {
        property: "og:description",
        content: "Guides and FAQ for the SorSU Bulan attendance system.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Help,
});

const steps = [
  [
    "Register & sign in",
    "Create an account with your email. New accounts start as Students; an administrator can promote faculty.",
  ],
  [
    "Set up classes",
    "Administrators add students and subjects, assign a faculty member, and enroll students.",
  ],
  [
    "Manage enrollments",
    "On Subjects, open a subject's enrollment list to add or remove students. Faculty manage only the subjects they teach.",
  ],
  [
    "Track progress",
    "The Dashboard shows attendance by subject, a status breakdown and a 30-day trend. Students see their own rate per subject.",
  ],
];
const faqs = [
  [
    "What counts toward my attendance percentage?",
    "Rate = (Present + Late) ÷ (Present + Late + Absent). Excused days are left out completely, so they neither help nor hurt. A rate below 75% shows a warning.",
  ],
  [
    "I marked the wrong status. Can I fix it?",
    "Yes. Re-open the same subject and date and save again — the record is updated, never duplicated.",
  ],
  [
    "Why can't I see the Students page?",
    "Students only see their own records. Ask an administrator if you need faculty access.",
  ],
  [
    "How is my student record linked to my account?",
    "Register with the same email used on your student record and it links automatically.",
  ],
];

function HelpBody() {
  return (
    <main className="mx-auto max-w-4xl px-4 py-14">
      <h1 className="text-3xl font-bold">About & Help</h1>
      <p className="mt-2 text-muted-foreground">
        AttendEase replaces paper attendance sheets at Sorsogon State University – Bulan Campus.
      </p>
      <h2 className="mt-10 text-xl font-semibold">How to use the system</h2>
      <ol className="mt-4 grid gap-4 sm:grid-cols-2">
        {steps.map(([t, d], i) => (
          <li key={t} className="rounded-xl border bg-card p-5 shadow-card">
            <span className="grid size-8 place-items-center rounded-full bg-primary font-bold text-primary-foreground">
              {i + 1}
            </span>
            <h3 className="mt-3 font-semibold">{t}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{d}</p>
          </li>
        ))}
      </ol>
      <h2 className="mt-10 text-xl font-semibold">FAQ</h2>
      <Accordion type="single" collapsible className="mt-2">
        {faqs.map(([q, a]) => (
          <AccordionItem key={q} value={q}>
            <AccordionTrigger>{q}</AccordionTrigger>
            <AccordionContent>{a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
      <h2 className="mt-10 text-xl font-semibold">Contact</h2>
      <div className="mt-4 grid gap-3 text-sm sm:grid-cols-3">
        <p className="flex items-center gap-2">
          <MapPin className="size-4 text-primary" /> Bulan, Sorsogon, Philippines
        </p>
      </div>
    </main>
  );
}

function Help() {
  const { data: auth, isLoading } = useAuth();
  if (isLoading) return <Loading />;
  if (auth) {
    return (
      <AppLayout>
        <HelpBody />
      </AppLayout>
    );
  }
  return (
    <div className="min-h-screen">
      <PublicNav />
      <HelpBody />
      <PublicFooter />
    </div>
  );
}
