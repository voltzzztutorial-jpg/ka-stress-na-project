import { useEffect, useRef, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AuthShell } from "@/components/AuthShell";
import { FieldError, Loading } from "@/components/shared";
import { PasswordInput } from "@/components/PasswordInput";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { passwordSchema } from "@/lib/validation";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Set new password – AttendEase" },
      { name: "description", content: "Choose a new password for AttendEase." },
      { property: "og:title", content: "Set new password – AttendEase" },
      { property: "og:description", content: "Choose a new password." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Reset,
});

type Status = "checking" | "ready" | "expired";

function Reset() {
  // Resetting depends only on the recovery session, never on profile/role loading.
  const [status, setStatus] = useState<Status>("checking");
  const statusRef = useRef<Status>("checking");
  const navigate = useNavigate();
  const [pw, setPw] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errs, setErrs] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const resolve = (next: Status) => {
      statusRef.current = next;
      setStatus(next);
    };
    const url = window.location.hash + window.location.search;
    if (/(^|[?&#])(error_code|error_description)=/.test(url)) {
      resolve("expired");
      return;
    }
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN") resolve("ready");
      else if (event === "INITIAL_SESSION" && session) resolve("ready");
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) resolve("ready");
    });
    const timer = setTimeout(() => {
      if (statusRef.current === "checking") resolve("expired");
    }, 2000);
    return () => {
      subscription.unsubscribe();
      clearTimeout(timer);
    };
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const r = passwordSchema.safeParse(pw);
    const next: Record<string, string> = {};
    if (!r.success) next.pw = r.error.issues[0].message;
    if (pw !== confirm) next.confirm = "Passwords do not match";
    setErrs(next);
    if (Object.keys(next).length) return;
    setLoading(true);
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (!session) {
      setLoading(false);
      setStatus("expired");
      return;
    }
    const { error } = await supabase.auth.updateUser({ password: pw });
    setLoading(false);
    if (error) {
      if (
        error.name === "AuthSessionMissingError" ||
        /session missing|session.*expired/i.test(error.message)
      ) {
        setStatus("expired");
        return;
      }
      return toast.error(error.message);
    }
    toast.success("Password updated");
    navigate({ to: "/dashboard" });
  }
  return (
    <AuthShell
      allowSignedIn
      title="Set a new password"
      subtitle="At least 8 characters with letters and numbers"
    >
      {status === "checking" ? (
        <Loading />
      ) : status === "expired" ? (
        <div role="alert" className="space-y-4">
          <p>This reset link is invalid or has expired</p>
          <Button asChild variant="outline">
            <Link to="/forgot-password">Request a new reset link</Link>
          </Button>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4" noValidate>
          <div>
            <Label htmlFor="pw">New password</Label>
            <PasswordInput
              id="pw"
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              className="mt-1"
            />
            <FieldError msg={errs.pw} />
          </div>
          <div>
            <Label htmlFor="cf">Confirm password</Label>
            <PasswordInput
              id="cf"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              className="mt-1"
            />
            <FieldError msg={errs.confirm} />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading && <Loader2 className="animate-spin" />} Update password
          </Button>
        </form>
      )}
    </AuthShell>
  );
}
