import { createFileRoute } from "@tanstack/react-router";
import { AccessDenied } from "@/components/shared";

export const Route = createFileRoute("/access-denied")({
  head: () => ({
    meta: [
      { title: "Access Denied – AttendEase" },
      { name: "description", content: "You don't have permission to view this page." },
      { property: "og:title", content: "Access Denied – AttendEase" },
      { property: "og:description", content: "You don't have permission to view this page." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <div className="grid min-h-screen place-items-center px-4">
      <AccessDenied />
    </div>
  ),
});
