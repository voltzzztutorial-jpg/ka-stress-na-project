import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { RequireRole } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, Loading, PageHeader, StatusBadge } from "@/components/shared";
import { UserAvatar } from "@/components/UserAvatar";
import { StudentExcuseRequests } from "@/components/ExcuseRequests";
import { useEnrolledClasses } from "@/lib/my-classes";
import {
  attendanceRate,
  daysAgo,
  isLowAttendance,
  localDate,
  LOW_ATTENDANCE_THRESHOLD,
} from "@/lib/attendance";
export const Route = createFileRoute("/_authenticated/my-classes")({
  head: () => ({
    meta: [
      { title: "My classes – AttendEase" },
      { name: "description", content: "Your enrolled classes and attendance history." },
      { property: "og:title", content: "My classes – AttendEase" },
      { property: "og:description", content: "Your enrolled classes and attendance history." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireRole roles={["student"]}>
      <MyClasses />
    </RequireRole>
  ),
});
function MyClasses() {
  const q = useEnrolledClasses();
  const [selected, setSelected] = useState<string | null>(null);
  const [from, setFrom] = useState(() => daysAgo(60));
  const [to, setTo] = useState(() => localDate());
  const subject = q.data?.subjects.find((s) => s.id === selected);
  return (
    <div>
      <PageHeader title="My classes" />
      {q.isLoading ? (
        <Loading />
      ) : q.isError ? (
        <EmptyState text="Couldn't load your classes." />
      ) : !q.data?.subjects.length ? (
        <EmptyState text="No enrolled classes yet" />
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {q.data.subjects.map((s) => {
            const records = q.data.attendance.filter((a) => a.subject_id === s.id);
            const counts = { present: 0, absent: 0, late: 0, excused: 0 };
            records.forEach((r) => counts[r.status]++);
            const rate = attendanceRate(counts);
            const faculty = q.data.faculty.find((f) => f.id === s.faculty_id);
            const low = isLowAttendance(rate, counts.present + counts.absent + counts.late > 0);
            return (
              <article key={s.id} className="rounded-lg border bg-card p-5 shadow-card">
                <p className="font-mono text-xs text-primary">{s.subject_code}</p>
                <Button
                  variant="link"
                  className="h-auto max-w-full justify-start whitespace-normal p-0 text-left text-lg font-semibold text-foreground"
                  onClick={() => setSelected(s.id)}
                >
                  {s.subject_name}
                </Button>
                <p className="mt-2 text-sm text-muted-foreground">
                  {s.schedule_day} · {s.schedule_time} · {s.room}
                </p>
                <div className="mt-2 flex items-center gap-2">
                  <UserAvatar
                    name={faculty?.full_name || "Unassigned"}
                    avatarUrl={faculty?.avatar_url}
                    size="xs"
                  />
                  <span className="text-sm">{faculty?.full_name || "Unassigned"}</span>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <strong className={low ? "text-absent" : "text-primary"}>{rate}%</strong>
                  {low && (
                    <span className="rounded-full bg-absent/10 px-2 py-1 text-xs text-absent">
                      Below {LOW_ATTENDANCE_THRESHOLD}%
                    </span>
                  )}
                </div>
                <div className="mt-2 flex flex-wrap gap-3 text-xs">
                  {Object.entries(counts).map(([status, count]) => (
                    <span key={status} className="capitalize">
                      {status}: {count}
                    </span>
                  ))}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-4"
                  onClick={() => setSelected(s.id)}
                >
                  Attendance history
                </Button>
              </article>
            );
          })}
        </div>
      )}
      {q.data && <StudentExcuseRequests subjects={q.data.subjects} />}
      <Dialog open={!!subject} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>{subject?.subject_code} · Attendance history</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="class-from">From</Label>
              <Input
                id="class-from"
                type="date"
                value={from}
                max={to}
                onChange={(e) => setFrom(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="class-to">To</Label>
              <Input
                id="class-to"
                type="date"
                value={to}
                min={from}
                max={localDate()}
                onChange={(e) => setTo(e.target.value)}
              />
            </div>
          </div>
          <div className="max-h-80 overflow-y-auto">
            {(q.data?.attendance ?? [])
              .filter(
                (r) =>
                  r.subject_id === selected && r.attendance_date >= from && r.attendance_date <= to,
              )
              .map((r) => (
                <div key={r.id} className="flex items-center gap-3 border-b py-3 text-sm">
                  <span>{r.attendance_date}</span>
                  <StatusBadge status={r.status} />
                  <span className="text-muted-foreground">{r.remarks}</span>
                </div>
              ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
