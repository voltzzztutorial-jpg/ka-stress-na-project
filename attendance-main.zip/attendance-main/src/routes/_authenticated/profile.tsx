import { useEffect, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { ImagePlus, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { errMsg, logActivity, useAuth } from "@/lib/auth";
import { AVATAR_BUCKET } from "@/lib/avatar";
import { fieldErrors } from "@/lib/validation";
import { needsPasswordSetup, profilePasswordSchema } from "@/lib/profile-password";
import { Card, FieldError, Loading, PageHeader } from "@/components/shared";
import { PasswordInput } from "@/components/PasswordInput";
import { UserAvatar } from "@/components/UserAvatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "My Profile – AttendEase" },
      { name: "description", content: "View and update your profile and password." },
      { property: "og:title", content: "My Profile – AttendEase" },
      { property: "og:description", content: "View and update your profile and password." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Profile,
});

const profileSchema = z.object({
  full_name: z.string().trim().min(2, "Full name is required").max(100),
});

const AVATAR_TYPES = ["image/png", "image/jpeg", "image/webp"];
const AVATAR_MAX_BYTES = 2 * 1024 * 1024;

function Profile() {
  const { data: auth } = useAuth();
  const qc = useQueryClient();
  const [f, setF] = useState({ full_name: "" });
  const nameDirty = useRef(false);
  const [errs, setErrs] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [pw, setPw] = useState({ current: "", password: "", confirm: "" });
  const [pwErrs, setPwErrs] = useState<Record<string, string>>({});
  const [pwSaving, setPwSaving] = useState(false);
  const [passwordSet, setPasswordSet] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [dragging, setDragging] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (auth?.profile) {
      if (!nameDirty.current) setF({ full_name: auth.profile.full_name });
      setAvatarUrl(auth.profile.avatar_url ?? null);
    }
  }, [auth?.profile]);

  useEffect(
    () => () => {
      if (preview) URL.revokeObjectURL(preview);
    },
    [preview],
  );

  if (!auth) return <Loading />;
  const settingPassword = !passwordSet && needsPasswordSetup(auth.user);

  function pickFile(file: File | undefined | null) {
    if (!file) return;
    if (!AVATAR_TYPES.includes(file.type))
      return toast.error("Please choose a PNG, JPG or WebP image");
    if (file.size > AVATAR_MAX_BYTES) return toast.error("Image must be 2 MB or smaller");
    if (preview) URL.revokeObjectURL(preview);
    setPreview(URL.createObjectURL(file));
    setPendingFile(file);
  }

  async function saveAvatar() {
    if (!pendingFile || !auth) return;
    setUploading(true);
    const uid = auth.user.id;
    // Derive the extension from the validated MIME type, not the file name.
    const ext =
      { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp" }[pendingFile.type] ?? "png";
    const path = `${uid}/avatar-${Date.now()}.${ext}`;
    const { error } = await supabase.storage
      .from(AVATAR_BUCKET)
      .upload(path, pendingFile, { contentType: pendingFile.type });
    if (error) {
      setUploading(false);
      return toast.error(errMsg(error));
    }
    const oldPath = avatarUrl;
    const { error: upErr } = await supabase
      .from("profiles")
      .update({ avatar_url: path })
      .eq("id", uid);
    if (upErr) {
      await supabase.storage.from(AVATAR_BUCKET).remove([path]);
      setUploading(false);
      return toast.error(errMsg(upErr));
    }
    if (oldPath && oldPath !== path) await supabase.storage.from(AVATAR_BUCKET).remove([oldPath]);
    setUploading(false);
    setAvatarUrl(path);
    setPendingFile(null);
    if (preview) URL.revokeObjectURL(preview);
    setPreview(null);
    toast.success("Profile photo updated");
    logActivity("updated", "profile");
    qc.invalidateQueries();
  }

  async function removeAvatar() {
    if (!auth) return;
    setUploading(true);
    const oldPath = avatarUrl;
    const { error } = await supabase
      .from("profiles")
      .update({ avatar_url: null })
      .eq("id", auth.user.id);
    if (error) {
      setUploading(false);
      return toast.error(errMsg(error));
    }
    if (oldPath) await supabase.storage.from(AVATAR_BUCKET).remove([oldPath]);
    setUploading(false);
    setAvatarUrl(null);
    setPendingFile(null);
    if (preview) URL.revokeObjectURL(preview);
    setPreview(null);
    toast.success("Profile photo removed");
    logActivity("updated", "profile");
    qc.invalidateQueries();
  }

  function cancelPreview() {
    if (preview) URL.revokeObjectURL(preview);
    setPreview(null);
    setPendingFile(null);
    if (fileInput.current) fileInput.current.value = "";
  }

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    if (!auth) return;
    const r = profileSchema.safeParse(f);
    if (!r.success) return setErrs(fieldErrors(r.error));
    setErrs({});
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ full_name: r.data.full_name })
      .eq("id", auth.user.id);
    setSaving(false);
    if (error) return toast.error(errMsg(error));
    nameDirty.current = false;
    setF({ full_name: r.data.full_name });
    toast.success("Profile updated");
    logActivity("updated", "profile");
    qc.invalidateQueries();
  }

  async function savePassword(e: React.FormEvent) {
    e.preventDefault();
    const r = profilePasswordSchema(settingPassword).safeParse(pw);
    if (!r.success) return setPwErrs(fieldErrors(r.error));
    setPwErrs({});
    setPwSaving(true);
    // Some Auth versions do not add an email identity when an OAuth user sets
    // a password. This presentation-only marker remembers a successful setup.
    const { error } = await supabase.auth.updateUser(
      settingPassword
        ? { password: r.data.password, data: { attendease_password_set: true } }
        : { password: r.data.password, current_password: r.data.current },
    );
    setPwSaving(false);
    if (error) return toast.error(errMsg(error));
    if (settingPassword) setPasswordSet(true);
    toast.success(
      settingPassword
        ? "Password set. You can now also log in with your email and password."
        : "Password changed",
    );
    setPw({ current: "", password: "", confirm: "" });
    qc.invalidateQueries();
  }

  return (
    <div className="max-w-3xl">
      <PageHeader title="My Profile" description="Manage your personal information and password" />
      <Card className="mb-6">
        <div className="mb-6 flex flex-wrap items-center gap-4">
          <div
            role="button"
            tabIndex={0}
            aria-label="Change profile photo"
            title="Click or drop an image to change your photo"
            onClick={() => fileInput.current?.click()}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                fileInput.current?.click();
              }
            }}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              pickFile(e.dataTransfer.files?.[0]);
            }}
            className={`relative cursor-pointer rounded-full outline-none ring-offset-background transition focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${dragging ? "ring-2 ring-primary ring-offset-2" : ""}`}
          >
            <UserAvatar
              name={f.full_name || "Unnamed user"}
              avatarUrl={preview ?? avatarUrl}
              version={auth.profile?.updated_at}
              size="lg"
            />
            <span className="absolute -bottom-1 -right-1 flex size-7 items-center justify-center rounded-full border bg-background text-muted-foreground shadow-sm">
              {uploading ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : (
                <ImagePlus className="size-3.5" />
              )}
            </span>
          </div>
          <input
            ref={fileInput}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="hidden"
            aria-hidden="true"
            tabIndex={-1}
            onChange={(e) => {
              pickFile(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
          <div className="min-w-40 flex-1">
            <p className="font-semibold">{f.full_name || "Unnamed user"}</p>
            <p className="text-sm text-muted-foreground">{auth.user.email}</p>
            <span className="mt-1 inline-block rounded-full bg-secondary px-2 py-0.5 text-xs font-medium capitalize">
              {auth.role}
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {pendingFile ? (
              <>
                <Button type="button" size="sm" onClick={saveAvatar} disabled={uploading}>
                  {uploading && <Loader2 className="animate-spin" />} Save photo
                </Button>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={cancelPreview}
                  disabled={uploading}
                >
                  Cancel
                </Button>
              </>
            ) : (
              <>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => fileInput.current?.click()}
                  disabled={uploading}
                >
                  <ImagePlus /> Change photo
                </Button>
                {avatarUrl && (
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={removeAvatar}
                    disabled={uploading}
                  >
                    {uploading ? <Loader2 className="animate-spin" /> : <Trash2 />} Remove photo
                  </Button>
                )}
              </>
            )}
          </div>
        </div>
        {pendingFile && (
          <p className="mb-4 text-sm text-muted-foreground">
            Previewing new photo — save to apply it.
          </p>
        )}
        <form onSubmit={saveProfile} className="grid gap-4" noValidate>
          <div>
            <Label htmlFor="fn">Full name</Label>
            <Input
              id="fn"
              value={f.full_name}
              onChange={(e) => {
                nameDirty.current = true;
                setF({ ...f, full_name: e.target.value });
              }}
              className="mt-1"
            />
            <FieldError msg={errs.full_name} />
          </div>
          <div>
            <Label>Email</Label>
            <Input value={auth.user.email ?? ""} disabled className="mt-1" />
          </div>
          <div>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="animate-spin" />} Save changes
            </Button>
          </div>
        </form>
      </Card>
      <Card title={settingPassword ? "Set a password" : "Change password"}>
        {settingPassword && (
          <p className="mb-4 text-sm text-muted-foreground">
            You signed in with Google, so you don't have a password yet.
          </p>
        )}
        <form
          onSubmit={savePassword}
          className={`grid gap-4 ${settingPassword ? "sm:grid-cols-2" : "sm:grid-cols-3"}`}
          noValidate
        >
          {!settingPassword && (
            <div>
              <Label htmlFor="cp">Current password</Label>
              <PasswordInput
                id="cp"
                autoComplete="current-password"
                value={pw.current}
                onChange={(e) => setPw({ ...pw, current: e.target.value })}
                className="mt-1"
              />
              <FieldError msg={pwErrs.current} />
            </div>
          )}
          <div>
            <Label htmlFor="np">New password</Label>
            <PasswordInput
              id="np"
              autoComplete="new-password"
              value={pw.password}
              onChange={(e) => setPw({ ...pw, password: e.target.value })}
              className="mt-1"
            />
            <FieldError msg={pwErrs.password} />
          </div>
          <div>
            <Label htmlFor="cf">Confirm new password</Label>
            <PasswordInput
              id="cf"
              autoComplete="new-password"
              value={pw.confirm}
              onChange={(e) => setPw({ ...pw, confirm: e.target.value })}
              className="mt-1"
            />
            <FieldError msg={pwErrs.confirm} />
          </div>
          <p
            className={`text-xs text-muted-foreground ${settingPassword ? "sm:col-span-2" : "sm:col-span-3"}`}
          >
            At least 8 characters, with letters and numbers.
          </p>
          <div className={settingPassword ? "sm:col-span-2" : "sm:col-span-3"}>
            <Button type="submit" disabled={pwSaving}>
              {pwSaving && <Loader2 className="animate-spin" />}{" "}
              {settingPassword ? "Set password" : "Update password"}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
