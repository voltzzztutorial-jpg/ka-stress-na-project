import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { RequireRole } from "@/components/AppLayout";
import { Card, EmptyState, Loading, PageHeader } from "@/components/shared";
import { SearchableSelect } from "@/components/SearchableSelect";
import { UserAvatar } from "@/components/UserAvatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { daysAgo, localDate } from "@/lib/attendance";

export const Route = createFileRoute("/_authenticated/activity")({
  head: () => ({
    meta: [
      { title: "Activity log – AttendEase" },
      { name: "description", content: "Every change made in AttendEase, for administrators." },
      { property: "og:title", content: "Activity log – AttendEase" },
      {
        property: "og:description",
        content: "Every change made in AttendEase, for administrators.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireRole roles={["admin"]}>
      <Activity />
    </RequireRole>
  ),
});

const PER_PAGE = 25;
/** Start of a local calendar day as an instant (users are in UTC+8). */
const dayStart = (d: string) => new Date(`${d}T00:00:00`).toISOString();
const dayEnd = (d: string) => new Date(`${d}T23:59:59.999`).toISOString();

function Activity() {
  const [search, setSearch] = useState("");
  const [term, setTerm] = useState("");
  const [user, setUser] = useState("all");
  const [action, setAction] = useState("all");
  const [from, setFrom] = useState(() => daysAgo(30));
  const [to, setTo] = useState(() => localDate());
  const [page, setPage] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setTerm(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);
  useEffect(() => setPage(0), [term, user, action, from, to]);

  const users = useQuery({
    queryKey: ["activity-users"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id,full_name,email")
        .order("full_name");
      if (error) throw error;
      return data;
    },
  });
  const actions = useQuery({
    queryKey: ["activity-actions"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("activity_actions");
      if (error) throw error;
      return (data ?? []) as string[];
    },
  });

  const logs = useQuery({
    queryKey: ["activity", term, user, action, from, to, page],
    placeholderData: keepPreviousData,
    queryFn: async () => {
      let q = supabase
        .from("activity_logs")
        .select(
          "id,action,entity,details,created_at,user_id,profile:profiles!activity_logs_user_id_fkey(full_name,email,avatar_url,updated_at)",
          { count: "exact" },
        )
        .order("created_at", { ascending: false });
      if (from) q = q.gte("created_at", dayStart(from));
      if (to) q = q.lte("created_at", dayEnd(to));
      if (user !== "all") q = q.eq("user_id", user);
      if (action !== "all") q = q.eq("action", action);
      if (term) {
        const t = term.replace(/[%,()]/g, " ");
        q = q.or(`action.ilike.%${t}%,entity.ilike.%${t}%,details.ilike.%${t}%`);
      }
      const { data, error, count } = await q.range(page * PER_PAGE, page * PER_PAGE + PER_PAGE - 1);
      if (error) throw error;
      return { rows: data ?? [], total: count ?? 0 };
    },
  });

  const total = logs.data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / PER_PAGE));

  return (
    <div className="space-y-6">
      <PageHeader title="Activity log" description="Who did what, and when" />
      <Card>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <Label htmlFor="act-search">Search</Label>
            <div className="relative mt-1">
              <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
              <Input
                id="act-search"
                className="pl-8"
                placeholder="Action, item or details"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
          <div>
            <Label>User</Label>
            <SearchableSelect
              aria-label="User"
              className="mt-1"
              value={user}
              onValueChange={setUser}
              searchPlaceholder="Search name or email"
              loading={users.isLoading}
              noneOption={{ value: "all", label: "All users" }}
              options={(users.data ?? []).map((u) => ({
                value: u.id,
                label: u.full_name || u.email,
                description: u.email,
              }))}
            />
          </div>
          <div>
            <Label>Action</Label>
            <SearchableSelect
              aria-label="Action"
              className="mt-1"
              value={action}
              onValueChange={setAction}
              searchPlaceholder="Search action"
              loading={actions.isLoading}
              noneOption={{ value: "all", label: "All actions" }}
              options={(actions.data ?? []).map((a) => ({ value: a, label: a }))}
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="act-from">From</Label>
              <Input
                id="act-from"
                type="date"
                className="mt-1"
                value={from}
                max={to}
                onChange={(e) => setFrom(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="act-to">To</Label>
              <Input
                id="act-to"
                type="date"
                className="mt-1"
                value={to}
                min={from}
                onChange={(e) => setTo(e.target.value)}
              />
            </div>
          </div>
        </div>
      </Card>
      <Card>
        {logs.isLoading ? (
          <Loading />
        ) : logs.error ? (
          <p className="text-destructive">Couldn't load activity: {logs.error.message}</p>
        ) : !logs.data?.rows.length ? (
          <EmptyState text="No activity matches these filters" />
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>When</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.data.rows.map((l) => {
                  const name = l.profile?.full_name || l.profile?.email || "Deleted user";
                  return (
                    <TableRow key={l.id}>
                      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                        {new Date(l.created_at).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <UserAvatar
                            name={name}
                            avatarUrl={l.profile?.avatar_url}
                            version={l.profile?.updated_at}
                            size="sm"
                          />
                          <span className="text-sm font-medium">{name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">
                        <span className="font-medium capitalize">{l.action}</span> {l.entity}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {l.details || "—"}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
            <div className="mt-4 flex items-center justify-between text-sm">
              <span className="text-muted-foreground">
                {total.toLocaleString()} entries · page {page + 1} of {pages}
              </span>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page === 0}
                  onClick={() => setPage((p) => p - 1)}
                >
                  <ChevronLeft /> Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page + 1 >= pages}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Next <ChevronRight />
                </Button>
              </div>
            </div>
          </>
        )}
      </Card>
    </div>
  );
}
