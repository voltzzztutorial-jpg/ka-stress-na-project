import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, Pencil, Plus, Search, Trash2, UserPlus, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { errMsg, logActivity, useAuth } from "@/lib/auth";
import { DAYS, fieldErrors, subjectSchema } from "@/lib/validation";
import { RequireRole } from "@/components/AppLayout";
import { ConfirmDialog, EmptyState, FieldError, Loading, PageHeader } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StudentAvatar, UserAvatar } from "@/components/UserAvatar";
import { bulkCandidates } from "@/lib/student-workflows";
import { PROGRAMS } from "@/lib/validation";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SearchableSelect } from "@/components/SearchableSelect";
import { activeFaculty, eligibleStudents } from "@/lib/select-options";
import { fetchAllPages } from "@/lib/paging";

export const Route = createFileRoute("/_authenticated/subjects")({
  head: () => ({
    meta: [
      { title: "Subjects – AttendEase" },
      { name: "description", content: "Manage subjects and enrollment." },
      { property: "og:title", content: "Subjects – AttendEase" },
      { property: "og:description", content: "Manage subjects and enrollment." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireRole roles={["admin", "faculty"]}>
      <Subjects />
    </RequireRole>
  ),
});

type Subject = Tables<"subjects">;

function useFaculty() {
  return useQuery({
    queryKey: ["faculty"],
    queryFn: async () => {
      const roles = await fetchAllPages((a, b) =>
        supabase
          .from("user_roles")
          .select("user_id")
          .in("role", ["faculty", "admin"])
          .order("user_id")
          .range(a, b),
      );
      const ids = [...new Set(roles.rows.map((r) => r.user_id))];
      if (!ids.length) return [];
      const { data, error } = await supabase
        .from("profiles")
        .select("id,full_name,email,is_active,avatar_url,updated_at")
        .in("id", ids);
      if (error) throw error;
      return data ?? [];
    },
  });
}

function Subjects() {
  const qc = useQueryClient();
  const { data: auth } = useAuth();
  const isAdmin = auth?.role === "admin";
  const faculty = useFaculty();
  const q = useQuery({
    queryKey: ["subjects"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("subjects")
        .select("*, enrollments(count)")
        .order("subject_code");
      if (error) throw error;
      return data;
    },
  });
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Subject | "new" | null>(null);
  const [enrolling, setEnrolling] = useState<Subject | null>(null);
  const [deleting, setDeleting] = useState<Subject | null>(null);
  const [busy, setBusy] = useState(false);
  const fac = (id: string | null) => faculty.data?.find((f) => f.id === id);
  const fname = (id: string | null) => fac(id)?.full_name || (id ? "Former faculty" : "Unassigned");
  const rows = (q.data ?? []).filter((s) =>
    `${s.subject_code} ${s.subject_name}`.toLowerCase().includes(search.toLowerCase()),
  );

  async function remove() {
    if (!deleting) return;
    setBusy(true);
    const { error } = await supabase.from("subjects").delete().eq("id", deleting.id);
    setBusy(false);
    if (error) return toast.error(errMsg(error));
    toast.success("Subject deleted");
    logActivity("deleted", "subject", deleting.subject_code);
    setDeleting(null);
    qc.invalidateQueries({ queryKey: ["subjects"] });
  }

  return (
    <div>
      <PageHeader
        title="Subjects & Classes"
        description="Schedules, assigned faculty and enrolled students"
        actions={
          isAdmin && (
            <Button onClick={() => setEditing("new")}>
              <Plus /> Add subject
            </Button>
          )
        }
      />
      <div className="relative mb-4 max-w-sm">
        <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
        <Input
          placeholder="Search subjects"
          className="pl-9"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
      {q.isLoading ? (
        <Loading />
      ) : q.isError ? (
        <div role="alert" className="space-y-3">
          <p className="text-destructive">Couldn't load subjects.</p>
          <Button variant="outline" onClick={() => q.refetch()}>
            Try again
          </Button>
        </div>
      ) : !rows.length ? (
        <EmptyState />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {rows.map((s) => {
            const canEdit = isAdmin || s.faculty_id === auth?.user.id;
            return (
              <div key={s.id} className="flex flex-col rounded-xl border bg-card p-5 shadow-card">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-mono text-xs font-semibold text-primary">{s.subject_code}</p>
                    <h3 className="font-semibold">{s.subject_name}</h3>
                  </div>
                  {canEdit && (
                    <span className="rounded-full bg-secondary px-2 py-0.5 text-xs">
                      {(s.enrollments as unknown as { count: number }[])[0]?.count ?? 0} students
                    </span>
                  )}
                </div>
                <dl className="mt-3 space-y-1 text-sm text-muted-foreground">
                  <div>
                    {s.schedule_day} · {s.schedule_time} · {s.room}
                  </div>
                  <div>
                    {s.semester}, {s.school_year}
                  </div>
                  <div className="flex items-center gap-2">
                    Faculty:{" "}
                    {fac(s.faculty_id) && (
                      <UserAvatar
                        name={fname(s.faculty_id)}
                        avatarUrl={fac(s.faculty_id)?.avatar_url}
                        version={fac(s.faculty_id)?.updated_at}
                        size="xs"
                      />
                    )}
                    <span className="text-foreground">{fname(s.faculty_id)}</span>
                  </div>
                </dl>
                <div className="mt-4 flex gap-1 border-t pt-3">
                  {canEdit && (
                    <Button size="sm" variant="outline" onClick={() => setEnrolling(s)}>
                      <UserPlus /> Enrollment
                    </Button>
                  )}
                  {canEdit && (
                    <Button
                      size="icon"
                      variant="ghost"
                      aria-label="Edit"
                      onClick={() => setEditing(s)}
                    >
                      <Pencil />
                    </Button>
                  )}
                  {isAdmin && (
                    <Button
                      size="icon"
                      variant="ghost"
                      aria-label="Delete"
                      className="ml-auto text-destructive"
                      onClick={() => setDeleting(s)}
                    >
                      <Trash2 />
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
      {editing && (
        <SubjectForm
          subject={editing === "new" ? null : editing}
          faculty={activeFaculty(faculty.data ?? [])}
          facultyLoading={faculty.isLoading}
          isAdmin={isAdmin}
          onClose={() => setEditing(null)}
        />
      )}
      {enrolling && <Enrollment subject={enrolling} onClose={() => setEnrolling(null)} />}
      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(o) => !o && setDeleting(null)}
        title="Delete subject?"
        description={`Deleting ${deleting?.subject_code} also removes its enrollments and attendance records.`}
        onConfirm={remove}
        loading={busy}
      />
    </div>
  );
}

function SubjectForm({
  subject,
  faculty,
  facultyLoading,
  isAdmin,
  onClose,
}: {
  subject: Subject | null;
  faculty: {
    id: string;
    full_name: string;
    email: string;
    avatar_url: string | null;
    updated_at: string;
  }[];
  facultyLoading: boolean;
  isAdmin: boolean;
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const [f, setF] = useState({
    subject_code: subject?.subject_code ?? "",
    subject_name: subject?.subject_name ?? "",
    faculty_id: subject?.faculty_id ?? null,
    schedule_day: subject?.schedule_day ?? "Monday",
    schedule_time: subject?.schedule_time ?? "08:00",
    room: subject?.room ?? "",
    semester: subject?.semester ?? "1st Semester",
    school_year: subject?.school_year ?? "2026-2027",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  async function save(e: React.FormEvent) {
    e.preventDefault();
    const r = subjectSchema.safeParse(f);
    if (!r.success) return setErrors(fieldErrors(r.error));
    setErrors({});
    setSaving(true);
    const { error } = subject
      ? await supabase.from("subjects").update(r.data).eq("id", subject.id)
      : await supabase.from("subjects").insert(r.data);
    setSaving(false);
    if (error) {
      const m = errMsg(error);
      if (m.includes("code")) setErrors({ subject_code: m });
      return toast.error(m);
    }
    toast.success(subject ? "Subject updated" : "Subject created");
    logActivity(subject ? "updated" : "created", "subject", r.data.subject_code);
    qc.invalidateQueries({ queryKey: ["subjects"] });
    onClose();
  }
  const text = (k: keyof typeof f, label: string, type = "text", locked = false) => (
    <div>
      <Label htmlFor={k}>{label}</Label>
      <Input
        id={k}
        type={type}
        disabled={locked}
        value={(f[k] as string) ?? ""}
        onChange={(e) => setF({ ...f, [k]: e.target.value })}
        className="mt-1"
      />
      <FieldError msg={errors[k]} />
    </div>
  );
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{subject ? "Edit subject" : "Add subject"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={save} className="grid gap-4 sm:grid-cols-2" noValidate>
          {text("subject_code", "Subject code", "text", !isAdmin && !!subject)}
          {text("room", "Room")}
          <div className="sm:col-span-2">{text("subject_name", "Subject name")}</div>
          <div>
            <Label>Day</Label>
            <Select value={f.schedule_day} onValueChange={(v) => setF({ ...f, schedule_day: v })}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DAYS.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {text("schedule_time", "Time", "time")}
          <div>
            <Label>Semester</Label>
            <Select value={f.semester} onValueChange={(v) => setF({ ...f, semester: v })}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["1st Semester", "2nd Semester", "Summer"].map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {text("school_year", "School year")}
          {isAdmin && (
            <div className="sm:col-span-2">
              <Label>Assigned faculty</Label>
              <SearchableSelect
                aria-label="Assigned faculty"
                className="mt-1"
                value={f.faculty_id ?? "none"}
                onValueChange={(v) => setF({ ...f, faculty_id: v === "none" ? null : v })}
                loading={facultyLoading}
                searchPlaceholder="Search faculty name or email"
                noneOption={{ value: "none", label: "Unassigned" }}
                options={faculty.map((p) => ({
                  value: p.id,
                  label: p.full_name || p.email,
                  description: p.email,
                  leading: (
                    <UserAvatar
                      name={p.full_name || "Unnamed user"}
                      avatarUrl={p.avatar_url}
                      version={p.updated_at}
                      size="xs"
                    />
                  ),
                }))}
              />
            </div>
          )}
          <DialogFooter className="sm:col-span-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="animate-spin" />} Save
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function Enrollment({ subject, onClose }: { subject: Subject; onClose: () => void }) {
  const qc = useQueryClient();
  const [pick, setPick] = useState("");
  const [removing, setRemoving] = useState<string | null>(null);
  const [dropBusy, setDropBusy] = useState(false);
  const enrolled = useQuery({
    queryKey: ["enrollments", subject.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("enrollments")
        .select(
          "id, students(id,first_name,last_name,student_number,user_id,profile:profiles!students_user_id_fkey(avatar_url,updated_at))",
        )
        .eq("subject_id", subject.id);
      if (error) throw error;
      return data ?? [];
    },
  });
  const all = useQuery({
    queryKey: ["students", "all"],
    queryFn: async () => {
      const { rows } = await fetchAllPages((a, b) =>
        supabase
          .from("students")
          .select("*,profile:profiles!students_user_id_fkey(avatar_url,updated_at)")
          .order("last_name")
          .order("id")
          .range(a, b),
      );
      return rows;
    },
  });
  const queryError = enrolled.isError || all.isError;
  const ids = new Set((enrolled.data ?? []).map((e) => e.students?.id));
  const available = eligibleStudents(all.data ?? [], ids);
  const [bulk, setBulk] = useState({ program: PROGRAMS[0], year: "1", section: "" });
  const [bulkBusy, setBulkBusy] = useState(false);
  const bulkPlan = bulkCandidates(all.data ?? [], ids, bulk.program, bulk.year, bulk.section);
  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["enrollments", subject.id] });
    qc.invalidateQueries({ queryKey: ["subjects"] });
  };

  async function add() {
    if (!pick) return;
    const { error } = await supabase
      .from("enrollments")
      .insert({ subject_id: subject.id, student_id: pick });
    if (error) return toast.error(errMsg(error));
    toast.success("Student enrolled");
    logActivity("enrolled", "student", subject.subject_code);
    setPick("");
    refresh();
  }
  async function bulkEnroll() {
    if (!bulkPlan.candidates.length) return;
    setBulkBusy(true);
    const { data, error } = await supabase
      .from("enrollments")
      .upsert(
        bulkPlan.candidates.map((st) => ({ subject_id: subject.id, student_id: st.id })),
        { onConflict: "student_id,subject_id", ignoreDuplicates: true },
      )
      .select("id");
    setBulkBusy(false);
    if (error) return toast.error(errMsg(error));
    const added = data?.length ?? 0;
    toast.success(`${added} student(s) enrolled`);
    logActivity("bulk enrolled", "student", `${added} into ${subject.subject_code}`);
    refresh();
  }
  async function drop() {
    if (!removing) return;
    setDropBusy(true);
    const { error } = await supabase.from("enrollments").delete().eq("id", removing);
    setDropBusy(false);
    if (error) return toast.error(errMsg(error));
    setRemoving(null);
    toast.success("Student removed from class");
    refresh();
  }
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Enrollment · {subject.subject_code}</DialogTitle>
        </DialogHeader>
        {queryError && (
          <p className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
            Couldn't load students. Close and try again.
          </p>
        )}
        <Tabs defaultValue="single">
          <TabsList>
            <TabsTrigger value="single">Enroll one</TabsTrigger>
            <TabsTrigger value="bulk">Bulk enroll</TabsTrigger>
          </TabsList>
          <TabsContent value="single" className="space-y-3">
            <div className="flex gap-2">
              <SearchableSelect
                aria-label="Enroll student"
                value={pick}
                onValueChange={setPick}
                placeholder="Select a student to enroll"
                searchPlaceholder="Search name, student number or email"
                loading={all.isLoading || enrolled.isFetching}
                options={available.map((s) => ({
                  value: s.id,
                  label: `${s.last_name}, ${s.first_name}`,
                  description: `${s.student_number} · ${s.program}`,
                  searchText: s.email,
                  leading: (
                    <StudentAvatar
                      name={`${s.first_name} ${s.last_name}`}
                      profile={s.profile}
                      linked={!!s.user_id}
                      size="xs"
                    />
                  ),
                }))}
              />
              <Button
                onClick={add}
                disabled={
                  queryError || !available.some((s) => s.id === pick) || enrolled.isFetching
                }
              >
                <UserPlus /> Enroll
              </Button>
            </div>
            <div className="max-h-80 overflow-y-auto">
              {enrolled.isLoading ? (
                <Loading />
              ) : !enrolled.data?.length ? (
                <EmptyState text="No students enrolled" />
              ) : (
                <ul className="divide-y text-sm">
                  {enrolled.data.map((e) => (
                    <li key={e.id} className="flex items-center justify-between py-2">
                      <span className="flex items-center gap-2">
                        {e.students && (
                          <StudentAvatar
                            name={`${e.students.first_name} ${e.students.last_name}`}
                            profile={e.students.profile}
                            linked={!!e.students.user_id}
                            size="xs"
                          />
                        )}
                        <span>
                          {e.students?.last_name}, {e.students?.first_name}{" "}
                          <span className="text-xs text-muted-foreground">
                            {e.students?.student_number}
                          </span>
                        </span>
                      </span>
                      <Button
                        size="icon"
                        variant="ghost"
                        aria-label="Remove"
                        onClick={() => setRemoving(e.id)}
                      >
                        <X />
                      </Button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </TabsContent>
          <TabsContent value="bulk" className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-3">
              <div>
                <Label>Program</Label>
                <Select
                  value={bulk.program}
                  onValueChange={(v) => setBulk({ ...bulk, program: v })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PROGRAMS.map((v) => (
                      <SelectItem key={v} value={v}>
                        {v}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Year level</Label>
                <Select value={bulk.year} onValueChange={(v) => setBulk({ ...bulk, year: v })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {["1", "2", "3", "4", "5"].map((v) => (
                      <SelectItem key={v} value={v}>
                        {v}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="bulk-section">Section (optional)</Label>
                <Input
                  id="bulk-section"
                  className="mt-1"
                  value={bulk.section}
                  onChange={(e) => setBulk({ ...bulk, section: e.target.value })}
                />
              </div>
            </div>
            <p className="rounded-lg bg-muted p-3 text-sm">
              {bulkPlan.candidates.length} students will be enrolled, {bulkPlan.skipped} already
              enrolled are skipped
            </p>
            <div className="flex max-h-48 flex-wrap gap-2 overflow-y-auto">
              {bulkPlan.candidates.map((st) => (
                <span
                  key={st.id}
                  className="flex items-center gap-1 rounded-full border px-2 py-1 text-xs"
                >
                  <StudentAvatar
                    name={`${st.first_name} ${st.last_name}`}
                    profile={st.profile}
                    linked={!!st.user_id}
                    size="xs"
                  />
                  {st.last_name}, {st.first_name}
                </span>
              ))}
            </div>
            <Button
              onClick={bulkEnroll}
              disabled={
                queryError ||
                !bulkPlan.candidates.length ||
                bulkBusy ||
                all.isLoading ||
                enrolled.isFetching
              }
            >
              {bulkBusy && <Loader2 className="animate-spin" />} Confirm bulk enrollment
            </Button>
          </TabsContent>
        </Tabs>
        <ConfirmDialog
          open={!!removing}
          onOpenChange={(open) => !open && setRemoving(null)}
          title="Remove student from class?"
          description="Existing attendance records for this student in this subject are kept. New marks can no longer be added; staff can still correct or delete existing records."
          confirmLabel="Remove"
          onConfirm={drop}
          loading={dropBusy}
        />
      </DialogContent>
    </Dialog>
  );
}
