import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, useBlocker } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCheck, Loader2, Pencil, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { errMsg, logActivity, useAuth } from "@/lib/auth";
import { RequireRole } from "@/components/AppLayout";
import {
  Card,
  ConfirmDialog,
  EmptyState,
  Loading,
  PageHeader,
  StatusBadge,
  type Status,
} from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { daysAgo, localDate } from "@/lib/attendance";
import { useMySubjects } from "@/lib/my-subjects";
import { clampPage, markUnmarkedPresent } from "@/lib/record-controls";
import { StudentAvatar } from "@/components/UserAvatar";
import type { AvatarProfile } from "@/lib/avatar";
import { changedMarkIds, marksChanged } from "@/lib/student-workflows";
import { SearchableSelect } from "@/components/SearchableSelect";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/_authenticated/attendance")({
  head: () => ({
    meta: [
      { title: "Attendance – AttendEase" },
      { name: "description", content: "Mark and manage class attendance." },
      { property: "og:title", content: "Attendance – AttendEase" },
      { property: "og:description", content: "Mark and manage class attendance." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  validateSearch: (search: Record<string, unknown>) => ({
    subject: typeof search.subject === "string" ? search.subject : undefined,
    date:
      typeof search.date === "string" && isRealDate(search.date) && search.date <= localDate()
        ? search.date
        : undefined,
  }),
  component: () => (
    <RequireRole roles={["admin", "faculty"]}>
      <AttendancePage />
    </RequireRole>
  ),
});

/** True for a real calendar date in YYYY-MM-DD form (rejects e.g. 2026-02-31). */
function isRealDate(v: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const [y, m, d] = v.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

const STATUSES: Status[] = ["present", "absent", "late", "excused"];
const today = () => localDate();
const ROW_LIMIT = 1000;
const tone: Record<Status, string> = {
  present: "bg-present text-primary-foreground border-present",
  absent: "bg-absent text-primary-foreground border-absent",
  late: "bg-late text-foreground border-late",
  excused: "bg-excused text-primary-foreground border-excused",
};

function AttendancePage() {
  const [tab, setTab] = useState("mark");
  const [dirty, setDirty] = useState(false);
  const [pending, setPending] = useState<(() => void) | null>(null);
  const blocker = useBlocker({
    shouldBlockFn: () => dirty,
    enableBeforeUnload: dirty,
    withResolver: true,
  });
  const discardRef = useRef<() => void>(() => {});
  function guard(action: () => void) {
    if (dirty) setPending(() => action);
    else action();
  }
  function discard() {
    discardRef.current();
    setDirty(false);
    if (blocker.status === "blocked") blocker.proceed();
    pending?.();
    setPending(null);
  }
  return (
    <div>
      <PageHeader
        title="Attendance"
        description="Record attendance per class session and manage past records"
      />
      <Tabs value={tab} onValueChange={(v) => guard(() => setTab(v))}>
        <TabsList className="mb-4">
          <TabsTrigger value="mark">Mark attendance</TabsTrigger>
          <TabsTrigger value="records">Records</TabsTrigger>
        </TabsList>
        <TabsContent forceMount value="mark" className="data-[state=inactive]:hidden">
          <MarkAttendance onDirty={setDirty} guard={guard} discardRef={discardRef} />
        </TabsContent>
        <TabsContent value="records">
          <Records />
        </TabsContent>
      </Tabs>
      <AlertDialog
        open={!!pending || blocker.status === "blocked"}
        onOpenChange={(open) => {
          if (!open) {
            setPending(null);
            if (blocker.status === "blocked") blocker.reset();
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Discard unsaved attendance?</AlertDialogTitle>
            <AlertDialogDescription>
              Your unsaved marks and remarks will be lost.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep editing</AlertDialogCancel>
            <AlertDialogAction onClick={discard}>Discard changes</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function SubjectSelect({
  value,
  onChange,
  allowAll,
}: {
  value: string;
  onChange: (v: string) => void;
  allowAll?: boolean;
}) {
  const subjects = useMySubjects();
  return (
    <SearchableSelect
      aria-label="Subject"
      value={value}
      onValueChange={onChange}
      className="mt-1"
      placeholder="Select a subject"
      searchPlaceholder="Search subject code or name"
      loading={subjects.isLoading}
      noneOption={allowAll ? { value: "all", label: "All subjects" } : undefined}
      options={(subjects.data ?? []).map((s) => ({
        value: s.id,
        label: `${s.subject_code} – ${s.subject_name}`,
        description: `${s.schedule_day} · ${s.schedule_time}${s.room ? ` · ${s.room}` : ""}`,
      }))}
    />
  );
}

function MarkAttendance({
  onDirty,
  guard,
  discardRef,
}: {
  onDirty: (dirty: boolean) => void;
  guard: (action: () => void) => void;
  discardRef: React.MutableRefObject<() => void>;
}) {
  const qc = useQueryClient();
  const { data: auth } = useAuth();
  const searchParams = Route.useSearch();
  const [subject, setSubject] = useState(searchParams.subject ?? "");
  const [date, setDate] = useState(searchParams.date ?? today());
  const [marks, setMarks] = useState<Record<string, { status: Status; remarks: string }>>({});
  const [saving, setSaving] = useState(false);
  const [baseline, setBaseline] = useState<Record<string, { status: Status; remarks: string }>>({});
  const dirty = marksChanged(marks, baseline);
  const dirtyRef = useRef(dirty);
  dirtyRef.current = dirty;
  useEffect(() => {
    onDirty(dirty);
  }, [dirty, onDirty]);
  discardRef.current = () => {
    setMarks(baseline);
  };
  function changeScope(action: () => void) {
    guard(() => {
      setMarks({});
      setBaseline({});
      action();
    });
  }

  const roster = useQuery({
    queryKey: ["roster", subject, date],
    enabled: !!subject && !!date,
    queryFn: async () => {
      const [en, at] = await Promise.all([
        supabase
          .from("enrollments")
          .select(
            "student_id, students(id,student_number,first_name,last_name,status,user_id,profile:profiles!students_user_id_fkey(avatar_url,updated_at))",
          )
          .eq("subject_id", subject),
        supabase
          .from("attendance")
          .select("student_id,status,remarks")
          .eq("subject_id", subject)
          .eq("attendance_date", date),
      ]);
      if (en.error) throw en.error;
      if (at.error) throw at.error;
      const students = (en.data ?? [])
        .map((e) => e.students)
        .filter((s): s is NonNullable<typeof s> => !!s && s.status === "active")
        .sort((a, b) => a.last_name.localeCompare(b.last_name));
      return { students, existing: at.data ?? [] };
    },
  });

  useEffect(() => {
    if (!roster.data || dirtyRef.current) return;
    const m: Record<string, { status: Status; remarks: string }> = {};
    for (const e of roster.data.existing.filter((e) =>
      roster.data?.students.some((s) => s.id === e.student_id),
    ))
      m[e.student_id] = { status: e.status as Status, remarks: e.remarks ?? "" };
    setMarks(m);
    setBaseline(m);
  }, [roster.data]);

  const marked = Object.keys(marks).length;
  const total = roster.data?.students.length ?? 0;

  function markAll() {
    setMarks(markUnmarkedPresent(marks, roster.data?.students ?? []));
  }

  const [askUnmarked, setAskUnmarked] = useState(false);
  function requestSave() {
    if (!marked) return toast.error("Mark at least one student first.");
    if (marked < total) return setAskUnmarked(true);
    save(false);
  }

  async function save(fillAbsent: boolean) {
    setAskUnmarked(false);
    const all = { ...marks };
    if (fillAbsent)
      for (const s of roster.data?.students ?? [])
        if (!all[s.id]) all[s.id] = { status: "absent", remarks: "" };
    // Only upsert rows whose status or remarks changed, so untouched rows keep
    // their original time_recorded and recorded_by.
    const changed = changedMarkIds(all, baseline);
    const rows = changed.map((student_id) => ({
      student_id,
      subject_id: subject,
      attendance_date: date,
      status: all[student_id].status,
      remarks: all[student_id].remarks.trim() || null,
      recorded_by: auth?.user.id ?? null,
      time_recorded: new Date().toTimeString().slice(0, 8),
    }));
    if (!rows.length) {
      onDirty(false);
      return toast.success("No changes to save.");
    }
    setSaving(true);
    const { error } = await supabase
      .from("attendance")
      .upsert(rows, { onConflict: "student_id,subject_id,attendance_date" });
    setSaving(false);
    if (error) return toast.error(errMsg(error));
    setMarks(all);
    setBaseline(all);
    onDirty(false);
    toast.success(`Attendance saved for ${rows.length} student(s)`);
    logActivity("recorded", "attendance", `${rows.length} records on ${date}`);
    qc.invalidateQueries();
  }

  return (
    <Card>
      <div className="grid gap-4 sm:grid-cols-[1fr_200px]">
        <div>
          <Label>Subject</Label>
          <SubjectSelect value={subject} onChange={(v) => changeScope(() => setSubject(v))} />
        </div>
        <div>
          <Label htmlFor="date">Date</Label>
          <Input
            id="date"
            type="date"
            max={today()}
            value={date}
            onChange={(e) => {
              const v = e.target.value;
              if (v && v > today())
                return toast.error("You can't record attendance for a future date.");
              changeScope(() => setDate(v));
            }}
            className="mt-1"
          />
        </div>
      </div>
      <AlertDialog open={askUnmarked} onOpenChange={setAskUnmarked}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{total - marked} student(s) not marked</AlertDialogTitle>
            <AlertDialogDescription>
              Mark the remaining students as Absent, or save only the students you've marked?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Go back</AlertDialogCancel>
            <Button variant="outline" onClick={() => save(false)}>
              Save marked only
            </Button>
            <AlertDialogAction onClick={() => save(true)}>
              Mark rest Absent & save
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      {!subject ? (
        <EmptyState text="Choose a subject and date to load the class list." />
      ) : !date ? (
        <EmptyState text="Choose a date." />
      ) : roster.isLoading ? (
        <Loading />
      ) : roster.isError ? (
        <EmptyState text="Couldn't load the class list. Please try again." />
      ) : !total ? (
        <EmptyState text="No students are enrolled in this subject yet." />
      ) : (
        <>
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <p className="text-sm text-muted-foreground">
              {marked} of {total} marked
            </p>
            <Button variant="outline" size="sm" className="ml-auto" onClick={markAll}>
              <CheckCheck /> Mark unmarked as present
            </Button>
            <Button size="sm" onClick={requestSave} disabled={saving}>
              {saving ? <Loader2 className="animate-spin" /> : <Save />} Save
            </Button>
          </div>
          <div className="mt-3 divide-y rounded-lg border">
            {(roster.data?.students ?? []).map((s) => {
              const cur = marks[s.id];
              return (
                <div key={s.id} className="flex flex-col gap-2 p-3 md:flex-row md:items-center">
                  <div className="flex min-w-0 items-center gap-2 md:w-56">
                    <StudentAvatar
                      name={`${s.first_name} ${s.last_name}`}
                      profile={s.profile}
                      linked={!!s.user_id}
                      preview
                      number={s.student_number}
                    />
                    <div>
                      <p className="font-medium">
                        {s.last_name}, {s.first_name}
                      </p>
                      <p className="font-mono text-xs text-muted-foreground">{s.student_number}</p>
                    </div>
                  </div>
                  <div
                    className="flex flex-wrap gap-1"
                    role="radiogroup"
                    aria-label={`Status for ${s.first_name}`}
                  >
                    {STATUSES.map((st) => (
                      <button
                        key={st}
                        type="button"
                        role="radio"
                        aria-checked={cur?.status === st}
                        onClick={() =>
                          setMarks({
                            ...marks,
                            [s.id]: { status: st, remarks: cur?.remarks ?? "" },
                          })
                        }
                        className={cn(
                          "rounded-md border px-3 py-1 text-xs font-semibold capitalize transition-colors",
                          cur?.status === st ? tone[st] : "bg-card hover:bg-muted",
                        )}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                  <Input
                    placeholder="Remarks (optional)"
                    className="md:ml-auto md:max-w-xs"
                    value={cur?.remarks ?? ""}
                    disabled={!cur}
                    onChange={(e) =>
                      cur && setMarks({ ...marks, [s.id]: { ...cur, remarks: e.target.value } })
                    }
                  />
                </div>
              );
            })}
          </div>
        </>
      )}
    </Card>
  );
}

type Rec = {
  id: string;
  attendance_date: string;
  time_recorded: string;
  status: Status;
  remarks: string | null;
  students: {
    first_name: string;
    last_name: string;
    student_number: string;
    user_id: string | null;
    profile?: AvatarProfile | null;
  } | null;
  subjects: { subject_code: string } | null;
};

function Records() {
  const qc = useQueryClient();
  const subjects = useMySubjects();
  const [subject, setSubject] = useState("all");
  const [status, setStatus] = useState("all");
  const [from, setFrom] = useState(() => daysAgo(30));
  const [to, setTo] = useState(today());
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [editing, setEditing] = useState<Rec | null>(null);
  const [deleting, setDeleting] = useState<Rec | null>(null);
  const [busy, setBusy] = useState(false);
  const ids = useMemo(() => (subjects.data ?? []).map((s) => s.id), [subjects.data]);

  const q = useQuery({
    queryKey: ["attendance-records", subject, status, from, to, ids],
    enabled: subjects.isSuccess,
    queryFn: async () => {
      if (!ids.length) return [] as Rec[];
      let qq = supabase
        .from("attendance")
        .select(
          "id,attendance_date,time_recorded,status,remarks,students(first_name,last_name,student_number,user_id,profile:profiles!students_user_id_fkey(avatar_url,updated_at)),subjects(subject_code)",
        )
        .gte("attendance_date", from)
        .lte("attendance_date", to)
        .order("attendance_date", { ascending: false })
        .limit(ROW_LIMIT);
      qq = subject === "all" ? qq.in("subject_id", ids) : qq.eq("subject_id", subject);
      if (status !== "all") qq = qq.eq("status", status as Status);
      const { data, error } = await qq;
      if (error) throw error;
      return data as unknown as Rec[];
    },
  });
  const rows = (q.data ?? []).filter((r) =>
    `${r.students?.first_name} ${r.students?.last_name} ${r.students?.student_number}`
      .toLowerCase()
      .includes(search.toLowerCase()),
  );
  const PER = 15;
  const pages = Math.max(1, Math.ceil(rows.length / PER));
  const currentPage = clampPage(page, pages);
  const shown = rows.slice(currentPage * PER, currentPage * PER + PER);
  useEffect(() => {
    if (page >= pages) setPage(pages - 1);
  }, [page, pages]);

  async function remove() {
    if (!deleting) return;
    setBusy(true);
    const { error } = await supabase.from("attendance").delete().eq("id", deleting.id);
    setBusy(false);
    if (error) return toast.error(errMsg(error));
    toast.success("Record deleted");
    logActivity(
      "deleted",
      "attendance",
      `${deleting.students?.student_number} ${deleting.attendance_date}`,
    );
    setDeleting(null);
    qc.invalidateQueries();
  }

  return (
    <Card>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <Label>Subject</Label>
          <SubjectSelect
            value={subject}
            onChange={(v) => {
              setSubject(v);
              setPage(0);
            }}
            allowAll
          />
        </div>
        <div>
          <Label>Status</Label>
          <Select
            value={status}
            onValueChange={(v) => {
              setStatus(v);
              setPage(0);
            }}
          >
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {STATUSES.map((s) => (
                <SelectItem key={s} value={s} className="capitalize">
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="from">From</Label>
          <Input
            id="from"
            type="date"
            value={from}
            max={to}
            onChange={(e) => {
              if (e.target.value) {
                setFrom(e.target.value);
                setPage(0);
              }
            }}
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="to">To</Label>
          <Input
            id="to"
            type="date"
            value={to}
            min={from}
            max={today()}
            onChange={(e) => {
              if (e.target.value) {
                setTo(e.target.value);
                setPage(0);
              }
            }}
            className="mt-1"
          />
        </div>
      </div>
      <Input
        placeholder="Search student name or number"
        className="mt-3 max-w-sm"
        value={search}
        onChange={(e) => {
          setSearch(e.target.value);
          setPage(0);
        }}
      />
      {q.isLoading ? (
        <Loading />
      ) : q.isError ? (
        <EmptyState text="Couldn't load records." />
      ) : !rows.length ? (
        <EmptyState />
      ) : (
        <>
          <div className="mt-4 overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Student</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Remarks</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {shown.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="whitespace-nowrap">
                      {r.attendance_date}
                      <span className="block text-xs text-muted-foreground">
                        {r.time_recorded?.slice(0, 5)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <StudentAvatar
                          name={`${r.students?.first_name ?? ""} ${r.students?.last_name ?? ""}`}
                          profile={r.students?.profile}
                          linked={!!r.students?.user_id}
                          preview
                          number={r.students?.student_number}
                          size="xs"
                        />
                        <div>
                          {r.students?.last_name}, {r.students?.first_name}
                          <span className="block font-mono text-xs text-muted-foreground">
                            {r.students?.student_number}
                          </span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{r.subjects?.subject_code}</TableCell>
                    <TableCell>
                      <StatusBadge status={r.status} />
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">
                      {r.remarks || "—"}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="icon"
                        variant="ghost"
                        aria-label="Edit"
                        onClick={() => setEditing(r)}
                      >
                        <Pencil />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        aria-label="Delete"
                        className="text-destructive"
                        onClick={() => setDeleting(r)}
                      >
                        <Trash2 />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="mt-3 flex items-center justify-between text-sm text-muted-foreground">
            <span>
              {rows.length} record(s)
              {(q.data?.length ?? 0) >= ROW_LIMIT && (
                <span className="ml-2 font-medium text-late">
                  Showing the newest {ROW_LIMIT} records only — narrow the date range to see older
                  ones.
                </span>
              )}
            </span>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                disabled={page === 0}
                onClick={() => setPage(page - 1)}
              >
                Previous
              </Button>
              <span>
                Page {currentPage + 1} of {pages}
              </span>
              <Button
                size="sm"
                variant="outline"
                disabled={page >= pages - 1}
                onClick={() => setPage(page + 1)}
              >
                Next
              </Button>
            </div>
          </div>
        </>
      )}
      {editing && <EditRecord rec={editing} onClose={() => setEditing(null)} />}
      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(o) => !o && setDeleting(null)}
        title="Delete attendance record?"
        description="This permanently removes the record."
        onConfirm={remove}
        loading={busy}
      />
    </Card>
  );
}

function EditRecord({ rec, onClose }: { rec: Rec; onClose: () => void }) {
  const qc = useQueryClient();
  const [status, setStatus] = useState<Status>(rec.status);
  const [remarks, setRemarks] = useState(rec.remarks ?? "");
  const [saving, setSaving] = useState(false);
  async function save() {
    setSaving(true);
    const { error } = await supabase
      .from("attendance")
      .update({ status, remarks: remarks.trim() || null })
      .eq("id", rec.id);
    setSaving(false);
    if (error) return toast.error(errMsg(error));
    toast.success("Record updated");
    logActivity("updated", "attendance", `${rec.students?.student_number} ${rec.attendance_date}`);
    qc.invalidateQueries();
    onClose();
  }
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            Edit record – {rec.students?.first_name} {rec.students?.last_name}
          </DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">
          {rec.subjects?.subject_code} · {rec.attendance_date}
        </p>
        <div>
          <Label>Status</Label>
          <Select value={status} onValueChange={(v) => setStatus(v as Status)}>
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {STATUSES.map((s) => (
                <SelectItem key={s} value={s} className="capitalize">
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="rem">Remarks</Label>
          <Input
            id="rem"
            value={remarks}
            maxLength={200}
            onChange={(e) => setRemarks(e.target.value)}
            className="mt-1"
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} disabled={saving}>
            {saving && <Loader2 className="animate-spin" />} Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
