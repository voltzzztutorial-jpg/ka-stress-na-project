import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Archive,
  RotateCcw,
  ArrowUpDown,
  Eye,
  Loader2,
  Pencil,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { errMsg, logActivity, useAuth } from "@/lib/auth";
import { fieldErrors, PROGRAMS, studentSchema } from "@/lib/validation";
import { RequireRole } from "@/components/AppLayout";
import { StudentAvatar } from "@/components/UserAvatar";
import type { AvatarProfile } from "@/lib/avatar";
import {
  Card,
  ConfirmDialog,
  EmptyState,
  FieldError,
  Loading,
  PageHeader,
} from "@/components/shared";
import { compareValues } from "@/lib/record-controls";
import { fetchAllPages, MAX_ROWS } from "@/lib/paging";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/students")({
  head: () => ({
    meta: [
      { title: "Students – AttendEase" },
      { name: "description", content: "Manage student records." },
      { property: "og:title", content: "Students – AttendEase" },
      { property: "og:description", content: "Manage student records." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireRole roles={["admin", "faculty"]}>
      <Students />
    </RequireRole>
  ),
});

type Student = Tables<"students"> & { profile?: AvatarProfile | null };
const empty = {
  student_number: "",
  first_name: "",
  last_name: "",
  email: "",
  program: "BSIT",
  year_level: "1",
  section: "A",
  status: "active",
};
const PAGE = 10;

function Students() {
  const qc = useQueryClient();
  const { data: auth } = useAuth();
  const isAdmin = auth?.role === "admin";
  const q = useQuery({
    queryKey: ["students"],
    queryFn: async () => {
      const { rows, truncated } = await fetchAllPages<Student>(
        (a, b) =>
          supabase
            .from("students")
            .select("*,profile:profiles!students_user_id_fkey(avatar_url,updated_at)")
            .order("last_name")
            .order("id")
            .range(a, b) as unknown as PromiseLike<{
            data: Student[] | null;
            error: { message: string } | null;
          }>,
      );
      return { rows, truncated };
    },
  });
  const [search, setSearch] = useState("");
  const [program, setProgram] = useState("all");
  const [year, setYear] = useState("all");
  const [status, setStatus] = useState("active");
  const [sort, setSort] = useState<{ k: keyof Student; asc: boolean }>({
    k: "last_name",
    asc: true,
  });
  const [page, setPage] = useState(0);
  const [editing, setEditing] = useState<Student | "new" | null>(null);
  const [viewing, setViewing] = useState<Student | null>(null);
  const [deleting, setDeleting] = useState<Student | null>(null);
  const [archiving, setArchiving] = useState<Student | null>(null);
  const [busy, setBusy] = useState(false);

  const filtered = useMemo(() => {
    const s = search.toLowerCase();
    return (q.data?.rows ?? [])
      .filter(
        (r) =>
          !s ||
          `${r.first_name} ${r.last_name} ${r.student_number} ${r.email}`.toLowerCase().includes(s),
      )
      .filter((r) => program === "all" || r.program === program)
      .filter((r) => year === "all" || String(r.year_level) === year)
      .filter((r) => status === "all" || r.status === status)
      .sort((a, b) => compareValues(a[sort.k], b[sort.k], sort.asc));
  }, [q.data, search, program, year, status, sort]);
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE));
  const rows = filtered.slice(page * PAGE, page * PAGE + PAGE);
  // Clamp the page after archive/restore/delete shrinks the list.
  useEffect(() => {
    if (page >= pages) setPage(pages - 1);
  }, [page, pages]);

  async function setArchived(student: Student, archived: boolean) {
    setBusy(true);
    const { error } = await supabase
      .from("students")
      .update({ status: archived ? "inactive" : "active" })
      .eq("id", student.id);
    setBusy(false);
    if (error) return toast.error(errMsg(error));
    toast.success(archived ? "Student archived" : "Student restored");
    logActivity(
      archived ? "archived" : "restored",
      "student",
      `${student.first_name} ${student.last_name}`,
    );
    setArchiving(null);
    qc.invalidateQueries();
  }

  async function remove() {
    if (!deleting) return;
    setBusy(true);
    const { error } = await supabase.from("students").delete().eq("id", deleting.id);
    setBusy(false);
    if (error) return toast.error(errMsg(error));
    toast.success("Student deleted");
    logActivity("deleted", "student", `${deleting.first_name} ${deleting.last_name}`);
    setDeleting(null);
    // Permanent delete cascades attendance, so refresh every query.
    qc.invalidateQueries();
  }

  const th = (k: keyof Student, label: string) => (
    <th className="px-3 py-2">
      <button
        className="flex items-center gap-1"
        onClick={() => setSort({ k, asc: sort.k === k ? !sort.asc : true })}
      >
        {label}
        <ArrowUpDown className="size-3" />
      </button>
    </th>
  );

  return (
    <div>
      <PageHeader
        title="Students"
        description={`${q.data?.rows.length ?? 0} students on record`}
        actions={
          <Button onClick={() => setEditing("new")}>
            <Plus /> Add student
          </Button>
        }
      />
      {q.data?.truncated && (
        <p role="status" className="mb-4 rounded-lg border border-late/40 bg-late/10 p-3 text-sm">
          Showing the first {MAX_ROWS.toLocaleString()} students only. Use the search and filters to
          narrow the list.
        </p>
      )}
      <Card>
        <div className="mb-4 grid gap-3 md:grid-cols-[1fr_auto_auto_auto]">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
            <Input
              placeholder="Search name, number or email"
              className="pl-9"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(0);
              }}
            />
          </div>
          <Filter
            value={program}
            onChange={(v) => {
              setProgram(v);
              setPage(0);
            }}
            label="Program"
            options={PROGRAMS}
          />
          <Filter
            value={year}
            onChange={(v) => {
              setYear(v);
              setPage(0);
            }}
            label="Year"
            options={["1", "2", "3", "4", "5"]}
          />
          <Filter
            value={status}
            onChange={(v) => {
              setStatus(v);
              setPage(0);
            }}
            label="Status"
            options={[
              { value: "active", label: "Active" },
              { value: "inactive", label: "Archived" },
            ]}
          />
        </div>
        {q.isLoading ? (
          <Loading />
        ) : q.error ? (
          <p className="text-destructive">{errMsg(q.error)}</p>
        ) : !rows.length ? (
          <EmptyState />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/60 text-left text-muted-foreground">
                <tr>
                  {th("student_number", "No.")}
                  {th("last_name", "Name")}
                  {th("program", "Program")}
                  {th("year_level", "Year")}
                  <th className="px-3">Section</th>
                  {th("status", "Status")}
                  <th className="px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-t hover:bg-muted/30">
                    <td className="px-3 py-2 font-mono text-xs">{r.student_number}</td>
                    <td className="px-3">
                      <div className="flex items-center gap-2">
                        <StudentAvatar
                          name={`${r.first_name} ${r.last_name}`}
                          profile={r.profile}
                          linked={!!r.user_id}
                        />
                        <div>
                          <p className="font-medium">
                            {r.last_name}, {r.first_name}
                          </p>
                          <p className="text-xs text-muted-foreground">{r.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-3">{r.program}</td>
                    <td className="px-3">{r.year_level}</td>
                    <td className="px-3">{r.section}</td>
                    <td className="px-3">
                      <span
                        className={
                          r.status === "active"
                            ? "text-present font-medium"
                            : "text-muted-foreground"
                        }
                      >
                        {r.status === "inactive" ? "Archived" : r.status}
                      </span>
                    </td>
                    <td className="px-3 text-right whitespace-nowrap">
                      <Button
                        size="icon"
                        variant="ghost"
                        aria-label="View"
                        onClick={() => setViewing(r)}
                      >
                        <Eye />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        aria-label="Edit"
                        onClick={() => setEditing(r)}
                      >
                        <Pencil />
                      </Button>
                      {r.status === "active" ? (
                        <Button size="sm" variant="ghost" onClick={() => setArchiving(r)}>
                          <Archive /> Archive
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="ghost"
                          disabled={busy}
                          onClick={() => setArchived(r, false)}
                        >
                          <RotateCcw /> Restore
                        </Button>
                      )}
                      {isAdmin && status === "inactive" && (
                        <Button
                          size="icon"
                          variant="ghost"
                          aria-label="Permanently delete"
                          className="text-destructive"
                          onClick={() => setDeleting(r)}
                        >
                          <Trash2 />
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
          <span>
            Page {page + 1} of {pages} · {filtered.length} results
          </span>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={page === 0}
              onClick={() => setPage(page - 1)}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= pages - 1}
              onClick={() => setPage(page + 1)}
            >
              Next
            </Button>
          </div>
        </div>
      </Card>
      {editing && (
        <StudentForm
          student={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
        />
      )}
      <Dialog open={!!viewing} onOpenChange={(o) => !o && setViewing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {viewing?.first_name} {viewing?.last_name}
            </DialogTitle>
          </DialogHeader>
          {viewing && (
            <StudentAvatar
              name={`${viewing.first_name} ${viewing.last_name}`}
              profile={viewing.profile}
              linked={!!viewing.user_id}
              size="lg"
            />
          )}
          {viewing && (
            <dl className="grid grid-cols-2 gap-3 text-sm">
              {[
                ["Student no.", viewing.student_number],
                ["Email", viewing.email],
                ["Program", viewing.program],
                ["Year / Section", `${viewing.year_level} – ${viewing.section}`],
                ["Status", viewing.status],
                ["Account linked", viewing.user_id ? "Yes" : "No"],
              ].map(([k, v]) => (
                <div key={k}>
                  <dt className="text-muted-foreground">{k}</dt>
                  <dd className="font-medium break-all">{v}</dd>
                </div>
              ))}
            </dl>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={!!archiving} onOpenChange={(open) => !open && setArchiving(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Archive student?</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Archived students keep their attendance history but no longer appear in class lists.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setArchiving(null)}>
              Cancel
            </Button>
            <Button disabled={busy} onClick={() => archiving && setArchived(archiving, true)}>
              <Archive /> Archive
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(o) => !o && setDeleting(null)}
        title="Permanently delete archived student?"
        description={`This permanently removes ${deleting?.first_name} ${deleting?.last_name} and erases ALL their attendance records. This cannot be undone.`}
        onConfirm={remove}
        loading={busy}
      />
    </div>
  );
}

export function Filter({
  value,
  onChange,
  label,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  label: string;
  options: string[] | { value: string; label: string }[];
}) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="min-w-36" aria-label={label}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">All {label.toLowerCase()}</SelectItem>
        {options.map((o) =>
          typeof o === "string" ? (
            <SelectItem key={o} value={o} className="capitalize">
              {o}
            </SelectItem>
          ) : (
            <SelectItem key={o.value} value={o.value}>
              {o.label}
            </SelectItem>
          ),
        )}
      </SelectContent>
    </Select>
  );
}

function StudentForm({ student, onClose }: { student: Student | null; onClose: () => void }) {
  const qc = useQueryClient();
  const [f, setF] = useState(
    student ? { ...student, year_level: String(student.year_level) } : empty,
  );
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const set = (k: string, v: string) => setF({ ...f, [k]: v });
  const all = (qc.getQueryData<{ rows: Student[] }>(["students"])?.rows ?? []).filter(
    (x) => x.id !== student?.id,
  );
  const numKey = f.student_number.trim().toUpperCase();
  const mailKey = f.email.trim().toLowerCase();
  const dupNum = numKey
    ? all.find((x) => x.student_number.trim().toUpperCase() === numKey)
    : undefined;
  const dupMail = mailKey ? all.find((x) => x.email.trim().toLowerCase() === mailKey) : undefined;
  const live: Record<string, string> = {};
  if (dupNum)
    live.student_number = `This student ID is already taken by ${dupNum.first_name} ${dupNum.last_name}`;
  if (dupMail)
    live.email = `This email is already used by ${dupMail.first_name} ${dupMail.last_name}`;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (dupNum || dupMail) return toast.error("Fix the duplicate fields first");
    const r = studentSchema.safeParse(f);
    if (!r.success) return setErrors(fieldErrors(r.error));
    setErrors({});
    setSaving(true);
    const { error } = student
      ? await supabase.from("students").update(r.data).eq("id", student.id)
      : await supabase.from("students").insert(r.data);
    setSaving(false);
    if (error) {
      const m = errMsg(error);
      if (m.includes("student number")) setErrors({ student_number: m });
      if (m.includes("email")) setErrors({ email: m });
      return toast.error(m);
    }
    toast.success(student ? "Student updated" : "Student added");
    logActivity(
      student ? "updated" : "added",
      "student",
      `${r.data.first_name} ${r.data.last_name}`,
    );
    qc.invalidateQueries({ queryKey: ["students"] });
    onClose();
  }
  const text = (k: string, label: string, type = "text") => (
    <div>
      <Label htmlFor={k}>{label}</Label>
      <Input
        id={k}
        type={type}
        value={(f as Record<string, string>)[k]}
        onChange={(e) => set(k, e.target.value)}
        className="mt-1"
      />
      <FieldError msg={live[k] ?? errors[k]} />
    </div>
  );
  const sel = (k: string, label: string, opts: string[]) => (
    <div>
      <Label>{label}</Label>
      <Select value={(f as Record<string, string>)[k]} onValueChange={(v) => set(k, v)}>
        <SelectTrigger className="mt-1">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {opts.map((o) => (
            <SelectItem key={o} value={o}>
              {o}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <StudentAvatar
              name={`${f.first_name} ${f.last_name}`}
              profile={student?.profile}
              linked={!!student?.user_id}
            />
            <DialogTitle>{student ? "Edit student" : "Add student"}</DialogTitle>
          </div>
        </DialogHeader>
        <form onSubmit={save} className="grid gap-4 sm:grid-cols-2" noValidate>
          {text("student_number", "Student number")}
          {text("email", "Email", "email")}
          {text("first_name", "First name")}
          {text("last_name", "Last name")}
          {sel("program", "Program", PROGRAMS)}
          {sel("year_level", "Year level", ["1", "2", "3", "4", "5"])}
          {text("section", "Section")}
          {sel("status", "Status", ["active", "inactive"])}
          <DialogFooter className="sm:col-span-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving || !!dupNum || !!dupMail}>
              {saving && <Loader2 className="animate-spin" />} Save
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
