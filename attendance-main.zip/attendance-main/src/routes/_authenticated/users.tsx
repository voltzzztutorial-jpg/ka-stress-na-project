import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { errMsg, useAuth, type AppRole } from "@/lib/auth";
import { RequireRole } from "@/components/AppLayout";
import { Card, EmptyState, Loading, PageHeader } from "@/components/shared";
import { fetchAllPages, MAX_ROWS } from "@/lib/paging";
import { UserAvatar } from "@/components/UserAvatar";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/users")({
  head: () => ({
    meta: [
      { title: "User Management – AttendEase" },
      { name: "description", content: "Manage user roles and account status." },
      { property: "og:title", content: "User Management – AttendEase" },
      { property: "og:description", content: "Manage user roles and account status." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireRole roles={["admin"]}>
      <Users />
    </RequireRole>
  ),
});

const ROLES: AppRole[] = ["admin", "faculty", "student"];

function Users() {
  const qc = useQueryClient();
  const { data: auth } = useAuth();
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const q = useQuery({
    queryKey: ["users"],
    queryFn: async () => {
      const [p, r] = await Promise.all([
        fetchAllPages((a, b) =>
          supabase.from("profiles").select("*").order("created_at").order("id").range(a, b),
        ),
        fetchAllPages((a, b) =>
          supabase.from("user_roles").select("user_id,role").order("user_id").range(a, b),
        ),
      ]);
      const truncated = p.truncated || r.truncated;
      const users = p.rows.map((u) => {
        const list = r.rows.filter((x) => x.user_id === u.id).map((x) => x.role as AppRole);
        const role: AppRole = list.includes("admin")
          ? "admin"
          : list.includes("faculty")
            ? "faculty"
            : "student";
        return { ...u, role };
      });
      return { users, truncated };
    },
  });

  async function changeRole(userId: string, role: AppRole) {
    if (userId === auth?.user.id) return toast.error("You can't change your own role.");
    const { error } = await supabase.rpc("set_user_role", { _user_id: userId, _role: role });
    if (error) return toast.error(errMsg(error));
    toast.success(`Role changed to ${role}`);
    qc.invalidateQueries({ queryKey: ["users"] });
  }

  async function toggleActive(userId: string, is_active: boolean) {
    if (userId === auth?.user.id) return toast.error("You can't deactivate yourself.");
    const { error } = await supabase.rpc("set_user_active", {
      _user_id: userId,
      _active: is_active,
    });
    if (error) return toast.error(errMsg(error));
    toast.success(is_active ? "User activated" : "User deactivated");
    qc.invalidateQueries({ queryKey: ["users"] });
  }

  const rows = (q.data?.users ?? []).filter(
    (u) =>
      (roleFilter === "all" || u.role === roleFilter) &&
      `${u.full_name} ${u.email}`.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div>
      <PageHeader
        title="User Management"
        description="Assign roles and activate or deactivate accounts"
      />
      {q.data?.truncated && (
        <p role="status" className="mb-4 rounded-lg border border-late/40 bg-late/10 p-3 text-sm">
          Showing the first {MAX_ROWS.toLocaleString()} users only. Use the search to narrow the
          list.
        </p>
      )}
      <Card>
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative max-w-sm flex-1">
            <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
            <Input
              placeholder="Search name or email"
              className="pl-9"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="sm:w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All roles</SelectItem>
              {ROLES.map((r) => (
                <SelectItem key={r} value={r} className="capitalize">
                  {r}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {q.isLoading ? (
          <Loading />
        ) : q.isError ? (
          <EmptyState text="Couldn't load users." />
        ) : !rows.length ? (
          <EmptyState />
        ) : (
          <div className="mt-4 overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Joined</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Active</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((u) => {
                  const self = u.id === auth?.user.id;
                  return (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <UserAvatar
                            name={u.full_name || "Unnamed user"}
                            avatarUrl={u.avatar_url}
                            version={u.updated_at}
                            size="sm"
                          />
                          <span>
                            {u.full_name || "—"}
                            {self && (
                              <span className="ml-2 text-xs text-muted-foreground">(you)</span>
                            )}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">{u.email}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(u.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <Select
                          value={u.role}
                          disabled={self}
                          onValueChange={(v) => changeRole(u.id, v as AppRole)}
                        >
                          <SelectTrigger className="h-8 w-32 capitalize" aria-label="Role">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {ROLES.map((r) => (
                              <SelectItem key={r} value={r} className="capitalize">
                                {r}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Switch
                          checked={u.is_active}
                          disabled={self}
                          aria-label="Active"
                          onCheckedChange={(v) => toggleActive(u.id, v)}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </div>
  );
}
