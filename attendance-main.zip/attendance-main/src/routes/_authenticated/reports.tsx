import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, CalendarCheck, Percent, Users, Download, Printer } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { fetchAllPages, MAX_ROWS } from "@/lib/paging";
import { supabase } from "@/integrations/supabase/client";
import { RequireRole } from "@/components/AppLayout";
import { Card, EmptyState, Loading, PageHeader, StatCard, downloadCsv } from "@/components/shared";
import {
  attendanceRate,
  isLowAttendance,
  LOW_ATTENDANCE_THRESHOLD,
  PROGRAMS,
} from "@/lib/validation";
import { useMySubjects } from "@/lib/my-subjects";
import { retainedDate, validDateRange } from "@/lib/record-controls";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { daysAgo, localDate } from "@/lib/attendance";
import { StudentAvatar } from "@/components/UserAvatar";
import type { AvatarProfile } from "@/lib/avatar";
import { SearchableSelect } from "@/components/SearchableSelect";

export const Route = createFileRoute("/_authenticated/reports")({
  head: () => ({
    meta: [
      { title: "Reports – AttendEase" },
      { name: "description", content: "Attendance summaries, charts and exports." },
      { property: "og:title", content: "Reports – AttendEase" },
      { property: "og:description", content: "Attendance summaries, charts and exports." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireRole roles={["admin", "faculty"]}>
      <Reports />
    </RequireRole>
  ),
});

type Counts = { present: number; absent: number; late: number; excused: number; total: number };
const empty = (): Counts => ({ present: 0, absent: 0, late: 0, excused: 0, total: 0 });

function Reports() {
  const subjects = useMySubjects();
  const [subject, setSubject] = useState("all");
  const [program, setProgram] = useState("all");
  const [from, setFrom] = useState(() => daysAgo(60));
  const [to, setTo] = useState(() => localDate());
  const ids = useMemo(() => (subjects.data ?? []).map((s) => s.id), [subjects.data]);

  const q = useQuery({
    queryKey: ["report", subject, from, to, ids],
    enabled: subjects.isSuccess && validDateRange(from, to),
    queryFn: async () => {
      if (!ids.length) return { rows: [], truncated: false };
      return fetchAllPages((a, b) => {
        let qq = supabase
          .from("attendance")
          .select(
            "id,status,student_id,subject_id,students(student_number,first_name,last_name,program,user_id,profile:profiles!students_user_id_fkey(avatar_url,updated_at)),subjects(subject_code,subject_name)",
          )
          .gte("attendance_date", from)
          .lte("attendance_date", to);
        qq = subject === "all" ? qq.in("subject_id", ids) : qq.eq("subject_id", subject);
        return qq.order("id").range(a, b);
      });
    },
  });

  const data = (q.data?.rows ?? []).filter(
    (r) => program === "all" || r.students?.program === program,
  );
  const overall = empty();
  const byStudent = new Map<
    string,
    Counts & {
      name: string;
      number: string;
      program: string;
      profile?: AvatarProfile | null;
      linked: boolean;
    }
  >();
  const bySubject = new Map<string, Counts & { code: string; name: string }>();
  for (const r of data) {
    const st = r.status as keyof Omit<Counts, "total">;
    overall[st]++;
    overall.total++;
    const s = byStudent.get(r.student_id) ?? {
      ...empty(),
      name: `${r.students?.last_name}, ${r.students?.first_name}`,
      number: r.students?.student_number ?? "",
      program: r.students?.program ?? "",
      profile: r.students?.profile,
      linked: !!r.students?.user_id,
    };
    s[st]++;
    s.total++;
    byStudent.set(r.student_id, s);
    const sb = bySubject.get(r.subject_id) ?? {
      ...empty(),
      code: r.subjects?.subject_code ?? "",
      name: r.subjects?.subject_name ?? "",
    };
    sb[st]++;
    sb.total++;
    bySubject.set(r.subject_id, sb);
  }
  const students = [...byStudent.values()].sort((a, b) => a.name.localeCompare(b.name));
  const subs = [...bySubject.values()].sort((a, b) => a.code.localeCompare(b.code));
  const low = students.filter((s) =>
    isLowAttendance(attendanceRate(s), s.present + s.late + s.absent > 0),
  ).length;
  const pie = [
    { name: "Present", value: overall.present, color: "var(--present)" },
    { name: "Absent", value: overall.absent, color: "var(--absent)" },
    { name: "Late", value: overall.late, color: "var(--late)" },
    { name: "Excused", value: overall.excused, color: "var(--excused)" },
  ];

  function exportCsv() {
    downloadCsv(`attendance-report-${from}-to-${to}.csv`, [
      [
        "Student number",
        "Name",
        "Program",
        "Present",
        "Absent",
        "Late",
        "Excused",
        "Total",
        "Rate %",
      ],
      ...students.map((s) => [
        s.number,
        s.name,
        s.program,
        s.present,
        s.absent,
        s.late,
        s.excused,
        s.total,
        attendanceRate(s),
      ]),
      [],
      ["Subject code", "Subject", "Present", "Absent", "Late", "Excused", "Total", "Rate %"],
      ...subs.map((s) => [
        s.code,
        s.name,
        s.present,
        s.absent,
        s.late,
        s.excused,
        s.total,
        attendanceRate(s),
      ]),
    ]);
  }

  return (
    <div>
      <PageHeader
        title="Reports & Analytics"
        description={`Attendance summary from ${from} to ${to}`}
        actions={
          <>
            <Button variant="outline" onClick={exportCsv} disabled={!data.length}>
              <Download /> Export to CSV
            </Button>
            <Button variant="outline" onClick={() => window.print()}>
              <Printer /> Print
            </Button>
          </>
        }
      />
      {q.data?.truncated && (
        <p role="status" className="mb-4 rounded-lg border border-late/40 bg-late/10 p-3 text-sm">
          Showing the first {MAX_ROWS.toLocaleString()} records only. Narrow the date range or
          subject to see complete totals.
        </p>
      )}
      <Card className="no-print mb-6">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <Label>Subject</Label>
            <SearchableSelect
              aria-label="Subject"
              value={subject}
              onValueChange={setSubject}
              className="mt-1"
              searchPlaceholder="Search subject code or name"
              loading={subjects.isLoading}
              noneOption={{ value: "all", label: "All subjects" }}
              options={(subjects.data ?? []).map((s) => ({
                value: s.id,
                label: `${s.subject_code} – ${s.subject_name}`,
                description: `${s.schedule_day} · ${s.schedule_time}${s.room ? ` · ${s.room}` : ""}`,
              }))}
            />
          </div>
          <div>
            <Label>Program</Label>
            <Select value={program} onValueChange={setProgram}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All programs</SelectItem>
                {PROGRAMS.map((p) => (
                  <SelectItem key={p} value={p}>
                    {p}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="rf">From</Label>
            <Input
              id="rf"
              type="date"
              value={from}
              max={to}
              onChange={(e) => setFrom((previous) => retainedDate(previous, e.target.value))}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="rt">To</Label>
            <Input
              id="rt"
              type="date"
              value={to}
              min={from}
              max={localDate()}
              onChange={(e) => setTo((previous) => retainedDate(previous, e.target.value))}
              className="mt-1"
            />
          </div>
        </div>
      </Card>

      {!validDateRange(from, to) ? (
        <p role="alert" className="text-destructive">
          From must be on or before To.
        </p>
      ) : q.isLoading || subjects.isLoading ? (
        <Loading />
      ) : q.isError ? (
        <EmptyState text="Couldn't load the report." />
      ) : !data.length ? (
        <EmptyState />
      ) : (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Records"
              value={overall.total}
              icon={<CalendarCheck className="size-5" />}
            />
            <StatCard
              label="Attendance rate"
              value={`${attendanceRate(overall)}%`}
              tone="present"
              icon={<Percent className="size-5" />}
              hint="(Present + Late) ÷ (Present + Late + Absent)"
            />
            <StatCard
              label="Students"
              value={students.length}
              tone="excused"
              icon={<Users className="size-5" />}
            />
            <StatCard
              label="Below 75%"
              value={low}
              tone="absent"
              icon={<AlertTriangle className="size-5" />}
              hint="Low attendance warning"
            />
          </div>
          <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
            <Card title="Attendance by subject">
              <div className="h-72">
                <ResponsiveContainer>
                  <BarChart
                    data={subs.map((s) => ({
                      name: s.code,
                      Present: s.present,
                      Late: s.late,
                      Absent: s.absent,
                      Excused: s.excused,
                    }))}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="name" fontSize={12} />
                    <YAxis fontSize={12} allowDecimals={false} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="Present" stackId="a" fill="var(--present)" />
                    <Bar dataKey="Late" stackId="a" fill="var(--late)" />
                    <Bar dataKey="Absent" stackId="a" fill="var(--absent)" />
                    <Bar
                      dataKey="Excused"
                      stackId="a"
                      fill="var(--excused)"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>
            <Card title="Status breakdown">
              <div className="h-72">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie
                      data={pie}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={55}
                      outerRadius={90}
                      paddingAngle={2}
                    >
                      {pie.map((p) => (
                        <Cell key={p.name} fill={p.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </div>
          <Card title="Summary per subject">
            <SummaryTable
              rows={subs.map((s) => ({ key: s.code, a: s.code, b: s.name, c: s }))}
              labels={["Code", "Subject"]}
            />
          </Card>
          <Card title="Summary per student">
            <SummaryTable
              rows={students.map((s) => ({
                key: s.number,
                a: s.number,
                b: `${s.name} (${s.program})`,
                c: s,
                avatar: (
                  <StudentAvatar name={s.name} profile={s.profile} linked={s.linked} size="xs" />
                ),
              }))}
              labels={["Student no.", "Name"]}
            />
          </Card>
        </div>
      )}
    </div>
  );
}

function SummaryTable({
  rows,
  labels,
}: {
  rows: { key: string; a: string; b: string; c: Counts; avatar?: React.ReactNode }[];
  labels: [string, string];
}) {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>{labels[0]}</TableHead>
            <TableHead>{labels[1]}</TableHead>
            <TableHead className="text-right">Present</TableHead>
            <TableHead className="text-right">Absent</TableHead>
            <TableHead className="text-right">Late</TableHead>
            <TableHead className="text-right">Excused</TableHead>
            <TableHead className="text-right">Rate</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((r) => {
            const rate = attendanceRate(r.c);
            const lowR = isLowAttendance(rate, r.c.present + r.c.late + r.c.absent > 0);
            return (
              <TableRow key={r.key}>
                <TableCell className="font-mono text-xs">{r.a}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {r.avatar}
                    <span>{r.b}</span>
                  </div>
                </TableCell>
                <TableCell className="text-right">{r.c.present}</TableCell>
                <TableCell className="text-right">{r.c.absent}</TableCell>
                <TableCell className="text-right">{r.c.late}</TableCell>
                <TableCell className="text-right">{r.c.excused}</TableCell>
                <TableCell
                  className={cn("text-right font-semibold", lowR ? "text-absent" : "text-present")}
                >
                  {lowR && <AlertTriangle className="mr-1 inline size-3.5" />}
                  {rate}%
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
