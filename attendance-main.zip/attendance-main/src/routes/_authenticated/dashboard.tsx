import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  AlertTriangle,
  BookOpen,
  CalendarCheck,
  CheckCircle2,
  Clock,
  GraduationCap,
  Percent,
  Users,
  XCircle,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import {
  attendanceRate,
  daysAgo,
  isLowAttendance,
  localDate,
  LOW_ATTENDANCE_THRESHOLD,
} from "@/lib/attendance";
import { fetchAllPages, MAX_ROWS } from "@/lib/paging";
import { PendingExcuseRequests } from "@/components/ExcuseRequests";
import { Button } from "@/components/ui/button";
import { StaffClassActions } from "@/components/StaffClassActions";
import { StudentFacultyList } from "@/components/StudentFacultyList";
import {
  Card,
  EmptyState,
  Loading,
  PageHeader,
  StatCard,
  StatusBadge,
  type Status,
} from "@/components/shared";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard – AttendEase" },
      { name: "description", content: "Attendance overview." },
      { property: "og:title", content: "Dashboard – AttendEase" },
      { property: "og:description", content: "Attendance overview." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

type Row = {
  id: string;
  status: Status;
  attendance_date: string;
  subject_id: string;
  student_id: string;
  subjects: { subject_code: string } | null;
  students: { first_name: string; last_name: string } | null;
};
const today = () => localDate();
const COLORS: Record<Status, string> = {
  present: "var(--present)",
  absent: "var(--absent)",
  late: "var(--late)",
  excused: "var(--excused)",
};

function count(rows: { status: Status }[]) {
  const c = { present: 0, absent: 0, late: 0, excused: 0, total: rows.length };
  rows.forEach((r) => c[r.status]++);
  return c;
}

function useAttendance() {
  return useQuery({
    queryKey: ["attendance", "dash"],
    queryFn: async () => {
      const since = daysAgo(30);
      return fetchAllPages<Row>(
        (a, b) =>
          supabase
            .from("attendance")
            .select(
              "id,status,attendance_date,subject_id,student_id,subjects(subject_code),students(first_name,last_name)",
            )
            .gte("attendance_date", since)
            .order("attendance_date", { ascending: false })
            .order("id")
            .range(a, b) as unknown as PromiseLike<{
            data: Row[] | null;
            error: { message: string } | null;
          }>,
      );
    },
  });
}

function Dashboard() {
  const { data: auth } = useAuth();
  if (!auth) return <Loading />;
  return auth.role === "student" ? (
    <StudentDash userId={auth.user.id} />
  ) : (
    <StaffDash
      isAdmin={auth.role === "admin"}
      name={auth.profile?.full_name}
      userId={auth.user.id}
    />
  );
}

function StaffDash({ isAdmin, name, userId }: { isAdmin: boolean; name?: string; userId: string }) {
  const att = useAttendance();
  const totals = useQuery({
    queryKey: ["dash-totals"],
    queryFn: async () => {
      const [s, sub, f, a, logs] = await Promise.all([
        supabase
          .from("students")
          .select("id", { count: "exact", head: true })
          .eq("status", "active"),
        supabase
          .from("subjects")
          .select("id,subject_code,subject_name,schedule_day,schedule_time,room,faculty_id"),
        supabase.from("user_roles").select("user_id").eq("role", "faculty"),
        supabase.from("attendance").select("id", { count: "exact", head: true }),
        supabase
          .from("activity_logs")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(8),
      ]);
      for (const result of [s, sub, f, a, logs]) {
        if (result.error) throw result.error;
      }
      // Count only faculty whose profile is active.
      const facIds = [...new Set((f.data ?? []).map((r) => r.user_id))];
      let faculty = 0;
      if (facIds.length) {
        const { count, error } = await supabase
          .from("profiles")
          .select("id", { count: "exact", head: true })
          .in("id", facIds)
          .eq("is_active", true);
        if (error) throw error;
        faculty = count ?? 0;
      }
      return {
        students: s.count ?? 0,
        subjects: sub.data ?? [],
        faculty,
        records: a.count ?? 0,
        logs: logs.data ?? [],
      };
    },
  });
  if (att.error || totals.error)
    return (
      <div role="alert" className="space-y-3">
        <p className="text-destructive">
          Failed to load data: {att.error?.message ?? totals.error?.message}
        </p>
        <Button
          onClick={() => {
            void att.refetch();
            void totals.refetch();
          }}
        >
          Try again
        </Button>
      </div>
    );
  if (att.isLoading || totals.isLoading) return <Loading />;
  const rows = att.data?.rows ?? [];
  const truncated = att.data?.truncated ?? false;
  const t = totals.data;
  if (!t) return <Loading />;
  const mySubjects = isAdmin ? t.subjects : t.subjects.filter((s) => s.faculty_id === userId);
  const mineIds = new Set(mySubjects.map((s) => s.id));
  const scoped = isAdmin ? rows : rows.filter((r) => mineIds.has(r.subject_id));
  const todayC = count(scoped.filter((r) => r.attendance_date === today()));
  const allC = count(scoped);
  const weekday = new Date().toLocaleDateString("en-US", { weekday: "long" });

  const bySubject = mySubjects.map((s) => {
    const c = count(scoped.filter((r) => r.subject_id === s.id));
    return {
      name: s.subject_code,
      present: c.present,
      late: c.late,
      absent: c.absent,
      excused: c.excused,
      rate: attendanceRate(c),
    };
  });
  const days: Record<string, Row[]> = {};
  scoped.forEach((r) => (days[r.attendance_date] ??= []).push(r));
  const trend = Object.keys(days)
    .sort()
    .map((d) => ({ date: d.slice(5), rate: attendanceRate(count(days[d])) }));
  const pie = (["present", "absent", "late", "excused"] as Status[])
    .map((k) => ({ name: k, value: allC[k] }))
    .filter((p) => p.value);

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Hello${name ? `, ${name.split(" ")[0]}` : ""}`}
        description={
          isAdmin ? "Campus-wide attendance overview (last 30 days)" : "Your classes at a glance"
        }
      />
      {truncated && <CapNotice />}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {isAdmin ? (
          <>
            <StatCard label="Total students" value={t.students} icon={<GraduationCap />} />
            <StatCard label="Total faculty" value={t.faculty} icon={<Users />} />
            <StatCard label="Total subjects" value={t.subjects.length} icon={<BookOpen />} />
            <StatCard label="Attendance records" value={t.records} icon={<CalendarCheck />} />
          </>
        ) : (
          <>
            <StatCard label="My classes" value={mySubjects.length} icon={<BookOpen />} />
            <StatCard
              label="Today's classes"
              value={mySubjects.filter((s) => s.schedule_day === weekday).length}
              icon={<CalendarCheck />}
            />
            <StatCard label="Records (30 days)" value={allC.total} icon={<Users />} />
            <StatCard
              label="Excused today"
              value={todayC.excused}
              icon={<AlertTriangle />}
              tone="excused"
            />
          </>
        )}
        <StatCard
          label="Present today"
          value={todayC.present}
          icon={<CheckCircle2 />}
          tone="present"
        />
        <StatCard label="Absent today" value={todayC.absent} icon={<XCircle />} tone="absent" />
        <StatCard label="Late today" value={todayC.late} icon={<Clock />} tone="late" />
        <StatCard
          label="Attendance rate"
          value={`${attendanceRate(allC)}%`}
          icon={<Percent />}
          tone="excused"
          hint="(Present + Late) ÷ (Present + Late + Absent), last 30 days"
        />
      </div>
      <PendingExcuseRequests userId={userId} isAdmin={isAdmin} />
      <StaffClassActions />
      <div className="grid gap-6 lg:grid-cols-3">
        <Card title="Attendance by subject" className="lg:col-span-2">
          {bySubject.length ? (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={bySubject}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" fontSize={12} />
                <YAxis fontSize={12} allowDecimals={false} />
                <Tooltip />
                <Legend />
                {(["present", "late", "absent", "excused"] as Status[]).map((k) => (
                  <Bar key={k} dataKey={k} stackId="a" fill={COLORS[k]} />
                ))}
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <EmptyState text="No subjects yet" />
          )}
        </Card>
        <Card title="Status breakdown">
          {pie.length ? (
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={pie}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={55}
                  outerRadius={95}
                  paddingAngle={2}
                >
                  {pie.map((p) => (
                    <Cell key={p.name} fill={COLORS[p.name as Status]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <EmptyState />
          )}
        </Card>
        <Card title="Attendance rate – last 30 days" className="lg:col-span-2">
          {trend.length ? (
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="date" fontSize={12} />
                <YAxis domain={[0, 100]} fontSize={12} unit="%" />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="rate"
                  stroke="var(--primary)"
                  strokeWidth={2.5}
                  dot
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <EmptyState />
          )}
        </Card>
        {isAdmin ? (
          <Card title="Recent activity">
            {t.logs.length ? (
              <ul className="space-y-3 text-sm">
                {t.logs.map((l) => (
                  <li key={l.id} className="border-l-2 border-primary/40 pl-3">
                    <p>
                      <span className="font-medium capitalize">{l.action}</span> {l.entity}
                    </p>
                    {l.details && <p className="text-xs text-muted-foreground">{l.details}</p>}
                    <p className="text-xs text-muted-foreground">
                      {new Date(l.created_at).toLocaleString()}
                    </p>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState text="No activity yet" />
            )}
          </Card>
        ) : (
          <Card title="Rate per class">
            <ul className="space-y-3 text-sm">
              {bySubject.map((s) => {
                const hasRecords = s.present + s.late + s.absent > 0;
                return (
                  <li key={s.name} className="flex items-center justify-between">
                    <span>{s.name}</span>
                    {hasRecords ? (
                      <span
                        className={
                          isLowAttendance(s.rate)
                            ? "font-semibold text-absent"
                            : "font-semibold text-present"
                        }
                      >
                        {s.rate}%
                      </span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </li>
                );
              })}
              {!bySubject.length && <EmptyState text="No classes assigned" />}
            </ul>
          </Card>
        )}
      </div>
      <Card title="Recent records">
        <RecentTable rows={scoped.slice(0, 8)} />
      </Card>
    </div>
  );
}

function RecentTable({ rows }: { rows: Row[] }) {
  if (!rows.length) return <EmptyState />;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-left text-muted-foreground">
          <tr>
            <th className="py-2">Date</th>
            <th>Student</th>
            <th>Subject</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id} className="border-t">
              <td className="py-2">{r.attendance_date}</td>
              <td>{r.students ? `${r.students.last_name}, ${r.students.first_name}` : "—"}</td>
              <td>{r.subjects?.subject_code}</td>
              <td>
                <StatusBadge status={r.status} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function StudentDash({ userId }: { userId: string }) {
  const student = useQuery({
    queryKey: ["students", "mine", userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("students")
        .select("id")
        .eq("user_id", userId)
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  const q = useQuery({
    queryKey: ["attendance", "mine", userId],
    queryFn: async () => {
      return fetchAllPages<Row>(
        (a, b) =>
          supabase
            .from("attendance")
            .select(
              "id,status,attendance_date,subject_id,student_id,subjects(subject_code),students(first_name,last_name)",
            )
            .order("attendance_date", { ascending: false })
            .order("id")
            .range(a, b) as unknown as PromiseLike<{
            data: Row[] | null;
            error: { message: string } | null;
          }>,
      );
    },
  });
  if (student.isLoading || q.isLoading) return <Loading />;
  if (student.error || q.error)
    return (
      <p className="text-destructive">
        Failed to load data: {student.error?.message ?? q.error?.message}
      </p>
    );
  if (!student.data)
    return (
      <div className="space-y-6">
        <PageHeader
          title="My attendance"
          description="Your attendance across all enrolled subjects"
        />
        <p className="rounded-lg border bg-card p-4 text-sm text-muted-foreground">
          Your account isn't linked to a student record yet. Ask your administrator to check that
          your email matches.
        </p>
      </div>
    );
  const rows = q.data?.rows ?? [];
  const c = count(rows);
  const rate = attendanceRate(c);
  return (
    <div className="space-y-6">
      <PageHeader
        title="My attendance"
        description="Your attendance across all enrolled subjects"
      />
      {q.data?.truncated && <CapNotice />}
      {!rows.length && (
        <p className="rounded-lg border bg-card p-4 text-sm text-muted-foreground">
          No attendance records yet. If you have a student record, make sure you registered with the
          same email your school has on file.
        </p>
      )}
      {isLowAttendance(rate, c.present + c.late + c.absent > 0) && (
        <div className="flex items-center gap-3 rounded-lg border border-absent/40 bg-absent/10 p-4 text-sm text-absent">
          <AlertTriangle className="size-5" /> Your attendance is below {LOW_ATTENDANCE_THRESHOLD}%.
          Please talk to your instructors.
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Attendance" value={`${rate}%`} icon={<Percent />} />
        <StatCard label="Present" value={c.present} icon={<CheckCircle2 />} tone="present" />
        <StatCard label="Absent" value={c.absent} icon={<XCircle />} tone="absent" />
        <StatCard label="Late" value={c.late} icon={<Clock />} tone="late" />
      </div>
      <Card title="By subject">
        <div className="mb-4">
          <StudentFacultyList />
        </div>
        <SubjectTable rows={rows} />
      </Card>
      <Card title="Recent attendance">
        <RecentTable rows={rows.slice(0, 15)} />
      </Card>
    </div>
  );
}

function SubjectTable({ rows }: { rows: Row[] }) {
  const groups: Record<string, Row[]> = {};
  rows.forEach((r) => (groups[r.subjects?.subject_code ?? "—"] ??= []).push(r));
  const list = Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
  if (!list.length) return <EmptyState text="No subjects with attendance yet" />;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-left text-muted-foreground">
          <tr>
            <th className="py-2">Subject</th>
            <th>Present</th>
            <th>Late</th>
            <th>Absent</th>
            <th>Excused</th>
            <th>Rate</th>
          </tr>
        </thead>
        <tbody>
          {list.map(([code, rs]) => {
            const c = count(rs);
            const rate = attendanceRate(c);
            const hasRecords = c.present + c.late + c.absent > 0;
            const low = isLowAttendance(rate, hasRecords);
            return (
              <tr key={code} className="border-t">
                <td className="py-2 font-medium">{code}</td>
                <td>{c.present}</td>
                <td>{c.late}</td>
                <td>{c.absent}</td>
                <td>{c.excused}</td>
                <td>
                  {hasRecords ? (
                    <span
                      className={low ? "font-semibold text-absent" : "font-semibold text-present"}
                    >
                      {rate}%
                    </span>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                  {low && (
                    <span className="ml-2 rounded-full border border-absent/40 bg-absent/10 px-2 py-0.5 text-xs font-semibold text-absent">
                      Below 75%
                    </span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function CapNotice() {
  return (
    <p role="status" className="rounded-lg border border-late/40 bg-late/10 p-3 text-sm">
      Showing the first {MAX_ROWS.toLocaleString()} records only. Narrow the date range or subject
      to see complete totals.
    </p>
  );
}
