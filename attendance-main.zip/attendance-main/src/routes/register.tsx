import { useRedirectIfSignedIn } from "@/lib/redirect-signed-in";
import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Loader2, MailCheck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AuthShell } from "@/components/AuthShell";
import { FieldError } from "@/components/shared";
import { PasswordInput } from "@/components/PasswordInput";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fieldErrors, registerSchema } from "@/lib/validation";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Register – AttendEase" },
      { name: "description", content: "Create your AttendEase account for SorSU Bulan Campus." },
      { property: "og:title", content: "Register – AttendEase" },
      { property: "og:description", content: "Create an account to view your attendance." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Register,
});

function Register() {
  useRedirectIfSignedIn();
  const [form, setForm] = useState({ full_name: "", email: "", password: "", confirm: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm({ ...form, [k]: e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const r = registerSchema.safeParse(form);
    if (!r.success) return setErrors(fieldErrors(r.error));
    setErrors({});
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email: r.data.email,
      password: r.data.password,
      options: {
        emailRedirectTo: window.location.origin + "/dashboard",
        data: { full_name: r.data.full_name },
      },
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    if (data.user && data.user.identities?.length === 0)
      return toast.error("An account with this email already exists.");
    toast.success("Account created!");
    setDone(true);
  }

  if (done)
    return (
      <AuthShell title="Check your email" subtitle="One more step">
        <div className="rounded-xl border bg-card p-6 text-center shadow-card">
          <MailCheck className="mx-auto size-10 text-primary" />
          <p className="mt-3 text-sm">
            We sent a confirmation link to <b>{form.email}</b>. Click it to activate your account,
            then sign in.
          </p>
          <Button asChild className="mt-5 w-full">
            <Link to="/login">Go to login</Link>
          </Button>
        </div>
      </AuthShell>
    );

  const fields: [keyof typeof form, string, string][] = [
    ["full_name", "Full name", "text"],
    ["email", "Email", "email"],
    ["password", "Password", "password"],
    ["confirm", "Confirm password", "password"],
  ];
  return (
    <AuthShell title="Create an account" subtitle="New accounts start with the Student role">
      <form onSubmit={submit} className="space-y-4" noValidate>
        {fields.map(([k, label, type]) => (
          <div key={k}>
            <Label htmlFor={k}>{label}</Label>
            {type === "password" ? (
              <PasswordInput id={k} value={form[k]} onChange={set(k)} className="mt-1" />
            ) : (
              <Input id={k} type={type} value={form[k]} onChange={set(k)} className="mt-1" />
            )}
            <FieldError msg={errors[k]} />
          </div>
        ))}
        <p className="text-xs text-muted-foreground">
          At least 8 characters with letters and numbers.
        </p>
        <Button type="submit" className="w-full" disabled={loading}>
          {loading && <Loader2 className="animate-spin" />} Create account
        </Button>
      </form>
      <p className="mt-6 text-center text-sm text-muted-foreground">
        Already registered?{" "}
        <Link to="/login" className="font-medium text-primary hover:underline">
          Login
        </Link>
      </p>
    </AuthShell>
  );
}
