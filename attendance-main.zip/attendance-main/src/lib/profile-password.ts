import { z } from "zod";
import { passwordSchema } from "@/lib/validation";

type PasswordUser = {
  identities?: { provider: string }[];
  app_metadata: { providers?: string[]; provider?: string };
  user_metadata: { attendease_password_set?: boolean };
};

export function needsPasswordSetup(user: PasswordUser): boolean {
  const providers = new Set([
    ...(user.identities ?? []).map((identity) => identity.provider),
    ...(user.app_metadata.providers ?? []),
    user.app_metadata.provider,
  ]);
  return (
    providers.has("google") &&
    !providers.has("email") &&
    user.user_metadata.attendease_password_set !== true
  );
}

export function profilePasswordSchema(settingPassword: boolean) {
  return z
    .object({
      current: settingPassword ? z.string() : z.string().min(1, "Current password is required"),
      password: passwordSchema,
      confirm: z.string(),
    })
    .refine((value) => value.password === value.confirm, {
      message: "Passwords do not match",
      path: ["confirm"],
    });
}
