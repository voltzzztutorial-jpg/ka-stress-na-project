export const EXCUSE_BUCKET = "excuse-files";
export const MAX_EXCUSE_FILE_BYTES = 2 * 1024 * 1024;
export const EXCUSE_FILE_TYPES = ["application/pdf", "image/jpeg", "image/png", "image/webp"];

/** Returns an error message, or null when the optional attachment is acceptable. */
export function excuseFileError(
  file: { size: number; type: string } | null | undefined,
): string | null {
  if (!file) return null;
  if (file.size >= MAX_EXCUSE_FILE_BYTES) return "File must be under 2 MB.";
  if (!EXCUSE_FILE_TYPES.includes(file.type)) return "Attach a PDF, JPG, PNG or WEBP file.";
  return null;
}

export function excuseReasonError(reason: string): string | null {
  const r = reason.trim();
  if (r.length < 3) return "Please give a reason.";
  if (r.length > 1000) return "Keep the reason under 1000 characters.";
  return null;
}

export const MAX_EXCUSE_AGE_DAYS = 30;
/** Date rule: not in the future and within the last 30 days (local YYYY-MM-DD strings). */
export function excuseDateError(date: string, today: string, oldest: string): string | null {
  if (!date) return "Choose a date.";
  if (date > today) return "The excuse date can't be in the future.";
  if (date < oldest) return "The excuse date must be within the last 30 days.";
  return null;
}
