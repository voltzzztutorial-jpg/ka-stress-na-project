import type { Status } from "@/components/shared";

export function clampPage(page: number, pages: number): number {
  return Math.max(0, Math.min(page, Math.max(1, pages) - 1));
}

export function compareValues(a: unknown, b: unknown, ascending = true): number {
  const left = String(a);
  const right = String(b);
  if (left === right) return 0;
  return (left > right ? 1 : -1) * (ascending ? 1 : -1);
}

/** An empty date field retains its previous value; reversed ranges never load. */
export function retainedDate(previous: string, next: string): string {
  return next || previous;
}

export function validDateRange(from: string, to: string): boolean {
  return !!from && !!to && from <= to;
}

export function markUnmarkedPresent(
  marks: Record<string, { status: Status; remarks: string }>,
  roster: { id: string }[],
) {
  const next = { ...marks };
  for (const student of roster) {
    if (!next[student.id]) next[student.id] = { status: "present", remarks: "" };
  }
  return next;
}
