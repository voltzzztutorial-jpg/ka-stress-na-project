import { useSyncExternalStore } from "react";
import { useQuery, queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type AppRole = "admin" | "faculty" | "student";

export const authQuery = queryOptions({
  queryKey: ["auth"],
  queryFn: async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return null;
    const [p, r] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", user.id).maybeSingle(),
      supabase.from("user_roles").select("role").eq("user_id", user.id),
    ]);
    // Throw so a transient failure is retried instead of being cached as role "student".
    if (p.error) throw p.error;
    if (r.error) throw r.error;
    const profile = p.data;
    const roles = r.data;
    const list = (roles ?? []).map((r) => r.role as AppRole);
    const role: AppRole = list.includes("admin")
      ? "admin"
      : list.includes("faculty")
        ? "faculty"
        : "student";
    return { user, profile, roles: list, role };
  },
  staleTime: 60_000,
});

const noop = () => () => {};
/** True only after hydration in the browser — the session lives in localStorage, so the server can't know it. */
export function useHydrated() {
  return useSyncExternalStore(
    noop,
    () => true,
    () => false,
  );
}

/** isLoading stays true until the browser session has been restored, so signed-in users never see signed-out UI. */
export function useAuth() {
  const hydrated = useHydrated();
  const q = useQuery({ ...authQuery, enabled: hydrated });
  return { ...q, isLoading: !hydrated || q.isPending };
}

/** action/entity are app-controlled strings; the database trusts the caller's known values by design (no DB allowlist). */
export async function logActivity(action: string, entity: string, details?: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return;
  await supabase.from("activity_logs").insert({ user_id: user.id, action, entity, details });
}

export function errMsg(e: unknown): string {
  const m = (e as { message?: string })?.message ?? String(e);
  if (m.includes("students_number_uq")) return "That student number is already in use.";
  if (m.includes("students_email_uq")) return "That email is already used by another student.";
  if (m.includes("subjects_code_uq")) return "That subject code already exists.";
  if (m.includes("enrollments_student_id_subject_id_key"))
    return "Student is already enrolled in this subject.";
  if (m.includes("Faculty cannot change"))
    return "Faculty can't change the subject code or assigned faculty.";
  if (m.includes("row-level security")) return "You don't have permission to do that.";
  return m;
}
