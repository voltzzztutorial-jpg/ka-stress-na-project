import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/** The single photo bucket. Profiles store object paths ("{user_id}/file.jpg"). */
export const AVATAR_BUCKET = "avatars";

export type AvatarProfile = { avatar_url: string | null; updated_at?: string; full_name?: string };

export function avatarTone(name: string): number {
  return (
    Array.from(name.trim().toLowerCase()).reduce(
      (hash, c) => (hash * 31 + c.charCodeAt(0)) >>> 0,
      0,
    ) % 4
  );
}

function withVersion(url: string, version?: string | number) {
  if (!version || /^blob:/.test(url)) return url;
  return `${url}${url.includes("?") ? "&" : "?"}v=${encodeURIComponent(String(version))}`;
}

/** Only local previews or relative object paths can be resolved. */
export function allowedAvatarPath(path: string | null | undefined): boolean {
  if (!path) return false;
  if (path.startsWith("blob:")) return true;
  return (
    !/^[a-z][a-z0-9+.-]*:/i.test(path) &&
    !path.startsWith("/") &&
    path.includes("/") &&
    !path.split("/").some((part) => part === ".." || !part)
  );
}

/** Resolves a stored photo path to a displayable URL (signed, cached ~50 min). */
export function useAvatarUrl(path: string | null | undefined, version?: string | number) {
  const url =
    useQuery({
      queryKey: ["avatar-url", path],
      enabled: allowedAvatarPath(path),
      staleTime: 50 * 60_000,
      queryFn: async () => {
        if (!path || !allowedAvatarPath(path)) return null;
        if (path.startsWith("blob:")) return path;
        const { data, error } = await supabase.storage
          .from(AVATAR_BUCKET)
          .createSignedUrl(path, 60 * 60);
        if (error) return null;
        return data.signedUrl;
      },
    }).data ?? null;
  return allowedAvatarPath(path) && url ? withVersion(url, version) : undefined;
}
