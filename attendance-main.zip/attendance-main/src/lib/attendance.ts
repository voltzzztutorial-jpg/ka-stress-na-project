/** Local-date helpers and attendance math. Never use toISOString() for calendar dates. */
export function localDate(d: Date = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function daysAgo(n: number, from: Date = new Date()): string {
  const d = new Date(from.getFullYear(), from.getMonth(), from.getDate() - n);
  return localDate(d);
}

export type StatusCounts = { present: number; absent: number; late: number; excused?: number };

/** (Present + Late) / (Present + Late + Absent). Excused is ignored entirely. Percent with 1 decimal. */
export function attendanceRate(c: StatusCounts): number {
  const denom = c.present + c.late + c.absent;
  if (denom === 0) return 0;
  return Math.round(((c.present + c.late) / denom) * 1000) / 10;
}

export const LOW_ATTENDANCE_THRESHOLD = 75;
export const isLowAttendance = (rate: number, hasRecords = true) =>
  hasRecords && rate < LOW_ATTENDANCE_THRESHOLD;
