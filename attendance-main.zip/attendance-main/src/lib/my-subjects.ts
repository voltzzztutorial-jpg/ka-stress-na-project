import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export function useMySubjects() {
  const { data: auth } = useAuth();
  return useQuery({
    queryKey: ["my-subjects", auth?.user.id, auth?.role],
    enabled: !!auth,
    queryFn: async () => {
      let q = supabase
        .from("subjects")
        .select("id,subject_code,subject_name,faculty_id,schedule_day,schedule_time,room")
        .order("subject_code");
      if (auth?.role === "faculty") q = q.eq("faculty_id", auth.user.id);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
  });
}
