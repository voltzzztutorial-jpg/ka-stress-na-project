import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { fetchAllPages } from "@/lib/paging";
export function useEnrolledClasses() {
  const { data: auth } = useAuth();
  return useQuery({
    queryKey: ["my-classes", auth?.user.id],
    enabled: !!auth && auth.role === "student",
    queryFn: async () => {
      const [enrollments, faculty, attendance] = await Promise.all([
        supabase
          .from("enrollments")
          .select("subjects(*),students!inner(user_id)")
          .eq("students.user_id", auth?.user.id ?? ""),
        supabase.rpc("my_enrolled_faculty"),
        fetchAllPages((a, b) =>
          supabase
            .from("attendance")
            .select("id,subject_id,attendance_date,status,remarks,time_recorded")
            .order("attendance_date", { ascending: false })
            .order("id")
            .range(a, b),
        ),
      ]);
      if (enrollments.error) throw enrollments.error;
      if (faculty.error) throw faculty.error;
      return {
        subjects: (enrollments.data ?? []).flatMap((e) => (e.subjects ? [e.subjects] : [])),
        faculty: faculty.data ?? [],
        attendance: attendance.rows,
        truncated: attendance.truncated,
      };
    },
  });
}
