import { attendanceRate, LOW_ATTENDANCE_THRESHOLD } from "@/lib/attendance";
export function bulkCandidates<
  T extends { id: string; status: string; program: string; year_level: number; section: string },
>(
  students: T[],
  enrolled: Set<string | undefined>,
  program: string,
  year: string,
  section: string,
) {
  const matching = students.filter(
    (s) =>
      s.status === "active" &&
      s.program === program &&
      String(s.year_level) === year &&
      (!section.trim() || s.section.toLowerCase() === section.trim().toLowerCase()),
  );
  return {
    candidates: matching.filter((s) => !enrolled.has(s.id)),
    skipped: matching.filter((s) => enrolled.has(s.id)).length,
  };
}
export function lowestRisk<
  T extends {
    student_id: string;
    subject_id: string;
    status: "present" | "absent" | "late" | "excused";
  },
>(rows: T[]) {
  const groups = new Map<
    string,
    { row: T; present: number; absent: number; late: number; excused: number; total: number }
  >();
  for (const row of rows) {
    const key = `${row.student_id}:${row.subject_id}`;
    const group = groups.get(key) ?? { row, present: 0, absent: 0, late: 0, excused: 0, total: 0 };
    group[row.status]++;
    group.total++;
    groups.set(key, group);
  }
  return [...groups.values()]
    .map((group) => ({ ...group, rate: attendanceRate(group) }))
    .filter(
      (group) =>
        group.total >= 3 &&
        group.present + group.late + group.absent > 0 &&
        group.rate < LOW_ATTENDANCE_THRESHOLD,
    )
    .sort((a, b) => a.rate - b.rate)
    .slice(0, 5);
}
export function marksChanged(
  marks: Record<string, { status: string; remarks: string }>,
  saved: Record<string, { status: string; remarks: string }>,
): boolean {
  const keys = [...new Set([...Object.keys(marks), ...Object.keys(saved)])];
  return keys.some(
    (key) =>
      marks[key]?.status !== saved[key]?.status || marks[key]?.remarks !== saved[key]?.remarks,
  );
}
/** Ids whose status or remarks differ from the saved baseline (new marks count as changed). */
export function changedMarkIds(
  marks: Record<string, { status: string; remarks: string }>,
  saved: Record<string, { status: string; remarks: string }>,
): string[] {
  return Object.keys(marks).filter(
    (key) => marks[key].status !== saved[key]?.status || marks[key].remarks !== saved[key]?.remarks,
  );
}
