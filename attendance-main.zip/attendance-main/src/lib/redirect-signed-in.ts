import { useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";

/** Sends already signed-in users from login/register/forgot-password to the dashboard. */
export function useRedirectIfSignedIn() {
  const { data, isLoading } = useAuth();
  const navigate = useNavigate();
  useEffect(() => {
    if (!isLoading && data) navigate({ to: "/dashboard", replace: true });
  }, [data, isLoading, navigate]);
}
