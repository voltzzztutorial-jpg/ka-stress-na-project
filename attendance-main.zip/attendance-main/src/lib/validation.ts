import { z } from "zod";

export const passwordSchema = z
  .string()
  .min(8, "Password must be at least 8 characters")
  .regex(/[A-Za-z]/, "Password must include a letter")
  .regex(/[0-9]/, "Password must include a number");

export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .min(1, "Email is required")
  .email("Enter a valid email");

export const registerSchema = z
  .object({
    full_name: z.string().trim().min(2, "Full name is required").max(100),
    email: emailSchema,
    password: passwordSchema,
    confirm: z.string(),
  })
  .refine((v) => v.password === v.confirm, {
    message: "Passwords do not match",
    path: ["confirm"],
  });

export const studentSchema = z.object({
  student_number: z.string().trim().min(1, "Student number is required").max(30),
  first_name: z.string().trim().min(1, "First name is required").max(60),
  last_name: z.string().trim().min(1, "Last name is required").max(60),
  email: emailSchema,
  program: z.string().min(1, "Program is required"),
  year_level: z.coerce.number().int().min(1).max(5),
  section: z.string().trim().min(1, "Section is required").max(10),
  status: z.enum(["active", "inactive"]),
});

export const subjectSchema = z.object({
  subject_code: z.string().trim().min(1, "Subject code is required").max(20),
  subject_name: z.string().trim().min(1, "Subject name is required").max(120),
  faculty_id: z.string().nullable(),
  schedule_day: z.string().min(1),
  schedule_time: z.string().min(1, "Time is required"),
  room: z.string().trim().min(1, "Room is required").max(30),
  semester: z.string().min(1),
  school_year: z
    .string()
    .trim()
    .regex(/^\d{4}-\d{4}$/, "Use format 2026-2027"),
});

export function fieldErrors(err: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const i of err.issues) {
    const k = String(i.path[0] ?? "");
    if (!out[k]) out[k] = i.message;
  }
  return out;
}

export { attendanceRate, isLowAttendance, LOW_ATTENDANCE_THRESHOLD } from "@/lib/attendance";
export const PROGRAMS = ["BSIT", "BSED", "BSBA", "BSCS", "BEED"];
export const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
