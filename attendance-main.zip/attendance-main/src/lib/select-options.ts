export function matchesSearch(text: string, search: string): boolean {
  return text.toLocaleLowerCase().includes(search.trim().toLocaleLowerCase());
}

export function eligibleStudents<T extends { id: string; status: string }>(
  students: T[],
  enrolledIds: Set<string | undefined>,
): T[] {
  return students.filter((student) => student.status === "active" && !enrolledIds.has(student.id));
}

export function activeFaculty<T extends { is_active: boolean }>(profiles: T[]): T[] {
  return profiles.filter((profile) => profile.is_active);
}
