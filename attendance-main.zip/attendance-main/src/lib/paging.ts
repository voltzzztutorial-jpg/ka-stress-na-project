/** Page size the backend returns per request. */
export const PAGE_SIZE = 1000;
/** Hard safety cap; callers show a notice when it is reached. */
export const MAX_ROWS = 50_000;

/**
 * Fetches every row of a query page by page so results are never silently
 * truncated by the backend's per-request row limit. `truncated` is true only
 * when the safety cap was hit.
 */
export async function fetchAllPages<T>(
  page: (
    from: number,
    to: number,
  ) => PromiseLike<{ data: T[] | null; error: { message: string } | null }>,
  max = MAX_ROWS,
): Promise<{ rows: T[]; truncated: boolean }> {
  const rows: T[] = [];
  for (let from = 0; from < max; from += PAGE_SIZE) {
    const { data, error } = await page(from, Math.min(from + PAGE_SIZE, max) - 1);
    if (error) throw new Error(error.message);
    const chunk = data ?? [];
    rows.push(...chunk);
    if (chunk.length < PAGE_SIZE) return { rows, truncated: false };
  }
  return { rows, truncated: true };
}
