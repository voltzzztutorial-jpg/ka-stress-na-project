<!-- LOVABLE:BEGIN -->

> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

<!-- LOVABLE:END -->

## AttendEase rules

- Calendar dates come from src/lib/attendance.ts (localDate/daysAgo); never toISOString() — users are in UTC+8.
- Permissions live in RLS + has_role/is_staff/teaches (all return false for inactive profiles); UI checks are cosmetic only.
- Signed-in pages live under src/routes/_authenticated; /help is top-level and switches layout by session.
- SearchableSelect is the shared Popover/Command control for searchable choices; callers supply scoped options so existing access filtering stays intact.
- Profile password mode uses Auth identities/providers plus a presentation-only user metadata flag written with successful initial password setup, because OAuth password updates may not add an email identity; the flag never grants privileges.
- UserAvatar resolves the single profile object path in the one `avatars` bucket through signed URLs (private bucket; storage SELECT is authenticated-only); joined profile data avoids row-by-row reads, and profile updates invalidate all query caches.
- Student faculty names and photos come only from my_enrolled_faculty, a narrowly scoped authenticated SQL function; never widen profiles RLS for this display.
- Attendance dirty state compares marks with a saved baseline; one page-level blocker governs navigation/beforeunload and a shared confirmation governs scope and tab changes.
- Staff quick-start and at-risk data is separately role-scoped and paged to avoid deriving risk from the dashboard's limited sample.
- Dashboard/report attendance reads page through all rows via src/lib/paging.ts and show a notice when the safety cap is hit, so totals are never silently truncated.
- Database changes live in drizzle/migrations (applied through Lovable Cloud).
- Excuse attachments are read via signed URLs; storage SELECT matches excuse_requests.file_path so owner, the subject's faculty and admins can open them.
- Excuse date/enrollment rules are enforced by a DB trigger and mirrored in src/lib/excuse.ts for UI messages.
- Storage buckets are created with the bucket tool (SQL writes to storage.buckets are blocked); policies live in migrations.
- Shared subject queries live in a browser-safe library, never in a route imported by another route, to avoid cross-route coupling.
- Record control helpers centralize range validation, stable comparison, page clamping and non-destructive bulk marking so behavioral rules have focused tests.
- Deliberate student relinking uses an active-admin RPC and a transaction-local student-scoped marker; the trigger checks both so ordinary updates cannot override links.
- Admin-removal and deactivation guards share a transaction lock, including direct profile changes, so concurrent management cannot remove the final active administrator.
- Generated auth storage lint exceptions live in ESLint configuration, not generated files, to survive regeneration.
