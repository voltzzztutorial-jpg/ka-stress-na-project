# AttendEase

Attendance management for SorSU Bulan Campus — admins, faculty and students.

Built with [Lovable](https://lovable.dev).

## Development

```sh
npm i
npm run dev
```

Run tests with `npm test`.
