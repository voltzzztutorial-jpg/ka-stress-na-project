# AttendEase verified bug fixes

## Tasks

- [x] 1.1 Account errors and retry tests
- [x] 1.2 Dashboard errors, paging and archived-student exclusion
- [x] 1.3 Reports date guards and tests
- [x] 1.4 Records pagination clamp and tests
- [x] 1.5 Stable pagination and comparator tests
- [x] 1.6 Preserve existing marks and tests
- [x] 1.7 Confirm enrollment removal and surface errors
- [x] 1.8 Smaller UI fixes and shared subject hook
- [x] 2.1–2.5 New account/security migration applied; installed definitions checked
- [x] 2.6 Optional activity and avatar extension hardening
- [x] 3 Tests and explicit testing-library peer dependency
- [x] 4 Formatting, lint and preview compilation checks
- [x] Database behavioral checks run in rolled-back transactions: linked-student email edit preserved user_id (PASS), https avatar rejected (PASS), demote and deactivate of the only active admin rejected (PASS). Unconfirmed-profile linking check skipped: every existing account is already confirmed, so there was no unconfirmed user to test against; the trigger requires email_confirmed_at by definition.
- [ ] Authenticated end-to-end browser checks: blocked because session mint found no account for the requesting user; sign in in the preview.

## Verified fixes

## Item report

- Fixed 1.1: first-load account and role errors show working retries; two focused rendering tests pass.
- Fixed 1.2: totals fail visibly, class cards offer retry, attendance reads use capped paging, inactive students excluded.
- Fixed 1.3: cleared dates retain values, range limits and reversed-range rejection; rendering test confirms no new query after clear.
- Fixed 1.4: records clamp stale pages immediately and in state; helper tests cover final-page deletion and empty data.
- Fixed 1.5: unique id ordering for students, enrollment choices and users; equal-value comparator returns positive zero.
- Fixed 1.6: bulk marking preserves existing statuses and remarks.
- Fixed 1.7: removal requires confirmation, retains attendance, surfaces errors; explanation matches preferred database behavior (existing records remain correctable/deletable).
- Fixed 1.8: subjects retry, Former faculty fallback, dirty name protection, distinct report icons, expired recovery message/link, shared subject hook.
- Fixed 2.1: confirmed-only automatic links, preserved existing links, active-admin relink RPC with logging and trigger-safe scoped authorization.
- Fixed 2.2: invalid legacy avatars cleared; profile path guard, database constraint and safe client resolver.
- Fixed 2.3: shared-lock last-active-admin role/profile guards; self-management restrictions preserved.
- Fixed 2.4: Auth email synchronization and confirmed matching-unlinked student linking.
- Fixed 2.5: enrollment required for new/reassigned attendance, not corrections/deletions; clear excuse approval enrollment failure before writes.
- Fixed 2.6: active-user activity action allowlist and avatar extension policies; existing private bucket retains 2 MB limit.
- Fixed 3: explicit @testing-library/dom dependency; 52 tests passed across 11 files.
- Fixed 4: formatted app sources; ESLint exits successfully with 0 errors and 10 existing fast-refresh warnings; preview compilation reports build OK. Generated auth storage restored and lint exceptions live in configuration.
- tsgo --noEmit and eslint src pass with zero errors (10 pre-existing fast-refresh warnings); vitest 52/52 pass; preview build OK.
- Not fully verified: authenticated in-browser flows; database guard behavior verified via rolled-back transactions instead.

## Changed files

AGENTS.md; roadmap.md; package.json; bun.lock; eslint.config.js;
drizzle/migrations/0002_account_link_and_profile_guards.sql; drizzle/migrations/meta/_journal.json; drizzle/migrations/meta/0002_snapshot.json;
src/components/AppLayout.tsx; src/components/StaffClassActions.tsx; src/components/shared.tsx; src/components/ExcuseRequests.tsx;
src/lib/avatar.ts; src/lib/my-subjects.ts; src/lib/record-controls.ts;
src/routes/_authenticated/attendance.tsx; src/routes/_authenticated/dashboard.tsx; src/routes/_authenticated/profile.tsx; src/routes/_authenticated/reports.tsx; src/routes/_authenticated/students.tsx; src/routes/_authenticated/subjects.tsx; src/routes/_authenticated/users.tsx; src/routes/reset-password.tsx;
src/test/account-errors.test.tsx; src/test/profile-password-flow.test.tsx; src/test/record-controls.test.ts; src/test/reports-dates.test.tsx.

Cloud regenerated src/integrations/supabase/types.ts after the migration (not hand-edited).

Public browser check: expired reset message displayed and new-link action reached /forgot-password.
Database read checks: both new guard triggers installed, avatar constraint installed, invalid avatar paths count 0; policy definitions include required activity and extension checks; journal contains 0002.
